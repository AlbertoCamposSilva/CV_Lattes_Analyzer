from bs4 import BeautifulSoup
import lxml
from Lattes import Lattes
from datetime import date, datetime
import pandas
import cProfile
import re
from Indicadores import Indicadores
int(datetime.now().time().strftime("%H"))