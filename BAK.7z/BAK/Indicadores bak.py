from bs4 import BeautifulSoup
from datetime import date, datetime

class Indicadores:
    def __init__ (self, xml):
        self.xml = xml
        self.id = None
        self.nome_completo = None
        self.nacionalidade = None
        self.CPF = None
        self.data_nascimento = None
        self.sexo = None
        self.data_atualizcao = None
        self.areas_do_conhecimento = [('Grande Área', 'Área', 'Sub-Área', 'Especialidade')]

        self.indicador = {}
        self.indicador['Id'] = []
        self.indicador['Indicador'] = []
        self.indicador['Descricao'] = []
        self.indicador['Ano'] = []

        self.publicacao = [('Tipo', 'Natureza', )]
        self.trabalhos_em_eventos = [('Tipo', 
                                     'Tipo - Descrição', 
                                     'Título', 
                                     'Ano publicação', 
                                     'País da publicação', 
                                     'Idioma', 
                                     'Meio de divulgação', 
                                     'Relevante?', 
                                     'DOI', 
                                     'É divulgacao científica?', 
                                     'Título em ingles', 
                                    'Homepage',
                                     'Abrangência', 
                                     'Nome do evento', 
                                     'Ano do Evento', 
                                     'Número de autores', 
                                     'Posição de autoria', 
                                     'Autores')]
        self.artigos = [('Tipo', 
                                     'Tipo - Descrição', 
                                     'Título', 
                                     'Ano publicação', 
                                     'País da publicação', 
                                     'Idioma', 
                                     'Meio de divulgação', 
                                     'Relevante?', 
                                     'DOI', 
                                     'É divulgacao científica?', 
                                     'Título em ingles', 
                                     'Homepage',
                                     'Título do Periódico', 
                                     'ISSN da revista', 
                                     'Número de autores', 
                                     'Posição de autoria', 
                                     'Autores',
                        'Áreas do Conhecimento')]        
        
        self.livros_capitulos = [('Tipo', 
                                     'Tipo - Descrição', 
                                     'Título do Livro', 
                                     'Ano publicação', 
                                     'País da publicação', 
                                     'Idioma', 
                                     'Meio de divulgação', 
                                     'Relevante?', 
                                     'DOI', 
                                     'É divulgacao científica?', 
                                     'Título em ingles', 
                                     'Homepage',
                                     'Editora', 
                                     'ISBN da revista', 
                                     'Número de autores', 
                                     'Posição de autoria', 
                                     'Autores',
                        'Áreas do Conhecimento')]            

        self.soup = BeautifulSoup(self.xml, "xml")

        #
        # FORMACAO-ACADEMICA-TITULACAO
        #
        self.cursos_tecnicos_profissionalizantes = []
        self.ensinos_fundamentais = []
        self.ensinos_medios = []
        self.graduacoes = []
        self.aperfeicoamentos = []
        self.especializacoes = []
        self.mestrados = []
        self.mestrados_profissionalizantes = []
        self.doutorados = []
        self.pos_doutorados = []
        self.livre_docencias = []
        self.residencias_medicas = []
        #
        # ATUACOES-PROFISSIONAIS
        #
        self.vinculos=[]
        self.atividades_direcao_administracao = []
        self.atividades_pesquisa_desenvolviemnto = []
        self.atividades_ensino = []
        self.atividades_estagio = []
        self.atividades_tecnico_especializado = []
        self.atividades_extensao_universitaria = []
        self.atividades_treinamento_ministrado = []
        self.atividades_outras_tecnico_cientifica = []
        self.atividades_conselho_comissao_consultoria = []
        self.areas_atuacao = []
        self.idiomas = []
        self.premios_titulos = []
        self.atividades_participacao_projeto = []




        self.get_id()
        self.get_formacao()
        self.get_areas_atuacao()
        self.get_atuacao_profissional()
        self.get_trabalhos_eventos()
        #self.get_artigos_publicados()
        #self.get_livros_capitulos()

    def indicadores_append (self, tipo, descricao, ano):
            self.indicador['Id'].append(self.id)
            self.indicador['Indicador'].append(tipo)
            self.indicador['Descricao'].append(descricao)
            self.indicador['Ano'].append(ano)

    def get_id (self):
        self.id = self.soup.find('CURRICULO-VITAE')['NUMERO-IDENTIFICADOR']
        data = self.soup.find('CURRICULO-VITAE')['DATA-ATUALIZACAO']
        hora = self.soup.find('CURRICULO-VITAE')['HORA-ATUALIZACAO']
        self.data_atualizcao = datetime.strptime(data + hora, '%d%m%Y%H%M%S')
        self.nome_completo = self.soup.find('DADOS-GERAIS')['NOME-COMPLETO']
        self.nacionalidade = self.soup.find('DADOS-GERAIS')['NACIONALIDADE']
        #self.CPF = self.soup.find('DADOS-GERAIS')['CPF']
        #self.data_nascimento = datetime.strptime(self.soup.find('DADOS-GERAIS')['DATA-NASCIMENTO'], '%d%m%Y')
        #self.sexo = self.soup.find('DADOS-GERAIS')['SEXO']
        #self.raca = self.soup.find('DADOS-GERAIS')['RACA-OU-COR']

    def get_dados_basicos_do_trabalho (self, xml):
        dados_basicos_do_trabalho = []
        for d in xml.get_all('DADOS-BASICOS-DO-TRABALHO'):
            dado = {
                "NATUREZA": d["NATUREZA"],
                "TITULO-DO-TRABALHO": d["TITULO-DO-TRABALHO"],
                "ANO-DO-TRABALHO": d["ANO-DO-TRABALHO"],
                "PAIS-DO-EVENTO": d["PAIS-DO-EVENTO"],
                "IDIOMA": d["IDIOMA"],
                "MEIO-DE-DIVULGACAO": d["MEIO-DE-DIVULGACAO"],
                "HOME-PAGE-DO-TRABALHO": d["HOME-PAGE-DO-TRABALHO"],
                "FLAG-RELEVANCIA": d["FLAG-RELEVANCIA"],
                "DOI": d["DOI"],
                "TITULO-DO-TRABALHO-INGLES": d["TITULO-DO-TRABALHO-INGLES"],
                "FLAG-DIVULGACAO-CIENTIFICA": d["FLAG-DIVULGACAO-CIENTIFICA"],
            }
            dados_basicos_do_trabalho.append(dado)
            return dados_basicos_do_trabalho


    def get_detalhamento_do_trabalho (self, xml):
        detalhamento_do_trabalho = []
        for d in xml.get_all('DETALHAMENTO-DO-TRABALHO'):
            dado = {
                "CLASSIFICACAO-DO-EVENTO": d["CLASSIFICACAO-DO-EVENTO"],
                "NOME-DO-EVENTO": d["NOME-DO-EVENTO"],
                "CIDADE-DO-EVENTO": d["CIDADE-DO-EVENTO"],
                "ANO-DE-REALIZACAO": d["ANO-DE-REALIZACAO"],
                "TITULO-DOS-ANAIS-OU-PROCEEDINGS": d["TITULO-DOS-ANAIS-OU-PROCEEDINGS"],
                "VOLUME": d["VOLUME"],
                "FASCICULO": d["FASCICULO"],
                "SERIE": d["SERIE"],
                "PAGINA-INICIAL": d["PAGINA-INICIAL"],
                "PAGINA-FINAL": d["PAGINA-FINAL"],
                "ISBN": d["ISBN"],
                "NOME-DA-EDITORA": d["NOME-DA-EDITORA"],
                "CIDADE-DA-EDITORA": d["CIDADE-DA-EDITORA"],
                "NOME-DO-EVENTO-INGLES": d["NOME-DO-EVENTO-INGLES"],
            }
            detalhamento_do_trabalho.append(dado)
            return detalhamento_do_trabalho

    def get_autores (self, xml):
        autores = []
        for d in xml.get_all('AUTORES'):
            dado = {
                "NOME-COMPLETO-DO-AUTOR": d["NOME-COMPLETO-DO-AUTOR"],
                "NOME-PARA-CITACAO": d["NOME-PARA-CITACAO"],
                "ORDEM-DE-AUTORIA": d["ORDEM-DE-AUTORIA"],
                "CPF": d["CPF"],
                "NRO-ID-CNPQ": d["NRO-ID-CNPQ"],
            }
            autores.append(dado)
            return autores

    def get_palavras_chave (self, xml):
        palavras_chaves = []
        for palavra in xml.find_all('PALAVRAS-CHAVE'):
            palavras_chaves.append(list(palavra.attrs.values()))
        return palavras_chaves

    def get_areas_do_conhecimento (self, xml):
        areas = []
        for area in xml.find_all('AREAS-DO-CONHECIMENTO'):
            for a in area.children:
                area_ga = a['NOME-GRANDE-AREA-DO-CONHECIMENTO']
                area_a = a['NOME-DA-AREA-DO-CONHECIMENTO']
                area_sa = a['NOME-DA-SUB-AREA-DO-CONHECIMENTO']
                area_e = a['NOME-DA-ESPECIALIDADE']
                areas.append ((area_ga, area_a, area_sa, area_e))
        return areas

    def get_setores_de_atividade (self, xml):
        setores = []
        for setor in xml.find_all('SETORES-DE-ATIVIDADE'):
            setores.append(list(palavra.attrs.values()))
        return setores

    def get_informacoes_adicionais (self, xml):
        informacoes = []
        for palavra in xml.find_all('INFORMACOES-ADICIONAIS'):
            informacoes.append(list(palavra.attrs.values()))
        return informacoes        
        
        
    def get_formacao(self):
        
        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        if not formacoes == None:
            formacoes = formacoes.find_all('CURSO-TECNICO-PROFISSIONALIZANTE')
            for curso in formacoes:
                curso_tecnico = {
                    "SEQUENCIA-FORMACAO": curso["SEQUENCIA-FORMACAO"],
                    "NIVEL": curso["NIVEL"],
                    "CODIGO-INSTITUICAO": curso["CODIGO-INSTITUICAO"],
                    "NOME-INSTITUICAO": curso["NOME-INSTITUICAO"],
                    "CODIGO-ORGAO": curso["CODIGO-ORGAO"],
                    "NOME-ORGAO": curso["NOME-ORGAO"],
                    "CODIGO-CURSO": curso["CODIGO-CURSO"],
                    "NOME-CURSO": curso["NOME-CURSO"],
                    "STATUS-DO-CURSO": curso["STATUS-DO-CURSO"],
                    "ANO-DE-INICIO": curso["ANO-DE-INICIO"],
                    "ANO-DE-CONCLUSAO": curso["ANO-DE-CONCLUSAO"],
                    "FLAG-BOLSA": curso["FLAG-BOLSA"],
                    "CODIGO-AGENCIA-FINANCIADORA": curso["CODIGO-AGENCIA-FINANCIADORA"],
                    "NOME-AGENCIA": curso["NOME-AGENCIA"],
                    "NOME-CURSO-INGLES": curso["NOME-CURSO-INGLES"],
                }
                self.cursos_tecnicos_profissionalizantes.append(curso_tecnico)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    indicadores_append('FMT', 'Formação nível Médio: curso Técnico/profissionalizante', curso_tecnico['ANO-DE-INICIO'], curso_tecnico['ANO-DE-CONCLUSAO'])

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        if not formacoes == None:
            formacoes = formacoes.find_all('ENSINO-FUNDAMENTAL-PRIMEIRO-GRAU')
            for curso in formacoes:
                ensino_fundamental = {
                    "SEQUENCIA-FORMACAO":curso["SEQUENCIA-FORMACAO"],
                    "NIVEL":curso["NIVEL"],
                    "CODIGO-INSTITUICAO":curso["CODIGO-INSTITUICAO"],
                    "NOME-INSTITUICAO":curso["NOME-INSTITUICAO"],
                    "STATUS-DO-CURSO":curso["STATUS-DO-CURSO"],
                    "ANO-DE-INICIO":curso["ANO-DE-INICIO"],
                    "ANO-DE-CONCLUSAO":curso["ANO-DE-CONCLUSAO"]
                    }
                self.ensinos_fundamentais.append(ensino_fundamental)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    indicadores_append('FFP', 'Formação nível Fundamental - Primeiro grau', ensino_fundamental['ANO-DE-INICIO'], ensino_fundamental['ANO-DE-CONCLUSAO'])

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        if not formacoes == None:
            formacoes = formacoes.find_all('ENSINO-MEDIO-SEGUNDO-GRAU')
            for curso in formacoes:
                ensino_medio = {
                "SEQUENCIA-FORMACAO": curso["SEQUENCIA-FORMACAO"],
                "NIVEL": curso["NIVEL"],
                "CODIGO-INSTITUICAO": curso["CODIGO-INSTITUICAO"],
                "NOME-INSTITUICAO": curso["NOME-INSTITUICAO"],
                "STATUS-DO-CURSO": curso["STATUS-DO-CURSO"],
                "ANO-DE-INICIO": curso["ANO-DE-INICIO"],
                "ANO-DE-CONCLUSAO": curso["ANO-DE-CONCLUSAO"],
                }
                self.ensinos_medios.append(ensino_medio)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('FMS', 'Formação nível Médio - Segundo Grau', ensino_medio['ANO-DE-INICIO'], ensino_medio['ANO-DE-CONCLUSAO'])

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        if not formacoes == None:
            formacoes = formacoes.find_all('GRADUACAO')
            for curso in formacoes:
                graduacao = {
                    "SEQUENCIA-FORMACAO": curso["SEQUENCIA-FORMACAO"],
                    "NIVEL": curso["NIVEL"],
                    "TITULO-DO-TRABALHO-DE-CONCLUSAO-DE-CURSO": curso["TITULO-DO-TRABALHO-DE-CONCLUSAO-DE-CURSO"],
                    "NOME-DO-ORIENTADOR": curso["NOME-DO-ORIENTADOR"],
                    "CODIGO-INSTITUICAO": curso["CODIGO-INSTITUICAO"],
                    "NOME-INSTITUICAO": curso["NOME-INSTITUICAO"],
                    "CODIGO-ORGAO": curso["CODIGO-ORGAO"],
                    "NOME-ORGAO": curso["NOME-ORGAO"],
                    "CODIGO-CURSO": curso["CODIGO-CURSO"],
                    "NOME-CURSO": curso["NOME-CURSO"],
                    "CODIGO-AREA-CURSO": curso["CODIGO-AREA-CURSO"],
                    "STATUS-DO-CURSO": curso["STATUS-DO-CURSO"],
                    "ANO-DE-INICIO": curso["ANO-DE-INICIO"],
                    "ANO-DE-CONCLUSAO": curso["ANO-DE-CONCLUSAO"],
                    "FLAG-BOLSA": curso["FLAG-BOLSA"],
                    "CODIGO-AGENCIA-FINANCIADORA": curso["CODIGO-AGENCIA-FINANCIADORA"],
                    "NOME-AGENCIA": curso["NOME-AGENCIA"],
                    "NUMERO-ID-ORIENTADOR": curso["NUMERO-ID-ORIENTADOR"],
                    "CODIGO-CURSO-CAPES": curso["CODIGO-CURSO-CAPES"],
                    "TITULO-DO-TRABALHO-DE-CONCLUSAO-DE-CURSO-INGLES": curso["TITULO-DO-TRABALHO-DE-CONCLUSAO-DE-CURSO-INGLES"],
                    "NOME-CURSO-INGLES": curso["NOME-CURSO-INGLES"],
                    "FORMACAO-ACADEMICA-TITULACAO": curso["FORMACAO-ACADEMICA-TITULACAO"],
                    "TIPO-GRADUACAO": curso["TIPO-GRADUACAO"],
                    "CODIGO-INSTITUICAO-GRAD": curso["CODIGO-INSTITUICAO-GRAD"],
                    "NOME-INSTITUICAO-GRAD": curso["NOME-INSTITUICAO-GRAD"],
                    "CODIGO-INSTITUICAO-OUTRA-GRAD": curso["CODIGO-INSTITUICAO-OUTRA-GRAD"],
                    "NOME-INSTITUICAO-OUTRA-GRAD": curso["NOME-INSTITUICAO-OUTRA-GRAD"],
                    "NOME-ORIENTADOR-GRAD": curso["NOME-ORIENTADOR-GRAD"],
                }
                self.graduacoes.append(graduacao)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('FSG', 'Formação nível Superior - Graduação', graduacao['ANO-DE-CONCLUSAO'])

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        if not formacoes == None:
            formacoes = formacoes.find_all('APERFEICOAMENTO')
            for curso in formacoes:
                aperfeicoamento = {
                    "SEQUENCIA-FORMACAO": curso["SEQUENCIA-FORMACAO"],
                    "NIVEL": curso["NIVEL"],
                    "TITULO-DA-MONOGRAFIA": curso["TITULO-DA-MONOGRAFIA"],
                    "NOME-DO-ORIENTADOR": curso["NOME-DO-ORIENTADOR"],
                    "CODIGO-INSTITUICAO": curso["CODIGO-INSTITUICAO"],
                    "NOME-INSTITUICAO": curso["NOME-INSTITUICAO"],
                    "CODIGO-ORGAO": curso["CODIGO-ORGAO"],
                    "NOME-ORGAO": curso["NOME-ORGAO"],
                    "CODIGO-CURSO": curso["CODIGO-CURSO"],
                    "NOME-CURSO": curso["NOME-CURSO"],
                    "CODIGO-AREA-CURSO": curso["CODIGO-AREA-CURSO"],
                    "STATUS-DO-CURSO": curso["STATUS-DO-CURSO"],
                    "ANO-DE-INICIO": curso["ANO-DE-INICIO"],
                    "ANO-DE-CONCLUSAO": curso["ANO-DE-CONCLUSAO"],
                    "FLAG-BOLSA": curso["FLAG-BOLSA"],
                    "CODIGO-AGENCIA-FINANCIADORA": curso["CODIGO-AGENCIA-FINANCIADORA"],
                    "NOME-AGENCIA": curso["NOME-AGENCIA"],
                    "CARGA-HORARIA": curso["CARGA-HORARIA"],
                    "TITULO-DA-MONOGRAFIA-INGLES": curso["TITULO-DA-MONOGRAFIA-INGLES"],
                    "NOME-CURSO-INGLES": curso["NOME-CURSO-INGLES"],
                }
                self.aperfeicoamentos.append(aperfeicoamento)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('FSA', 'Formação nível Superior - Aperfeiçoamento', aperfeicoamento['ANO-DE-CONCLUSAO'])

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        if not formacoes == None:
            formacoes = formacoes.find_all('ESPECIALIZACAO')
            for curso in formacoes:
                especializacao = {
                    "SEQUENCIA-FORMACAO": curso["SEQUENCIA-FORMACAO"],
                    "NIVEL": curso["NIVEL"],
                    "TITULO-DA-MONOGRAFIA": curso["TITULO-DA-MONOGRAFIA"],
                    "NOME-DO-ORIENTADOR": curso["NOME-DO-ORIENTADOR"],
                    "CODIGO-INSTITUICAO": curso["CODIGO-INSTITUICAO"],
                    "NOME-INSTITUICAO": curso["NOME-INSTITUICAO"],
                    "CODIGO-ORGAO": curso["CODIGO-ORGAO"],
                    "NOME-ORGAO": curso["NOME-ORGAO"],
                    "CODIGO-CURSO": curso["CODIGO-CURSO"],
                    "NOME-CURSO": curso["NOME-CURSO"],
                    "STATUS-DO-CURSO": curso["STATUS-DO-CURSO"],
                    "ANO-DE-INICIO": curso["ANO-DE-INICIO"],
                    "ANO-DE-CONCLUSAO": curso["ANO-DE-CONCLUSAO"],
                    "FLAG-BOLSA": curso["FLAG-BOLSA"],
                    "CODIGO-AGENCIA-FINANCIADORA": curso["CODIGO-AGENCIA-FINANCIADORA"],
                    "NOME-AGENCIA": curso["NOME-AGENCIA"],
                    "CARGA-HORARIA": curso["CARGA-HORARIA"],
                    "TITULO-DA-MONOGRAFIA-INGLES": curso["TITULO-DA-MONOGRAFIA-INGLES"],
                    "NOME-CURSO-INGLES": curso["NOME-CURSO-INGLES"],
                }
                self.especializacoes.append(especializacao)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('FSE', 'Formação nível Superior - Especialização', especializacao['ANO-DE-CONCLUSAO'])

        # MESTRADOS

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        if not formacoes == None:
            formacoes = formacoes.find_all('MESTRADO')
            for curso in formacoes:
                mestrado = {
                    "SEQUENCIA-FORMACAO": curso["SEQUENCIA-FORMACAO"],
                    "NIVEL": curso["NIVEL"],
                    "CODIGO-INSTITUICAO": curso["CODIGO-INSTITUICAO"],
                    "NOME-INSTITUICAO": curso["NOME-INSTITUICAO"],
                    "CODIGO-ORGAO": curso["CODIGO-ORGAO"],
                    "NOME-ORGAO": curso["NOME-ORGAO"],
                    "CODIGO-CURSO": curso["CODIGO-CURSO"],
                    "NOME-CURSO": curso["NOME-CURSO"],
                    "CODIGO-AREA-CURSO": curso["CODIGO-AREA-CURSO"],
                    "STATUS-DO-CURSO": curso["STATUS-DO-CURSO"],
                    "ANO-DE-INICIO": curso["ANO-DE-INICIO"],
                    "ANO-DE-CONCLUSAO": curso["ANO-DE-CONCLUSAO"],
                    "FLAG-BOLSA": curso["FLAG-BOLSA"],
                    "CODIGO-AGENCIA-FINANCIADORA": curso["CODIGO-AGENCIA-FINANCIADORA"],
                    "NOME-AGENCIA": curso["NOME-AGENCIA"],
                    "ANO-DE-OBTENCAO-DO-TITULO": curso["ANO-DE-OBTENCAO-DO-TITULO"],
                    "TITULO-DA-DISSERTACAO-TESE": curso["TITULO-DA-DISSERTACAO-TESE"],
                    "NOME-COMPLETO-DO-ORIENTADOR": curso["NOME-COMPLETO-DO-ORIENTADOR"],
                    "TIPO-MESTRADO": curso["TIPO-MESTRADO"],
                    "NUMERO-ID-ORIENTADOR": curso["NUMERO-ID-ORIENTADOR"],
                    "CODIGO-CURSO-CAPES": curso["CODIGO-CURSO-CAPES"],
                    "TITULO-DA-DISSERTACAO-TESE-INGLES": curso["TITULO-DA-DISSERTACAO-TESE-INGLES"],
                    "NOME-CURSO-INGLES": curso["NOME-CURSO-INGLES"],
                    "NOME-DO-CO-ORIENTADOR": curso["NOME-DO-CO-ORIENTADOR"],
                    "CODIGO-INSTITUICAO-DOUT": curso["CODIGO-INSTITUICAO-DOUT"],
                    "NOME-INSTITUICAO-DOUT": curso["NOME-INSTITUICAO-DOUT"],
                    "CODIGO-INSTITUICAO-OUTRA-DOUT": curso["CODIGO-INSTITUICAO-OUTRA-DOUT"],
                    "NOME-INSTITUICAO-OUTRA-DOUT": curso["NOME-INSTITUICAO-OUTRA-DOUT"],
                    "NOME-ORIENTADOR-DOUT": curso["NOME-ORIENTADOR-DOUT"],
                    }

                mestrado['PALAVRAS-CHAVE'] = get_palavras_chave(curso.find('PALAVRAS-CHAVE'))
                mestrado['AREAS-DO-CONHECIMENTO'] = get_areas_do_conhecimento(curso.find('AREAS-DO-CONHECIMENTO'))
                
                setores = []
                for setor in curso.find_all('SETORES-DE-ATIVIDADE'):
                    setores.append(list(palavra.attrs.values()))
                mestrado['SETORES-DE-ATIVIDADE'] = setores
                
                self.mestrados.append(mestrado)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('FSM', 'Formação nível Superior - Mestrado', mestrado['ANO-DE-CONCLUSAO'])

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        if not formacoes == None:
            formacoes = formacoes.find_all('MESTRADO-PROFISSIONALIZANTE')
            for curso in formacoes:
                mestrado_profissionalizante = {
                    "SEQUENCIA-FORMACAO": curso["SEQUENCIA-FORMACAO"],
                    "NIVEL": curso["NIVEL"],
                    "CODIGO-INSTITUICAO": curso["CODIGO-INSTITUICAO"],
                    "NOME-INSTITUICAO": curso["NOME-INSTITUICAO"],
                    "CODIGO-ORGAO": curso["CODIGO-ORGAO"],
                    "NOME-ORGAO": curso["NOME-ORGAO"],
                    "CODIGO-CURSO": curso["CODIGO-CURSO"],
                    "NOME-CURSO": curso["NOME-CURSO"],
                    "CODIGO-AREA-CURSO": curso["CODIGO-AREA-CURSO"],
                    "STATUS-DO-CURSO": curso["STATUS-DO-CURSO"],
                    "ANO-DE-INICIO": curso["ANO-DE-INICIO"],
                    "ANO-DE-CONCLUSAO": curso["ANO-DE-CONCLUSAO"],
                    "FLAG-BOLSA": curso["FLAG-BOLSA"],
                    "CODIGO-AGENCIA-FINANCIADORA": curso["CODIGO-AGENCIA-FINANCIADORA"],
                    "NOME-AGENCIA": curso["NOME-AGENCIA"],
                    "ANO-DE-OBTENCAO-DO-TITULO": curso["ANO-DE-OBTENCAO-DO-TITULO"],
                    "TITULO-DA-DISSERTACAO-TESE": curso["TITULO-DA-DISSERTACAO-TESE"],
                    "NOME-COMPLETO-DO-ORIENTADOR": curso["NOME-COMPLETO-DO-ORIENTADOR"],
                    "NUMERO-ID-ORIENTADOR": curso["NUMERO-ID-ORIENTADOR"],
                    "CODIGO-CURSO-CAPES": curso["CODIGO-CURSO-CAPES"],
                    "TITULO-DA-DISSERTACAO-TESE-INGLES": curso["TITULO-DA-DISSERTACAO-TESE-INGLES"],
                    "NOME-CURSO-INGLES": curso["NOME-CURSO-INGLES"],
                    "NOME-DO-CO-ORIENTADOR": curso["NOME-DO-CO-ORIENTADOR"],
                }

                mestrado_profissionalizante['PALAVRAS-CHAVE'] = get_palavras_chave(curso.find('PALAVRAS-CHAVE'))
                mestrado_profissionalizante['AREAS-DO-CONHECIMENTO'] = get_areas_do_conhecimento(curso.find('AREAS-DO-CONHECIMENTO'))
                
                setores = []
                for setor in curso.find_all('SETORES-DE-ATIVIDADE'):
                    setores.append(list(palavra.attrs.values()))
                mestrado_profissionalizante['SETORES-DE-ATIVIDADE'] = setores
                
                self.mestrados_profissionalizantes.append(mestrado_profissionalizante)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('FSR', 'Formação nível Superior - mestrado pRofissionalizante', mestrado_profissionalizante['ANO-DE-CONCLUSAO'])

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        if not formacoes == None:
            formacoes = formacoes.find_all('DOUTORADO')
            for curso in formacoes:
                doutorado = {
                    "SEQUENCIA-FORMACAO": curso["SEQUENCIA-FORMACAO"],
                    "NIVEL": curso["NIVEL"],
                    "CODIGO-INSTITUICAO": curso["CODIGO-INSTITUICAO"],
                    "NOME-INSTITUICAO": curso["NOME-INSTITUICAO"],
                    "CODIGO-ORGAO": curso["CODIGO-ORGAO"],
                    "NOME-ORGAO": curso["NOME-ORGAO"],
                    "CODIGO-CURSO": curso["CODIGO-CURSO"],
                    "NOME-CURSO": curso["NOME-CURSO"],
                    "CODIGO-AREA-CURSO": curso["CODIGO-AREA-CURSO"],
                    "STATUS-DO-CURSO": curso["STATUS-DO-CURSO"],
                    "ANO-DE-INICIO": curso["ANO-DE-INICIO"],
                    "ANO-DE-CONCLUSAO": curso["ANO-DE-CONCLUSAO"],
                    "FLAG-BOLSA": curso["FLAG-BOLSA"],
                    "CODIGO-AGENCIA-FINANCIADORA": curso["CODIGO-AGENCIA-FINANCIADORA"],
                    "NOME-AGENCIA": curso["NOME-AGENCIA"],
                    "ANO-DE-OBTENCAO-DO-TITULO": curso["ANO-DE-OBTENCAO-DO-TITULO"],
                    "TITULO-DA-DISSERTACAO-TESE": curso["TITULO-DA-DISSERTACAO-TESE"],
                    "NOME-COMPLETO-DO-ORIENTADOR": curso["NOME-COMPLETO-DO-ORIENTADOR"],
                    "TIPO-DOUTORADO": curso["TIPO-DOUTORADO"],
                    "CODIGO-INSTITUICAO-DOUT": curso["CODIGO-INSTITUICAO-DOUT"],
                    "NOME-INSTITUICAO-DOUT": curso["NOME-INSTITUICAO-DOUT"],
                    "CODIGO-INSTITUICAO-OUTRA-DOUT": curso["CODIGO-INSTITUICAO-OUTRA-DOUT"],
                    "NOME-INSTITUICAO-OUTRA-DOUT": curso["NOME-INSTITUICAO-OUTRA-DOUT"],
                    "NOME-ORIENTADOR-DOUT": curso["NOME-ORIENTADOR-DOUT"],
                    "NUMERO-ID-ORIENTADOR": curso["NUMERO-ID-ORIENTADOR"],
                    "CODIGO-CURSO-CAPES": curso["CODIGO-CURSO-CAPES"],
                    "TITULO-DA-DISSERTACAO-TESE-INGLES": curso["TITULO-DA-DISSERTACAO-TESE-INGLES"],
                    "NOME-CURSO-INGLES": curso["NOME-CURSO-INGLES"],
                    "NOME-DO-ORIENTADOR-CO-TUTELA": curso["NOME-DO-ORIENTADOR-CO-TUTELA"],
                    "CODIGO-INSTITUICAO-OUTRA-CO-TUTELA": curso["CODIGO-INSTITUICAO-OUTRA-CO-TUTELA"],
                    "CODIGO-INSTITUICAO-CO-TUTELA": curso["CODIGO-INSTITUICAO-CO-TUTELA"],
                    "NOME-DO-ORIENTADOR-SANDUICHE": curso["NOME-DO-ORIENTADOR-SANDUICHE"],
                    "CODIGO-INSTITUICAO-OUTRA-SANDUICHE": curso["CODIGO-INSTITUICAO-OUTRA-SANDUICHE"],
                    "CODIGO-INSTITUICAO-SANDUICHE": curso["CODIGO-INSTITUICAO-SANDUICHE"],
                    "NOME-DO-CO-ORIENTADOR": curso["NOME-DO-CO-ORIENTADOR"],
                }

                doutorado['PALAVRAS-CHAVE'] = get_palavras_chave(curso.find('PALAVRAS-CHAVE'))
                doutorado['AREAS-DO-CONHECIMENTO'] = get_areas_do_conhecimento(curso.find('AREAS-DO-CONHECIMENTO'))
                
                setores = []
                for setor in curso.find_all('SETORES-DE-ATIVIDADE'):
                    setores.append(list(palavra.attrs.values()))
                doutorado['SETORES-DE-ATIVIDADE'] = setores
                
                self.doutorados.append(doutorado)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('FSD', 'Formação nível Superior - Doutorado', doutorado['ANO-DE-CONCLUSAO'])

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        if not formacoes == None:
            formacoes = formacoes.find_all('RESIDENCIA-MEDICA')
            for curso in formacoes:
                residencia = {
                    "SEQUENCIA-FORMACAO": curso["SEQUENCIA-FORMACAO"],
                    "NIVEL": curso["NIVEL"],
                    "CODIGO-INSTITUICAO": curso["CODIGO-INSTITUICAO"],
                    "NOME-INSTITUICAO": curso["NOME-INSTITUICAO"],
                    "STATUS-DO-CURSO": curso["STATUS-DO-CURSO"],
                    "ANO-DE-INICIO": curso["ANO-DE-INICIO"],
                    "ANO-DE-CONCLUSAO": curso["ANO-DE-CONCLUSAO"],
                    "FLAG-BOLSA": curso["FLAG-BOLSA"],
                    "CODIGO-AGENCIA-FINANCIADORA": curso["CODIGO-AGENCIA-FINANCIADORA"],
                    "NOME-AGENCIA": curso["NOME-AGENCIA"],
                    "TITULO-DA-RESIDENCIA-MEDICA": curso["TITULO-DA-RESIDENCIA-MEDICA"],
                    "NUMERO-DO-REGISTRO": curso["NUMERO-DO-REGISTRO"],
                    "TITULO-DA-RESIDENCIA-MEDICA-INGLES": curso["TITULO-DA-RESIDENCIA-MEDICA-INGLES"],
                }

                residencia['PALAVRAS-CHAVE'] = get_palavras_chave(curso.find('PALAVRAS-CHAVE'))
                residencia['AREAS-DO-CONHECIMENTO'] = get_areas_do_conhecimento(curso.find('AREAS-DO-CONHECIMENTO'))
                
                setores = []
                for setor in curso.find_all('SETORES-DE-ATIVIDADE'):
                    setores.append(list(palavra.attrs.values()))
                residencia['SETORES-DE-ATIVIDADE'] = setores
                
                self.residencias_medicas.append(residencia)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('FSR', 'Formação nível Superior - Residência Médica', residencia['ANO-DE-CONCLUSAO'])

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        if not formacoes == None:
            formacoes = formacoes.find_all('LIVRE-DOCENCIA')
            for curso in formacoes:
                docencia = {
                    "SEQUENCIA-FORMACAO": curso["SEQUENCIA-FORMACAO"],
                    "NIVEL": curso["NIVEL"],
                    "CODIGO-INSTITUICAO": curso["CODIGO-INSTITUICAO"],
                    "NOME-INSTITUICAO": curso["NOME-INSTITUICAO"],
                    "ANO-DE-OBTENCAO-DO-TITULO": curso["ANO-DE-OBTENCAO-DO-TITULO"],
                    "TITULO-DO-TRABALHO": curso["TITULO-DO-TRABALHO"],
                    "TITULO-DO-TRABALHO-INGLES": curso["TITULO-DO-TRABALHO-INGLES"],
                }

                palavras_chaves = []
                for palavra in :
                    palavras_chaves.append(list(palavra.attrs.values()))

                docencia['PALAVRAS-CHAVE'] = get_palavras_chave(curso.find('PALAVRAS-CHAVE'))
                docencia['AREAS-DO-CONHECIMENTO'] = get_areas_do_conhecimento(curso.find('AREAS-DO-CONHECIMENTO'))
                
                setores = []
                for setor in curso.find_all('SETORES-DE-ATIVIDADE'):
                    setores.append(list(palavra.attrs.values()))
                docencia['SETORES-DE-ATIVIDADE'] = setores
                
                self.livre_docencias.append(docencia)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    print('colocando indicador LD')
                    self.indicadores_append('FSL', 'Formação nível Superior - Livre Docência', docencia['ANO-DE-CONCLUSAO'])

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        if not formacoes == None:
            formacoes = formacoes.find_all('POS-DOUTORADO')
            for curso in formacoes:
                pd = {
                    "SEQUENCIA-FORMACAO": curso["SEQUENCIA-FORMACAO"],
                    "NIVEL": curso["NIVEL"],
                    "CODIGO-INSTITUICAO": curso["CODIGO-INSTITUICAO"],
                    "NOME-INSTITUICAO": curso["NOME-INSTITUICAO"],
                    "ANO-DE-INICIO": curso["ANO-DE-INICIO"],
                    "ANO-DE-CONCLUSAO": curso["ANO-DE-CONCLUSAO"],
                    "ANO-DE-OBTENCAO-DO-TITULO": curso["ANO-DE-OBTENCAO-DO-TITULO"],
                    "FLAG-BOLSA": curso["FLAG-BOLSA"],
                    "CODIGO-AGENCIA-FINANCIADORA": curso["CODIGO-AGENCIA-FINANCIADORA"],
                    "NOME-AGENCIA": curso["NOME-AGENCIA"],
                    "STATUS-DO-ESTAGIO": curso["STATUS-DO-ESTAGIO"],
                    "STATUS-DO-CURSO": curso["STATUS-DO-CURSO"],
                    "NUMERO-ID-ORIENTADOR": curso["NUMERO-ID-ORIENTADOR"],
                    "CODIGO-CURSO-CAPES": curso["CODIGO-CURSO-CAPES"],
                    "TITULO-DO-TRABALHO": curso["TITULO-DO-TRABALHO"],
                    "TITULO-DO-TRABALHO-INGLES": curso["TITULO-DO-TRABALHO-INGLES"],
                    "NOME-CURSO-INGLES": curso["NOME-CURSO-INGLES"],
                }

                pd['PALAVRAS-CHAVE'] = get_palavras_chave(curso.find('PALAVRAS-CHAVE'))
                pd['AREAS-DO-CONHECIMENTO'] = get_areas_do_conhecimento(curso.find('AREAS-DO-CONHECIMENTO'))
                
                setores = []
                for setor in curso.find_all('SETORES-DE-ATIVIDADE'):
                    setores.append(list(palavra.attrs.values()))
                pd['SETORES-DE-ATIVIDADE'] = setores
                
                self.pos_doutorados.append(pd)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('FSP', 'Formação nível Superior - Pós-Doutorado', pd['ANO-DE-CONCLUSAO'])

            
    def get_atuacao_profissional (self):

        # self.vinculos=[]
        sopa = self.soup.find('ATUACOES-PROFISSIONAIS')
        if not sopa == None:
            sopa = sopa.find_all('VINCULOS')
            for atuacao in sopa:
                vinculo = {
                    "SEQUENCIA-HISTORICO": atuacao["SEQUENCIA-HISTORICO"],
                    "TIPO-DE-VINCULO": atuacao["TIPO-DE-VINCULO"],
                    "ENQUADRAMENTO-FUNCIONAL": atuacao["ENQUADRAMENTO-FUNCIONAL"],
                    "CARGA-HORARIA-SEMANAL": atuacao["CARGA-HORARIA-SEMANAL"],
                    "FLAG-DEDICACAO-EXCLUSIVA": atuacao["FLAG-DEDICACAO-EXCLUSIVA"],
                    "MES-INICIO": atuacao["MES-INICIO"],
                    "ANO-INICIO": atuacao["ANO-INICIO"],
                    "MES-FIM": atuacao["MES-FIM"],
                    "ANO-FIM": atuacao["ANO-FIM"],
                    "OUTRAS-INFORMACOES": atuacao["OUTRAS-INFORMACOES"],
                    "FLAG-VINCULO-EMPREGATICIO": atuacao["FLAG-VINCULO-EMPREGATICIO"],
                    "OUTRO-VINCULO-INFORMADO": atuacao["OUTRO-VINCULO-INFORMADO"],
                    "OUTRO-ENQUADRAMENTO-FUNCIONAL-INFORMADO": atuacao["OUTRO-ENQUADRAMENTO-FUNCIONAL-INFORMADO"],
                    "OUTRO-ENQUADRAMENTO-FUNCIONAL-INFORMADO-INGLES": atuacao["OUTRO-ENQUADRAMENTO-FUNCIONAL-INFORMADO-INGLES"],
                    "OUTRAS-INFORMACOES-INGLES": atuacao["OUTRAS-INFORMACOES-INGLES"],
                }
                self.vinculos.append(vinculo)
                self.indicadores_append('PV' + atuacao["TIPO-DE-VINCULO"][0], 'atuação Profissional, Vínculo + primeira letras do tipo de vínculo', atuacao["ANO-FIM"])

        # self.atividades_direcao_administracao = []
        sopa = self.soup.find('ATIVIDADES-DE-DIRECAO-E-ADMINISTRACAO')
        if not sopa == None:
            sopa = sopa.find_all('DIRECAO-E-ADMINISTRACAO')
            for atuacao in sopa:
                vinculo = {
                    "SEQUENCIA-FUNCAO-ATIVIDADE": atuacao["SEQUENCIA-FUNCAO-ATIVIDADE"],
                    "FLAG-PERIODO": atuacao["FLAG-PERIODO"],
                    "MES-INICIO": atuacao["MES-INICIO"],
                    "ANO-INICIO": atuacao["ANO-INICIO"],
                    "MES-FIM": atuacao["MES-FIM"],
                    "ANO-FIM": atuacao["ANO-FIM"],
                    "CODIGO-ORGAO": atuacao["CODIGO-ORGAO"],
                    "NOME-ORGAO": atuacao["NOME-ORGAO"],
                    "CODIGO-UNIDADE": atuacao["CODIGO-UNIDADE"],
                    "FORMATO-CARGO-OU-FUNCAO": atuacao["FORMATO-CARGO-OU-FUNCAO"],
                    "CARGO-OU-FUNCAO": atuacao["CARGO-OU-FUNCAO"],
                    "NOME-UNIDADE": atuacao["NOME-UNIDADE"],
                    "CARGO-OU-FUNCAO-INGLES": atuacao["CARGO-OU-FUNCAO-INGLES"],
                }
                self.atividades_direcao_administracao.append(vinculo)
                self.indicadores_append('PD' + atuacao["FORMATO-CARGO-OU-FUNCAO"][0], 'atuação Profissional, Direção e administração + primeira letras do tipo de direção', atuacao["ANO-FIM"])

        # self.atividades_pesquisa_desenvolviemnto = []
        sopa = self.soup.find('ATIVIDADES-DE-PESQUISA-E-DESENVOLVIMENTO')
        if not sopa == None:
            sopa = sopa.find_all('PESQUISA-E-DESENVOLVIMENTO')
            for atuacao in sopa:
                vinculo = {
                "SEQUENCIA-FUNCAO-ATIVIDADE": vinculo["SEQUENCIA-FUNCAO-ATIVIDADE"],
                "FLAG-PERIODO": vinculo["FLAG-PERIODO"],
                "MES-INICIO": vinculo["MES-INICIO"],
                "ANO-INICIO": vinculo["ANO-INICIO"],
                "MES-FIM": vinculo["MES-FIM"],
                "ANO-FIM": vinculo["ANO-FIM"],
                "CODIGO-ORGAO": vinculo["CODIGO-ORGAO"],
                "NOME-ORGAO": vinculo["NOME-ORGAO"],
                "CODIGO-UNIDADE": vinculo["CODIGO-UNIDADE"],
                "NOME-UNIDADE": vinculo["NOME-UNIDADE"],
                }
                linhas_de_pesquisa = []
                for linha in atuacao.find_all('LINHA-DE-PESQUISA'):
                    linha_pesquisa = {
                    "SEQUENCIA-LINHA": linha["SEQUENCIA-LINHA"],
                    "TITULO-DA-LINHA-DE-PESQUISA": linha["TITULO-DA-LINHA-DE-PESQUISA"],
                    "FLAG-LINHA-DE-PESQUISA-ATIVA": linha["FLAG-LINHA-DE-PESQUISA-ATIVA"],
                    "OBJETIVOS-LINHA-DE-PESQUISA": linha["OBJETIVOS-LINHA-DE-PESQUISA"],
                    "TITULO-DA-LINHA-DE-PESQUISA-INGLES": linha["TITULO-DA-LINHA-DE-PESQUISA-INGLES"],
                    "OBJETIVOS-LINHA-DE-PESQUISA-INGLES": linha["OBJETIVOS-LINHA-DE-PESQUISA-INGLES"],
                    }
                    
                    linha_pesquisa['PALAVRAS-CHAVE'] = get_palavras_chave(linha.find('PALAVRAS-CHAVE'))
                    linha_pesquisa['AREAS-DO-CONHECIMENTO'] = get_areas_do_conhecimento(curso.find('AREAS-DO-CONHECIMENTO'))
                    
                    setores = []
                    for setor in linha.find_all('SETORES-DE-ATIVIDADE'):
                        setores.append(list(palavra.attrs.values()))
                    linha_pesquisa['SETORES-DE-ATIVIDADE'] = setores

                    linhas_de_pesquisa.append(linha_pesquisa)
                    if linha["FLAG-LINHA-DE-PESQUISA-ATIVA"] == "ATUAL":
                        self.indicadores_append('PPL', 'atuação Profissional, atividades de Pesquisa e desenvolvimento, Linhas de Pesquisa', None)
                
                vinculo["LINHA-DE-PESQUISA"] = linhas_de_pesquisa
                self.atividades_pesquisa_desenvolviemnto.append(vinculo)

        # self.atividades_ensino = []
        sopa = self.soup.find('ATIVIDADES-DE-ENSINO')
        if not sopa == None:
            sopa = sopa.find_all('ENSINO')
            for atuacao in sopa:
                atua = {
                "SEQUENCIA-FUNCAO-ATIVIDADE": atuacao["SEQUENCIA-FUNCAO-ATIVIDADE"],
                "FLAG-PERIODO": atuacao["FLAG-PERIODO"],
                "TIPO-ENSINO": atuacao["TIPO-ENSINO"],
                "MES-INICIO": atuacao["MES-INICIO"],
                "ANO-INICIO": atuacao["ANO-INICIO"],
                "MES-FIM": atuacao["MES-FIM"],
                "ANO-FIM": atuacao["ANO-FIM"],
                "CODIGO-ORGAO": atuacao["CODIGO-ORGAO"],
                "NOME-ORGAO": atuacao["NOME-ORGAO"],
                "CODIGO-CURSO": atuacao["CODIGO-CURSO"],
                "NOME-CURSO": atuacao["NOME-CURSO"],
                "NOME-CURSO-INGLES": atuacao["NOME-CURSO-INGLES"]}
                disciplinas_ministradas = []
                for disciplina in atuacao.find_all('DISCIPLINA'):
                    disciplinas_ministradas.append (disciplina.string)
                    self.indicadores_append('PED', 'atuação Profissional, atividades de Ensino - Disciplinas', atuacao["ANO-FIM"])
                atua['DISCIPLINAS'] = disciplinas_ministradas
                self.atividades_ensino.append(atua)
  

        # self.atividades_estagio = []
        sopa = self.soup.find('ATIVIDADES-DE-ESTAGIO')
        if not sopa == None:
            sopa = sopa.find_all('ESTAGIO')
            for atuacao in sopa:
                atua = {
                    "SEQUENCIA-FUNCAO-ATIVIDADE": atuacao["SEQUENCIA-FUNCAO-ATIVIDADE"],
                    "FLAG-PERIODO": atuacao["FLAG-PERIODO"],
                    "MES-INICIO": atuacao["MES-INICIO"],
                    "ANO-INICIO": atuacao["ANO-INICIO"],
                    "MES-FIM": atuacao["MES-FIM"],
                    "ANO-FIM": atuacao["ANO-FIM"],
                    "CODIGO-ORGAO": atuacao["CODIGO-ORGAO"],
                    "NOME-ORGAO": atuacao["NOME-ORGAO"],
                    "CODIGO-UNIDADE": atuacao["CODIGO-UNIDADE"],
                    "NOME-UNIDADE": atuacao["NOME-UNIDADE"],
                    "ESTAGIO-REALIZADO": atuacao["ESTAGIO-REALIZADO"],
                }
                self.atividades_estagio.append(atua)
                self.indicadores_append('PEE', 'atuação Profissional - atividades de Estágio - Estágio', atuacao["ANO-FIM"])


        # self.atividades_tecnico_especializado = []
        sopa = self.soup.find('ATIVIDADES-DE-SERVICO-TECNICO-ESPECIALIZADO')
        if not sopa == None:
            sopa = sopa.find_all('SERVICO-TECNICO-ESPECIALIZADO')
            for atuacao in sopa:
                atua = {
                    "SEQUENCIA-FUNCAO-ATIVIDADE": atuacao["SEQUENCIA-FUNCAO-ATIVIDADE"],
                    "FLAG-PERIODO": atuacao["FLAG-PERIODO"],
                    "MES-INICIO": atuacao["MES-INICIO"],
                    "ANO-INICIO": atuacao["ANO-INICIO"],
                    "MES-FIM": atuacao["MES-FIM"],
                    "ANO-FIM": atuacao["ANO-FIM"],
                    "CODIGO-ORGAO": atuacao["CODIGO-ORGAO"],
                    "NOME-ORGAO": atuacao["NOME-ORGAO"],
                    "CODIGO-UNIDADE": atuacao["CODIGO-UNIDADE"],
                    "NOME-UNIDADE": atuacao["NOME-UNIDADE"],
                    "SERVICO-REALIZADO": atuacao["SERVICO-REALIZADO"],
                    }
                self.atividades_tecnico_especializado.append(atua)
                self.indicadores_append('PTS', 'atuação Profissional - atividades de Técnico-especializados - Serviço técnico-epecializado', atuacao["ANO-FIM"])

        # self.atividades_extensao_universitaria = []
        sopa = self.soup.find('ATIVIDADES-DE-EXTENSAO-UNIVERSITARIA')
        if not sopa == None:
            sopa = sopa.find_all('EXTENSAO-UNIVERSITARIA')
            for atuacao in sopa:
                atua = {
                    "SEQUENCIA-FUNCAO-ATIVIDADE": atuacao["SEQUENCIA-FUNCAO-ATIVIDADE"],
                    "FLAG-PERIODO": atuacao["FLAG-PERIODO"],
                    "MES-INICIO": atuacao["MES-INICIO"],
                    "ANO-INICIO": atuacao["ANO-INICIO"],
                    "MES-FIM": atuacao["MES-FIM"],
                    "ANO-FIM": atuacao["ANO-FIM"],
                    "CODIGO-ORGAO": atuacao["CODIGO-ORGAO"],
                    "NOME-ORGAO": atuacao["NOME-ORGAO"],
                    "CODIGO-UNIDADE": atuacao["CODIGO-UNIDADE"],
                    "NOME-UNIDADE": atuacao["NOME-UNIDADE"],
                    "ATIVIDADE-DE-EXTENSAO-REALIZADA": atuacao["ATIVIDADE-DE-EXTENSAO-REALIZADA"],
                    }
                self.atividades_tecnico_especializado.append(atua)
                self.indicadores_append('PEU', 'atuação Profissional - atividades de Extensão Universitária - extensão universitária', atuacao["ANO-FIM"])


        # self.atividades_treinamento_ministrado = []
        sopa = self.soup.find('ATIVIDADES-DE-TREINAMENTO-MINISTRADO')
        if not sopa == None:
            sopa = sopa.find_all('TREINAMENTO-MINISTRADO')
            for atuacao in sopa:
                atua = {
                    "SEQUENCIA-FUNCAO-ATIVIDADE": atuacao["SEQUENCIA-FUNCAO-ATIVIDADE"],
                    "FLAG-PERIODO": atuacao["FLAG-PERIODO"],
                    "MES-INICIO": atuacao["MES-INICIO"],
                    "ANO-INICIO": atuacao["ANO-INICIO"],
                    "MES-FIM": atuacao["MES-FIM"],
                    "ANO-FIM": atuacao["ANO-FIM"],
                    "CODIGO-ORGAO": atuacao["CODIGO-ORGAO"],
                    "NOME-ORGAO": atuacao["NOME-ORGAO"],
                    "CODIGO-UNIDADE": atuacao["CODIGO-UNIDADE"],
                    "NOME-UNIDADE": atuacao["NOME-UNIDADE"],
                    }
                atua['TREINAMENTOS'] = [t.string for t in atuacao.find_all('TREINAMENTO')]
                self.atividades_treinamento_ministrado.append(atua)
                self.indicadores_append('PTM', 'atuação Profissional - atividades de Treinamento Ministrado - treinamento ministrado', atuacao["ANO-FIM"])

        # self.atividades_outras_tecnico_cientifica = []
        sopa = self.soup.find('OUTRAS-ATIVIDADES-TECNICO-CIENTIFICA')
        if not sopa == None:
            sopa = sopa.find_all('OUTRA-ATIVIDADE-TECNICO-CIENTIFICA')
            for atuacao in sopa:
                atua = {
                    "SEQUENCIA-FUNCAO-ATIVIDADE": atuacao["SEQUENCIA-FUNCAO-ATIVIDADE"],
                    "FLAG-PERIODO": atuacao["FLAG-PERIODO"],
                    "MES-INICIO": atuacao["MES-INICIO"],
                    "ANO-INICIO": atuacao["ANO-INICIO"],
                    "MES-FIM": atuacao["MES-FIM"],
                    "ANO-FIM": atuacao["ANO-FIM"],
                    "CODIGO-ORGAO": atuacao["CODIGO-ORGAO"],
                    "NOME-ORGAO": atuacao["NOME-ORGAO"],
                    "CODIGO-UNIDADE": atuacao["CODIGO-UNIDADE"],
                    "ATIVIDADE-REALIZADA": atuacao["ATIVIDADE-REALIZADA"],
                    "NOME-UNIDADE": atuacao["NOME-UNIDADE"],
                    }
                self.atividades_outras_tecnico_cientifica.append(atua)
                self.indicadores_append('POA', 'atuação Profissional - Outras Atividades técnico-científicas', atuacao["ANO-FIM"])


        # self.atividades_conselho_comissao_consultoria = []
        sopa = self.soup.find('ATIVIDADES-DE-CONSELHO-COMISSAO-E-CONSULTORIA')
        if not sopa == None:
            sopa = sopa.find_all('CONSELHO-COMISSAO-E-CONSULTORIA')
            for atuacao in sopa:
                atua = {
                    "SEQUENCIA-FUNCAO-ATIVIDADE": atuacao["SEQUENCIA-FUNCAO-ATIVIDADE"],
                    "FLAG-PERIODO": atuacao["FLAG-PERIODO"],
                    "MES-INICIO": atuacao["MES-INICIO"],
                    "ANO-INICIO": atuacao["ANO-INICIO"],
                    "MES-FIM": atuacao["MES-FIM"],
                    "ANO-FIM": atuacao["ANO-FIM"],
                    "CODIGO-ORGAO": atuacao["CODIGO-ORGAO"],
                    "NOME-ORGAO": atuacao["NOME-ORGAO"],
                    "CODIGO-UNIDADE": atuacao["CODIGO-UNIDADE"],
                    "NOME-UNIDADE": atuacao["NOME-UNIDADE"],
                    "ESPECIFICACAO": atuacao["ESPECIFICACAO"],
                    }
                self.atividades_outras_tecnico_cientifica.append(atua)
                self.indicadores_append('PCC', 'atuação Profissional - atividades de Conselho, Comissão e Consultoria', atuacao["ANO-FIM"])

        # self.areas_atuacao = []

        sopa = self.soup.find('AREAS-DE-ATUACAO')
        if not sopa == None:
            sopa = sopa.find_all('AREA-DE-ATUACAO')
            for atuacao in sopa:
                atua = {
                    "SEQUENCIA-AREA-DE-ATUACAO": atuacao["SEQUENCIA-AREA-DE-ATUACAO"],
                    "NOME-GRANDE-AREA-DO-CONHECIMENTO": atuacao["NOME-GRANDE-AREA-DO-CONHECIMENTO"],
                    "NOME-DA-AREA-DO-CONHECIMENTO": atuacao["NOME-DA-AREA-DO-CONHECIMENTO"],
                    "NOME-DA-SUB-AREA-DO-CONHECIMENTO": atuacao["NOME-DA-SUB-AREA-DO-CONHECIMENTO"],
                    "NOME-DA-ESPECIALIDADE": atuacao["NOME-DA-ESPECIALIDADE"],
                    }
                self.areas_atuacao.append(atua)
                self.indicadores_append('PAA', 'atuação Profissional - Áreas de Atuação', None)


        # self.idiomas = []
        sopa = self.soup.find('IDIOMAS')
        if not sopa == None:
            sopa = sopa.find_all('IDIOMA')
            for atuacao in sopa:
                atua = {
                    "IDIOMA": atuacao["IDIOMA"],
                    "DESCRICAO-DO-IDIOMA": atuacao["DESCRICAO-DO-IDIOMA"],
                    "PROFICIENCIA-DE-LEITURA": atuacao["PROFICIENCIA-DE-LEITURA"],
                    "PROFICIENCIA-DE-FALA": atuacao["PROFICIENCIA-DE-FALA"],
                    "PROFICIENCIA-DE-ESCRITA": atuacao["PROFICIENCIA-DE-ESCRITA"],
                    "PROFICIENCIA-DE-COMPREENSAO": atuacao["PROFICIENCIA-DE-COMPREENSAO"],
                }
                self.idiomas.append(atua)
                self.indicadores_append('PII', 'atuação Profissional - Idiomas', None)

        # self.premios_titulos = []
        sopa = self.soup.find('PREMIOS-TITULOS')
        if not sopa == None:
            sopa = sopa.find_all('PREMIO-TITULO')
            for atuacao in sopa:
                atua = {
                    "NOME-DO-PREMIO-OU-TITULO": atuacao["NOME-DO-PREMIO-OU-TITULO"],
                    "NOME-DA-ENTIDADE-PROMOTORA": atuacao["NOME-DA-ENTIDADE-PROMOTORA"],
                    "ANO-DA-PREMIACAO": atuacao["ANO-DA-PREMIACAO"],
                    "NOME-DO-PREMIO-OU-TITULO-INGLES": atuacao["NOME-DO-PREMIO-OU-TITULO-INGLES"],
                }
                self.premios_titulos.append(atua)
                self.indicadores_append('PPT', 'atuação Profissional - Prêmios e Títulos', atua['ANO-DA-PREMIACAO'])


        # self.atividades_participacao_projeto = []
        sopa = self.soup.find('ATIVIDADES-DE-PARTICIPACAO-EM-PROJETO')
        if not sopa == None:
            sopa = sopa.find_all('PARTICIPACAO-EM-PROJETO')
            for atuacao in sopa:
                atua = {
                    "SEQUENCIA-FUNCAO-ATIVIDADE": atuacao["SEQUENCIA-FUNCAO-ATIVIDADE"],
                    "FLAG-PERIODO": atuacao["FLAG-PERIODO"],
                    "MES-INICIO": atuacao["MES-INICIO"],
                    "ANO-INICIO": atuacao["ANO-INICIO"],
                    "MES-FIM": atuacao["MES-FIM"],
                    "ANO-FIM": atuacao["ANO-FIM"],
                    "CODIGO-ORGAO": atuacao["CODIGO-ORGAO"],
                    "NOME-ORGAO": atuacao["NOME-ORGAO"],
                    "CODIGO-UNIDADE": atuacao["CODIGO-UNIDADE"],
                    "NOME-UNIDADE": atuacao["NOME-UNIDADE"],
                }
                self.premios_titulos.append(atua)
                self.indicadores_append('PP', 'atuação Profissional - Participação em projeto de pesquisa', atua['ANO-FIM'])
                projeto_pesquisa = []
                projetos_pesquisa = atuacao.find_all('PROJETO-DE-PESQUISA')
                for p in projetos_pesquisa:
                    projeto = {
                        "SEQUENCIA-PROJETO": p["SEQUENCIA-PROJETO"],
                        "ANO-INICIO": p["ANO-INICIO"],
                        "ANO-FIM": p["ANO-FIM"],
                        "NOME-DO-PROJETO": p["NOME-DO-PROJETO"],
                        "SITUACAO": p["SITUACAO"],
                        "NATUREZA": p["NATUREZA"],
                        "NUMERO-GRADUACAO": p["NUMERO-GRADUACAO"],
                        "NUMERO-ESPECIALIZACAO": p["NUMERO-ESPECIALIZACAO"],
                        "NUMERO-MESTRADO-ACADEMICO": p["NUMERO-MESTRADO-ACADEMICO"],
                        "NUMERO-MESTRADO-PROF": p["NUMERO-MESTRADO-PROF"],
                        "NUMERO-DOUTORADO": p["NUMERO-DOUTORADO"],
                        "DESCRICAO-DO-PROJETO": p["DESCRICAO-DO-PROJETO"],
                        "IDENTIFICADOR-PROJETO": p["IDENTIFICADOR-PROJETO"],
                        "DESCRICAO-DO-PROJETO-INGLES": p["DESCRICAO-DO-PROJETO-INGLES"],
                        "NOME-DO-PROJETO-INGLES": p["NOME-DO-PROJETO-INGLES"],
                        "FLAG-POTENCIAL-INOVACAO": p["FLAG-POTENCIAL-INOVACAO"],
                        "NOME-COORDENADOR-CERTIFICACAO": p["NOME-COORDENADOR-CERTIFICACAO"],
                        "FORMATO-DATA-CERTIFICACAO": p["FORMATO-DATA-CERTIFICACAO"],
                        "DATA-CERTIFICACAO": p["DATA-CERTIFICACAO"],
                        "NUMERO_TECNICO_NIVEL_MEDIO": p["NUMERO_TECNICO_NIVEL_MEDIO"],
                    }
                    self.indicadores_append('PPP', 'atuação Profissional - Participação em Projeto de pesquisa - Projeto realizado', atua['ANO-FIM'])
                    integrantes = []
                    for equipe in p.find('EQUIPE-DO-PROJETO').find_all('INTEGRANTES-DO-PROJETO'):
                        integrante = {
                            "NOME-COMPLETO": equipe["NOME-COMPLETO"],
                            "NOME-PARA-CITACAO": equipe["NOME-PARA-CITACAO"],
                            "ORDEM-DE-INTEGRACAO": equipe["ORDEM-DE-INTEGRACAO"],
                            "FLAG-RESPONSAVEL": equipe["FLAG-RESPONSAVEL"],
                            "NRO-ID-CNPQ": equipe["NRO-ID-CNPQ"],
                        }
                        integrantes.append(integrante)
                        self.indicadores_append('PPI', 'atuação Profissional - Participação em Projeto de pesquisa - Integrante em projeto', atua['ANO-FIM'])
                    projeto['INTEGRANTES'] = integrantes

                    financiadores = []
                    for financiador in p.find('FINANCIADORES-DO-PROJETO').find_all('FINANCIADOR-DO-PROJETO'):
                        finan = {
                            "SEQUENCIA-FINANCIADOR": financiador["SEQUENCIA-FINANCIADOR"],
                            "CODIGO-INSTITUICAO": financiador["CODIGO-INSTITUICAO"],
                            "NOME-INSTITUICAO": financiador["NOME-INSTITUICAO"],
                            "NATUREZA": financiador["NATUREZA"],
                        }
                        financiadores.append(finan)
                        self.indicadores_append('PAF', 'atuação Profissional - Participação em Projeto de pesquisa - financiador no projeto do pesquisador', atua['ANO-FIM'])
                    projeto['FINANCIADORES'] = financiadores

                    producoes = []
                    for produtor in p.find('PRODUCOES-CT-DO-PROJETO').find_all('PRODUCAO-CT-DO-PROJETO'):
                        prod = {
                            "SEQUENCIA-PRODUCAO-CT": produtor["SEQUENCIA-PRODUCAO-CT"],
                            "TITULO-DA-PRODUCAO-CT": produtor["TITULO-DA-PRODUCAO-CT"],
                            "TIPO-PRODUCAO-CT": produtor["TIPO-PRODUCAO-CT"],
                            "TITULO-DA-PRODUCAO-CT-INGLES": produtor["TITULO-DA-PRODUCAO-CT-INGLES"],
                            }
                        producoes.append(prod)
                        self.indicadores_append('PPR', 'atuação Profissional - Participação em Projeto de pesquisa - pRodução em C&T', None)
                    projeto['PRODUCOES'] = producoes

                    orientacoes = []
                    for orientacao in p.find('ORIENTACOES').find_all('ORIENTACAO'):
                        orien = {
                            "SEQUENCIA-ORIENTACAO": orientacao["SEQUENCIA-ORIENTACAO"],
                            "TITULO-ORIENTACAO": orientacao["TITULO-ORIENTACAO"],
                            "TIPO-ORIENTACAO": orientacao["TIPO-ORIENTACAO"],
                            "TITULO-ORIENTACAO-INGLES": orientacao["TITULO-ORIENTACAO-INGLES"],
                        }
                        orientacoes.append(orien)
                        self.indicadores_append('PPO', 'atuação Profissional - Participação em Projeto de pesquisa - Orientacoes', None)
                    projeto['ORIENTACOES'] = orientacoes

    def get_areas_atuacao(self):
        areas = self.soup.find('DADOS-GERAIS').find_all('AREA-DE-ATUACAO')
        for area in areas:
            area_ga = area['NOME-GRANDE-AREA-DO-CONHECIMENTO']
            area_a = area['NOME-DA-AREA-DO-CONHECIMENTO']
            area_sa = area['NOME-DA-SUB-AREA-DO-CONHECIMENTO']
            area_e = area['NOME-DA-ESPECIALIDADE']
            self.areas_do_conhecimento.append ((area_ga, area_a, area_sa, area_e))
        if len(self.areas_do_conhecimento) <= 1:
            self.areas_do_conhecimento.append ((None, None, None, None))

    def get_trabalhos_eventos (self):
        producao_bibliografica = self.soup.find('PRODUCAO-BIBLIOGRAFICA')


        #"TRABALHOS-EM-EVENTOS"
        trabalhos_em_eventos = []
        sopa = self.soup.find('TRABALHOS-EM-EVENTOS')
        if not sopa == None:
            sopa = sopa.find_all('TRABALHO-EM-EVENTOS')
            for producao in sopa:
                atua = {"SEQUENCIA-PRODUCAO": producao['SEQUENCIA-PRODUCAO']}
                dados_basicos_do_trabalho = get_dados_basicos_do_trabalho (xml)






        #"ARTIGOS-PUBLICADOS"
        #"LIVROS-E-CAPITULOS"
        #"TEXTOS-EM-JORNAIS-OU-REVISTAS"
        #"DEMAIS-TIPOS-DE-PRODUCAO-BIBLIOGRAFICA"
        #"ARTIGOS-ACEITOS-PARA-PUBLICACAO"


    
    def get_trabalhos_eventos2 (self):
        prod = self.soup.find('PRODUCAO-BIBLIOGRAFICA').find('TRABALHOS-EM-EVENTOS')
        
        for producao in prod.children:
            tipo = producao.name
            natureza = producao.find('DADOS-BASICOS-DO-TRABALHO')['NATUREZA']
            titulo = producao.find('DADOS-BASICOS-DO-TRABALHO')['TITULO-DO-TRABALHO']
            ano = producao.find('DADOS-BASICOS-DO-TRABALHO')['ANO-DO-TRABALHO']
            pais = producao.find('DADOS-BASICOS-DO-TRABALHO')['PAIS-DO-EVENTO']
            idioma = producao.find('DADOS-BASICOS-DO-TRABALHO')['IDIOMA']
            meio_de_divulgacao = producao.find('DADOS-BASICOS-DO-TRABALHO')['MEIO-DE-DIVULGACAO']
            flag_relevancia = producao.find('DADOS-BASICOS-DO-TRABALHO')['FLAG-RELEVANCIA']
            doi = producao.find('DADOS-BASICOS-DO-TRABALHO')['DOI']
            flag_divulgacao_cientifica = producao.find('DADOS-BASICOS-DO-TRABALHO')['FLAG-DIVULGACAO-CIENTIFICA']
            titulo_ingles = producao.find('DADOS-BASICOS-DO-TRABALHO')['TITULO-DO-TRABALHO-INGLES']
            homepage = producao.find('DADOS-BASICOS-DO-TRABALHO')['HOME-PAGE-DO-TRABALHO']
            
            internacional = producao.find('DETALHAMENTO-DO-TRABALHO')['CLASSIFICACAO-DO-EVENTO']
            nome_evento = producao.find('DETALHAMENTO-DO-TRABALHO')['NOME-DO-EVENTO']
            ano_do_evento = producao.find('DETALHAMENTO-DO-TRABALHO')['ANO-DE-REALIZACAO']
            numero_autores = 0
            posicao = 0
            autores = []
            for autor in producao.find_all('AUTORES'):
                numero_autores += 1
                nome_autor = autor['NOME-COMPLETO-DO-AUTOR']
                id_autor = autor['NRO-ID-CNPQ']
                if id_autor == self.id:
                    posicao = numero_autores
                autores.append((nome_autor,id_autor))
            if natureza=="RESUMO":
                tipo = "122"
                tipo_descricao = "Trabalhos publicados em anais de eventos - Resumos"
            elif natureza == "COMPLETO":
                tipo = "121"
                tipo_descricao = "Trabalhos publicados em anais de eventos - Trabalhos Completos"
            elif natureza == "RESUMO_EXPANDIDO":
                tipo = "123"
                tipo_descricao = "Trabalhos publicados em anais de eventos - Resumos expandidos"
            else:
                tipo = "12"
                tipo_descricao = "Trabalhos publicados em anais de eventos - " + natureza
                
            self.trabalhos_em_eventos.append((tipo, 
                                              tipo_descricao, 
                                              titulo, 
                                              ano, 
                                              pais, 
                                              idioma, 
                                              meio_de_divulgacao, 
                                              flag_relevancia, 
                                              doi, 
                                              flag_divulgacao_cientifica, 
                                              titulo_ingles, 
                                              internacional, 
                                              nome_evento, 
                                              ano_do_evento, 
                                              numero_autores, 
                                              posicao, 
                                              autores))
            
            self.indicadores_append(tipo, 
                                   tipo_descricao,
                                   ano) 
            
            
    def get_artigos_publicados (self):
        prod = self.soup.find('PRODUCAO-BIBLIOGRAFICA').find('ARTIGOS-PUBLICADOS')
        
        for producao in prod.children:
            tipo = producao.name
            natureza = producao.find('DADOS-BASICOS-DO-ARTIGO')['NATUREZA']
            titulo = producao.find('DADOS-BASICOS-DO-ARTIGO')['TITULO-DO-ARTIGO']
            ano = producao.find('DADOS-BASICOS-DO-ARTIGO')['ANO-DO-ARTIGO']
            pais = producao.find('DADOS-BASICOS-DO-ARTIGO')['PAIS-DE-PUBLICACAO']
            idioma = producao.find('DADOS-BASICOS-DO-ARTIGO')['IDIOMA']
            meio_de_divulgacao = producao.find('DADOS-BASICOS-DO-ARTIGO')['MEIO-DE-DIVULGACAO']
            flag_relevancia = producao.find('DADOS-BASICOS-DO-ARTIGO')['FLAG-RELEVANCIA']
            doi = producao.find('DADOS-BASICOS-DO-ARTIGO')['DOI']
            flag_divulgacao_cientifica = producao.find('DADOS-BASICOS-DO-ARTIGO')['FLAG-DIVULGACAO-CIENTIFICA']
            titulo_ingles = producao.find('DADOS-BASICOS-DO-ARTIGO')['TITULO-DO-ARTIGO-INGLES']
            homepage = producao.find('DADOS-BASICOS-DO-ARTIGO')['HOME-PAGE-DO-TRABALHO']
            
            titulo_periodico = producao.find('DETALHAMENTO-DO-ARTIGO')['TITULO-DO-PERIODICO-OU-REVISTA']
            issn = producao.find('DETALHAMENTO-DO-ARTIGO')['ISSN']

            numero_autores = 0
            posicao = 0
            autores = []
            for autor in producao.find_all('AUTORES'):
                numero_autores += 1
                nome_autor = autor['NOME-COMPLETO-DO-AUTOR']
                id_autor = autor['NRO-ID-CNPQ']
                if id_autor == self.id:
                    posicao = numero_autores
                autores.append((nome_autor,id_autor))
                
            if natureza=="RESUMO":
                tipo = "112"
                tipo_descricao = "Artigo publicado em periódicos - Resumos"
            elif natureza == "COMPLETO":
                tipo = "111"
                tipo_descricao = "Artigo publicado em periódicos - Trabalhos Completos"
            else:
                tipo = "11"
                tipo_descricao = "Artigo publicado em periódicos - " + natureza
            
            areas_do_artigo = []
            for area in producao.find_all('AREAS-DO-CONHECIMENTO'):
                for a in area.children:
                    area_ga = a['NOME-GRANDE-AREA-DO-CONHECIMENTO']
                    area_a = a['NOME-DA-AREA-DO-CONHECIMENTO']
                    area_sa = a['NOME-DA-SUB-AREA-DO-CONHECIMENTO']
                    area_e = a['NOME-DA-ESPECIALIDADE']
                    areas_do_artigo.append ((area_ga, area_a, area_sa, area_e))
                
            self.artigos.append((tipo, 
                                  tipo_descricao, 
                                  titulo, 
                                  ano, 
                                  pais, 
                                  idioma, 
                                  meio_de_divulgacao, 
                                  flag_relevancia, 
                                  doi, 
                                  flag_divulgacao_cientifica, 
                                  titulo_ingles, 
                                  titulo_periodico, 
                                  issn, 
                                  numero_autores, 
                                  posicao, 
                                  autores,
                                  areas_do_artigo
                                 ))
            
            self.indicadores_append(tipo, 
                                       tipo_descricao, 
                                       None) 
            
    def get_livros_capitulos (self):
        prod = self.soup.find('PRODUCAO-BIBLIOGRAFICA').find('LIVROS-E-CAPITULOS').find('LIVROS-PUBLICADOS-OU-ORGANIZADOS')
        
        tipo = prod.name
        for producao in prod.children:
            tipo = "LIVROS-PUBLICADOS-OU-ORGANIZADOS - " + producao.find('DADOS-BASICOS-DO-LIVRO')['TIPO']
            titulo_livro = producao.find('DADOS-BASICOS-DO-LIVRO')['TITULO-DO-LIVRO']
            ano = producao.find('DADOS-BASICOS-DO-LIVRO')['ANO']
            pais = producao.find('DADOS-BASICOS-DO-LIVRO')['PAIS-DE-PUBLICACAO']
            idioma = producao.find('DADOS-BASICOS-DO-LIVRO')['IDIOMA']
            meio_de_divulgacao = producao.find('DADOS-BASICOS-DO-LIVRO')['MEIO-DE-DIVULGACAO']
            flag_relevancia = producao.find('DADOS-BASICOS-DO-LIVRO')['FLAG-RELEVANCIA']
            doi = producao.find('DADOS-BASICOS-DO-LIVRO')['DOI']
            flag_divulgacao_cientifica = producao.find('DADOS-BASICOS-DO-LIVRO')['FLAG-DIVULGACAO-CIENTIFICA']
            titulo_ingles = producao.find('DADOS-BASICOS-DO-LIVRO')['TITULO-DO-LIVRO-INGLES']
            homepage = producao.find('DADOS-BASICOS-DO-LIVRO')['HOME-PAGE-DO-TRABALHO']

            editora = producao.find('DETALHAMENTO-DO-LIVRO')['NOME-DA-EDITORA']
            isbn = producao.find('DETALHAMENTO-DO-LIVRO')['ISBN']

            numero_autores = 0
            posicao = 0
            autores = []
            for autor in producao.find_all('AUTORES'):
                numero_autores += 1
                nome_autor = autor['NOME-COMPLETO-DO-AUTOR']
                id_autor = autor['NRO-ID-CNPQ']
                if id_autor == self.id:
                    posicao = numero_autores
                autores.append((nome_autor,id_autor))

            if tipo=="LIVROS-PUBLICADOS-OU-ORGANIZADOS - LIVRO_PUBLICADO":
                num_tipo = "131"
            elif tipo == "LIVROS-PUBLICADOS-OU-ORGANIZADO - Capítulo de livro publicado":
                num_tipo = "132"
            else:
                num_tipo = "13"

            areas_do_artigo = []
            for area in producao.find_all('AREAS-DO-CONHECIMENTO'):
                for a in area.children:
                    area_ga = a['NOME-GRANDE-AREA-DO-CONHECIMENTO']
                    area_a = a['NOME-DA-AREA-DO-CONHECIMENTO']
                    area_sa = a['NOME-DA-SUB-AREA-DO-CONHECIMENTO']
                    area_e = a['NOME-DA-ESPECIALIDADE']
                    areas_do_artigo.append ((area_ga, area_a, area_sa, area_e))

            self.livros_capitulos.append((num_tipo, 
                                  tipo, 
                                  titulo_livro, 
                                  ano, 
                                  pais, 
                                  idioma, 
                                  meio_de_divulgacao, 
                                  flag_relevancia, 
                                  doi, 
                                  flag_divulgacao_cientifica, 
                                  titulo_ingles, 
                                  homepage,
                                  editora, 
                                  isbn, 
                                  numero_autores, 
                                  posicao, 
                                  autores,
                                  areas_do_artigo
                                 ))

            self.indicadores_append(num_tipo, 
                                       tipo, 
                                       ano) 

        prod = self.soup.find('PRODUCAO-BIBLIOGRAFICA').find('LIVROS-E-CAPITULOS').find('CAPITULOS-DE-LIVROS-PUBLICADOS')
        for producao in prod.children:
            tipo = "CAPITULOS-DE-LIVROS-PUBLICADOS - " + producao.find('DADOS-BASICOS-DO-CAPITULO')['TIPO']
            titulo_livro = producao.find('DETALHAMENTO-DO-CAPITULO')['TITULO-DO-LIVRO']
            ano = producao.find('DADOS-BASICOS-DO-CAPITULO')['ANO']
            pais = producao.find('DADOS-BASICOS-DO-CAPITULO')['PAIS-DE-PUBLICACAO']
            idioma = producao.find('DADOS-BASICOS-DO-CAPITULO')['IDIOMA']
            meio_de_divulgacao = producao.find('DADOS-BASICOS-DO-CAPITULO')['MEIO-DE-DIVULGACAO']
            flag_relevancia = producao.find('DADOS-BASICOS-DO-CAPITULO')['FLAG-RELEVANCIA']
            doi = producao.find('DADOS-BASICOS-DO-CAPITULO')['DOI']
            flag_divulgacao_cientifica = producao.find('DADOS-BASICOS-DO-CAPITULO')['FLAG-DIVULGACAO-CIENTIFICA']
            titulo_ingles = producao.find('DADOS-BASICOS-DO-CAPITULO')['TITULO-DO-CAPITULO-DO-LIVRO-INGLES']
            homepage = producao.find('DADOS-BASICOS-DO-CAPITULO')['HOME-PAGE-DO-TRABALHO']

            editora = producao.find('DETALHAMENTO-DO-CAPITULO')['NOME-DA-EDITORA']
            isbn = producao.find('DETALHAMENTO-DO-CAPITULO')['ISBN']

            numero_autores = 0
            posicao = 0
            autores = []
            for autor in producao.find_all('AUTORES'):
                numero_autores += 1
                nome_autor = autor['NOME-COMPLETO-DO-AUTOR']
                id_autor = autor['NRO-ID-CNPQ']
                if id_autor == self.id:
                    posicao = numero_autores
                autores.append((nome_autor,id_autor))

            if tipo=="LIVROS-PUBLICADOS-OU-ORGANIZADOS - LIVRO_PUBLICADO":
                num_tipo = "131"
            elif tipo == "CAPITULOS-DE-LIVROS-PUBLICADOS - Capítulo de livro publicado":
                num_tipo = "132"
            else:
                num_tipo = "13"

            areas_do_artigo = []
            for area in producao.find_all('AREAS-DO-CONHECIMENTO'):
                for a in area.children:
                    area_ga = a['NOME-GRANDE-AREA-DO-CONHECIMENTO']
                    area_a = a['NOME-DA-AREA-DO-CONHECIMENTO']
                    area_sa = a['NOME-DA-SUB-AREA-DO-CONHECIMENTO']
                    area_e = a['NOME-DA-ESPECIALIDADE']
                    areas_do_artigo.append ((area_ga, area_a, area_sa, area_e))

            self.livros_capitulos.append((num_tipo, 
                                  tipo, 
                                  titulo_livro, 
                                  ano, 
                                  pais, 
                                  idioma, 
                                  meio_de_divulgacao, 
                                  flag_relevancia, 
                                  doi, 
                                  flag_divulgacao_cientifica, 
                                  titulo_ingles, 
                                  homepage,
                                  editora, 
                                  isbn, 
                                  numero_autores, 
                                  posicao, 
                                  autores,
                                  areas_do_artigo
                                 ))

            self.indicadores_append(num_tipo, 
                                       tipo, 
                                       None) 

def get_producao_tecnica (self):
        prod = self.soup.find('PRODUCAO-BIBLIOGRAFICA')
        for producao in prod.children:
            tipo = "CAPITULOS-DE-LIVROS-PUBLICADOS - " + producao.find('DADOS-BASICOS-DO-CAPITULO')['TIPO']
            titulo_livro = producao.find('DETALHAMENTO-DO-CAPITULO')['TITULO-DO-LIVRO']
            ano = producao.find('DADOS-BASICOS-DO-CAPITULO')['ANO']
            pais = producao.find('DADOS-BASICOS-DO-CAPITULO')['PAIS-DE-PUBLICACAO']
            idioma = producao.find('DADOS-BASICOS-DO-CAPITULO')['IDIOMA']
            meio_de_divulgacao = producao.find('DADOS-BASICOS-DO-CAPITULO')['MEIO-DE-DIVULGACAO']
            flag_relevancia = producao.find('DADOS-BASICOS-DO-CAPITULO')['FLAG-RELEVANCIA']
            doi = producao.find('DADOS-BASICOS-DO-CAPITULO')['DOI']
            flag_divulgacao_cientifica = producao.find('DADOS-BASICOS-DO-CAPITULO')['FLAG-DIVULGACAO-CIENTIFICA']
            titulo_ingles = producao.find('DADOS-BASICOS-DO-CAPITULO')['TITULO-DO-CAPITULO-DO-LIVRO-INGLES']
            homepage = producao.find('DADOS-BASICOS-DO-CAPITULO')['HOME-PAGE-DO-TRABALHO']

            editora = producao.find('DETALHAMENTO-DO-CAPITULO')['NOME-DA-EDITORA']
            isbn = producao.find('DETALHAMENTO-DO-CAPITULO')['ISBN']

            numero_autores = 0
            posicao = 0
            autores = []
            for autor in producao.find_all('AUTORES'):
                numero_autores += 1
                nome_autor = autor['NOME-COMPLETO-DO-AUTOR']
                id_autor = autor['NRO-ID-CNPQ']
                if id_autor == self.id:
                    posicao = numero_autores
                autores.append((nome_autor,id_autor))

            if tipo=="LIVROS-PUBLICADOS-OU-ORGANIZADOS - LIVRO_PUBLICADO":
                num_tipo = "131"
            elif tipo == "CAPITULOS-DE-LIVROS-PUBLICADOS - Capítulo de livro publicado":
                num_tipo = "132"
            else:
                num_tipo = "13"

            areas_do_artigo = []
            for area in producao.find_all('AREAS-DO-CONHECIMENTO'):
                for a in area.children:
                    area_ga = a['NOME-GRANDE-AREA-DO-CONHECIMENTO']
                    area_a = a['NOME-DA-AREA-DO-CONHECIMENTO']
                    area_sa = a['NOME-DA-SUB-AREA-DO-CONHECIMENTO']
                    area_e = a['NOME-DA-ESPECIALIDADE']
                    areas_do_artigo.append ((area_ga, area_a, area_sa, area_e))

            self.livros_capitulos.append((num_tipo, 
                                  tipo, 
                                  titulo_livro, 
                                  ano, 
                                  pais, 
                                  idioma, 
                                  meio_de_divulgacao, 
                                  flag_relevancia, 
                                  doi, 
                                  flag_divulgacao_cientifica, 
                                  titulo_ingles, 
                                  homepage,
                                  editora, 
                                  isbn, 
                                  numero_autores, 
                                  posicao, 
                                  autores,
                                  areas_do_artigo
                                 ))

            self.indicadores_append(num_tipo, 
                                       tipo, 
                                       None) 
    