from bs4 import BeautifulSoup, Tag
from datetime import date, datetime
import pandas, collections
from collections import OrderedDict

from sqlalchemy import false

class Indicadores:

    todos_indicadores = pandas.DataFrame

    def __init__ (self, xml, id = None):
        self.xml = xml
        self.id = id
        self.nome_completo = None
        self.nacionalidade = None
        self.CPF = None
        self.data_nascimento = None
        self.sexo = None
        self.data_atualizacao = None
        self.areas_do_conhecimento = [('Grande Área', 'Área', 'Sub-Área', 'Especialidade')]

        self.lattes = {}
        self.soup = BeautifulSoup(self.xml, "xml")
        self.indicadores = []
        self.get_id()

    def get_id (self):
        if not (
                type(self.xml) == BeautifulSoup or
                type(self.xml) == Tag ):
            self.xml = BeautifulSoup(self.xml, "xml")
        if self.id == None:
            self.id = self.soup.find('CURRICULO-VITAE')['NUMERO-IDENTIFICADOR']
        data = self.soup.find('CURRICULO-VITAE').get('DATA-ATUALIZACAO')
        hora = self.soup.find('CURRICULO-VITAE').get('HORA-ATUALIZACAO')
        self.data_atualizacao = datetime.strptime(data + hora, '%d%m%Y%H%M%S')
        self.nome_completo = self.soup.find('DADOS-GERAIS').get('NOME-COMPLETO')
        self.nacionalidade = self.soup.find('DADOS-GERAIS').get('NACIONALIDADE')
        #self.CPF = self.soup.find('DADOS-GERAIS').get('CPF')
        #self.data_nascimento = datetime.strptime(self.soup.find('DADOS-GERAIS').get('DATA-NASCIMENTO'], '%d%m%Y')
        #self.sexo = self.soup.find('DADOS-GERAIS').get('SEXO')
        #self.raca = self.soup.find('DADOS-GERAIS').get('RACA-OU-COR')
        
    def get_indicadores (self):
        self.get_areas_atuacao()
        self.get_formacao()
        self.get_atuacao_profissional()
        self.get_trabalhos_eventos()
        self.get_producao_tecnica()
        self.get_outra_producao()
        self.get_dados_complementares()
        # self.get_all()

    def indicadores_append (self, descricao, qty, ano):
        if ano == None or ano == '': 
            ano = 0
        existe = False
        for item in self.indicadores:
            if (item['id'] == self.id and
                item['tipo'] == descricao and
                item['ano'] == int(ano)
                ):
                item['qty'] += 1
                existe = True
        if not existe:
            mydict = {
                'id': self.id,
                'tipo': descricao,
                'ano': int(ano),
                'qty': qty,
            }
            self.indicadores.append(mydict)


    def get_all(self, xml = None, nivel = 0):
        dado={}   
        if xml == None:
            xml = self.xml
            if xml == None:
                return None
        if not (
                type(xml) == BeautifulSoup or
                type(xml) == Tag ):
            xml = BeautifulSoup(xml, "xml")
 
        if not xml.find('CURRICULO-VITAE') == None:
            xml = xml.find('CURRICULO-VITAE')

        nome_indicador = xml.name


        # Verifica se os filhos não são detalhamentos do pai
        detalhamento = False
        for child in xml.children:
            child_name = child.name
            if (not child_name == None and 
                    (child_name[0:14] == 'DADOS-BASICOS' or
                    child_name[0:13] == 'DETALHAMENTO-' or
                    child_name == 'AUTORES' or
                    child_name == "PALAVRAS-CHAVE" or
                    child_name == "AREAS-DO-CONHECIMENTO" or
                    child_name == "SETORES-DE-ATIVIDADE" or
                    child_name == "INFORMACOES-ADICIONAIS" or
                    child_name == 'INFORMACOES-ADICIONAIS' or
                    child_name == 'INFORMACOES-ADICIONAIS-INSTITUICOES' or
                    child_name == 'INFORMACOES-ADICIONAIS-CURSOS' 
                    )):
                detalhamento = True
                continue

        #Se houver detalhamento, pega.
        if detalhamento:
            
            #1. Pegar autores, se existirem
            autores = []
            num_autores = 0
            posicao_autor = 0
            for autor in xml.find_all('AUTORES'):
                num_autores += 1
                if autor.get("NRO-ID-CNPQ") == self.id:
                    posicao_autor = num_autores
                for (key, value) in xml.attrs.items():
                    try:
                        dado[key.lower()].append(value)
                    except:
                        dado[key.lower()] = [value]
                        # if key.lower() in dado:
                        #     dado[key.lower()] = [dado[key.lower()]]
                        #     dado[key.lower()].append(value)
                        # else:
                        #     dado[key.lower()] = value
                autores.append(list(autor.attrs.items()))
            if len(autores) > 0:
                dado['numero-autores'] = [num_autores]
                dado['posicao-autor'] = [posicao_autor]
                dado['autores'] = autores
            
            #2 Pegar palavras-chave, se existirem.
            palavras_chaves = []
            for palavra in xml.find_all('PALAVRAS-CHAVE'):
                palavras_chaves.append(list(palavra.attrs.values()))
            if len(palavras_chaves) > 0:
                dado['palavras-chave'] = palavras_chaves
                
            #3 Pegar áreas de atuação, se existirem
            areas = []
            for area in xml.find_all('AREAS-DO-CONHECIMENTO'):
                for a in area.children:
                    area_ga = a.find('NOME-GRANDE-AREA-DO-CONHECIMENTO')
                    area_a = a.find('NOME-DA-AREA-DO-CONHECIMENTO')
                    area_sa = a.find('NOME-DA-SUB-AREA-DO-CONHECIMENTO')
                    area_e = a.find('NOME-DA-ESPECIALIDADE')
                    areas.append ((area_ga, area_a, area_sa, area_e))
            if len(areas) > 0:
                dado['areas-do-conhecimento'] = areas
                        
            #4 Setores de Atividade
            setores = []
            for setor in xml.find_all('SETORES-DE-ATIVIDADE'):
                setores.append(list(setor.attrs.values()))
            if len(setores) > 0:
                    dado['setores-de-atividade'] = setores
                    
            #5 Informações adicionais
            informacoes = []
            for palavra in xml.find_all('INFORMACOES-ADICIONAIS'):
                informacoes.append(list(palavra.attrs.values()))
            if len(informacoes) > 0:
                    dado['informacoes-adicionais'] = informacoes
                    
            #6 Pegar outras informações
            for child in xml.children:
                child_name = child.name
                if child_name in [
                        'AUTORES',
                        'PALAVRAS-CHAVE',
                        'AREAS-DO-CONHECIMENTO',
                        'SETORES-DE-ATIVIDADE',
                        'INFORMACOES-ADICIONAIS',
                        'INFORMACOES-ADICIONAIS-INSTITUICOES',
                        'INFORMACOES-ADICIONAIS-CURSOS',
                        'SISTEMA-ORIGEM-XML',
                        '[document] - '
                        ]:
                    continue
                try:
                    for (key, value) in child.attrs.items():
                        try:
                            dado[key.lower()].append(value)
                        except:
                            dado[key.lower()] = [value]
                            # if key.lower() in dado:
                            #     dado[key.lower()] = [dado[key.lower()]]
                            #     dado[key.lower()].append(value)
                            # else:
                            #     if key in ('AUTORES',
                            #         'PALAVRAS-CHAVE',
                            #         'AREAS-DO-CONHECIMENTO',
                            #         'SETORES-DE-ATIVIDADE',):
                            #         dado[key.lower()] = [value]
                            #     else:
                            #         dado[key.lower()] = value
                    try:
                        for child2 in child.children:
                            child_name = child2.name
                            if child_name in [
                                    'AUTORES',
                                    'PALAVRAS-CHAVE',
                                    'AREAS-DO-CONHECIMENTO',
                                    'SETORES-DE-ATIVIDADE',
                                    'INFORMACOES-ADICIONAIS',
                                    ]:
                                continue
                            for (key, value) in child2.attrs.items():
                                try:
                                    dado[key.lower()].append(value)
                                except:
                                    dado[key.lower()] = [value]
                    except:
                        pass
                except:
                    pass

        #Pega outros atributos do XML
        for (key, value) in xml.attrs.items():
                dado[key.lower()] = [value]

        #Pega o ano, se houver           
        try:
            if not dado.get('ano') == None:
                ano = dado.get('ano')[0]
            elif not dado.get('ano-de-conclusao') == None:
                ano = dado.get('ano-de-conclusao')[0]
            elif not dado.get('ano-da-obra-de-referencia') == None:
                ano = dado.get('ano-da-obra-de-referencia')[0]
            elif not dado.get('ano-de-obtencao-do-titulo') ==None:
                ano = dado.get('ano-de-obtencao-do-titulo')[0]
            elif not dado.get('ano-fim') == None:
                ano = dado.get('ano-fim')[0]
            elif not dado.get('ano-de-realizacao') == None:
                ano = dado.get('ano-de-realizacao')[0]
            elif not dado.get('ano-do-artigo') == None:
                ano = dado.get('ano-do-artigo')[0]
            elif not dado.get('ano-do-texto') == None:
                ano = dado.get('ano-do-texto')[0]
            elif not dado.get('ano-desenvolvimento') == None:
                ano = dado.get('ano-desenvolvimento')[0]
            elif not dado.get('ano-solicitacao') == None:
                ano = dado.get('ano-solicitacao')[0]
            elif not dado.get('ano-da-obra') == None:
                ano = dado.get('ano-da-obra') [0]
            else:
                ano = None
            if not ano==None and int(ano) > 0:
                dado['ano'] = [int(ano)]
                self.indicadores_append(nome_indicador, 1, ano)
                if not dado.get('numero-autores') == None:
                    #print((1/int(dado.get('numero-autores'))))
                    self.indicadores_append(nome_indicador + ' - INVERSO-DE-AUTORES', (1/int(dado.get('numero-autores'))), ano)
                if not dado.get('posicao-autor') == None:
                    #print(dado.get('posicao-autor'))
                    self.indicadores_append(nome_indicador + ' - POSIÇÃO-AUTOR', dado.get('posicao-autor'), ano)                    
        except:
            pass

        #coloca o tipo de indicador nos dados
        parent = xml.parent
        pais = xml.name
        while not parent == None:
            if not pais == '':
                pais = parent.name + ', ' + pais 
            else:
                pais = parent.name
            parent = parent.parent
        
        dado['tipo-indicador'] = [pais]

        #atualiza a variável Indicador.lattes, exceto se só houver o 'tipo-indicador' nos dados
        if len(dado) > 1:
            try:
                self.lattes[nome_indicador].append(dado)
            except:
                self.lattes[nome_indicador] = [dado]
                # if nome_indicador in self.lattes:
                #     self.lattes[nome_indicador] = [self.lattes[nome_indicador]]
                #     self.lattes[nome_indicador].append(dado)
                # else:
                #     self.lattes[nome_indicador] = dado
                
        #Continua, exceto para detalhamentos, que já devem ter sido pegos        
        if not detalhamento:

            for child in xml.children:
                self.get_all(child, nivel + 1)
                    
    def get_publicacoes (self):

        def return_first_element_of(x):
            if x == None : return None
            elif isinstance(x, list): return x[0]
            elif isinstance(x, OrderedDict): return x[x.keys()[0]]
            else: return x

        publicações = []

        for k in self.lattes.keys():
            for k2 in self.lattes[k]:
                sequencia = k2.get('sequencia-producao')
                mesmo = False
                for indicador in k2:
                    if (indicador[:6]=='titulo' and
                            indicador.find('ingl') == -1 and 
                            not k2.get(indicador)==[''] and
                            not mesmo):
                        publicação = {}
                        if sequencia == k2.get('sequencia-producao'): mesmo = True
                        publicação['id'] = self.id
                        publicação['tipo'] = (return_first_element_of(indicador))
                        publicação['titulo'] = (return_first_element_of(k2.get(indicador)))
                        publicação['ano'] = (return_first_element_of(k2.get('ano')))
                        publicação['tipo_indicador'] = (return_first_element_of(k2.get('tipo-indicador')))
                        publicação['doi'] = (return_first_element_of(k2.get('doi')))
                        publicação['issn'] = (return_first_element_of(k2.get('issn')))
                        publicação['isbn'] = (return_first_element_of(k2.get('isbn')))
                        for indicador2 in k2:
                            if (indicador2[:6]=='titulo' and
                                    indicador2.find('ingl') == -1 and 
                                    not k2.get(indicador2)==[''] and
                                    not indicador2 == indicador
                                    ):
                                publicação['tipo_segundo_titulo'] = indicador2
                                publicação['segundo_titulo'] = return_first_element_of(k2.get(indicador2))
                        publicações.append(publicação)
        return publicações