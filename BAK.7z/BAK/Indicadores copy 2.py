from bs4 import BeautifulSoup
from datetime import date, datetime
import pandas

class Indicadores:

    indicadores = pandas.DataFrame()


    def __init__ (self, xml, id = None):
        self.xml = xml
        self.id = id
        self.nome_completo = None
        self.nacionalidade = None
        self.CPF = None
        self.data_nascimento = None
        self.sexo = None
        self.data_atualizacao = None
        self.areas_do_conhecimento = [('Grande Área', 'Área', 'Sub-Área', 'Especialidade')]

        self.lattes = {}
        self.soup = BeautifulSoup(self.xml, "xml")
        self.get_id()

    def get_id (self):
        try:
            self.id = self.soup.find('CURRICULO-VITAE')['NUMERO-IDENTIFICADOR']
        except:
            print ('ERRO!')
        data = self.soup.find('CURRICULO-VITAE').get('DATA-ATUALIZACAO')
        hora = self.soup.find('CURRICULO-VITAE').get('HORA-ATUALIZACAO')
        if not data == None and not hora == None:
            self.data_atualizacao = datetime.strptime(data + hora, '%d%m%Y%H%M%S')
        self.nome_completo = self.soup.find('DADOS-GERAIS').get('NOME-COMPLETO')
        self.nacionalidade = self.soup.find('DADOS-GERAIS').get('NACIONALIDADE')
        #self.CPF = self.soup.find('DADOS-GERAIS').get('CPF')
        #self.data_nascimento = datetime.strptime(self.soup.find('DADOS-GERAIS').get('DATA-NASCIMENTO'], '%d%m%Y')
        #self.sexo = self.soup.find('DADOS-GERAIS').get('SEXO')
        #self.raca = self.soup.find('DADOS-GERAIS').get('RACA-OU-COR')
        
    def get_indicadores (self):
        self.get_areas_atuacao()
        self.get_formacao()
        self.get_atuacao_profissional()
        self.get_trabalhos_eventos()
        self.get_producao_tecnica()
        self.get_outra_producao()
        self.get_dados_complementares()
        # self.get_all()

    def indicadores_append (self, descricao, ano):
        if ano == None or ano == '': 
            ano = 0
        mydict = pandas.DataFrame({
            'Id': [self.id],
            'Tipo': [descricao],
            'Ano': [int(ano)]
        })
        Indicadores.indicadores = Indicadores.indicadores.append(mydict)


    def get_areas_atuacao(self):
        areas = self.soup.find('DADOS-GERAIS').find_all('AREA-DE-ATUACAO')
        for area in areas:
            area_ga = area.get('NOME-GRANDE-AREA-DO-CONHECIMENTO')
            area_a = area.get('NOME-DA-AREA-DO-CONHECIMENTO')
            area_sa = area.get('NOME-DA-SUB-AREA-DO-CONHECIMENTO')
            area_e = area.get('NOME-DA-ESPECIALIDADE')
            self.areas_do_conhecimento.append ((area_ga, area_a, area_sa, area_e))
        if len(self.areas_do_conhecimento) <= 1:
            self.areas_do_conhecimento.append ((None, None, None, None))     
        self.lattes['AREA-DE-ATUACAO']  =  self.areas_do_conhecimento

    def get_dados_basicos_do_trabalho (self, xml, variable):
        if not xml == None:
            d = xml.find('DADOS-BASICOS-DO-TRABALHO')
            variable["NATUREZA"] = d["NATUREZA"]
            variable["TITULO-DO-TRABALHO"] = d["TITULO-DO-TRABALHO"]
            variable["ANO-DO-TRABALHO"] = d["ANO-DO-TRABALHO"]
            variable["PAIS-DO-EVENTO"] = d["PAIS-DO-EVENTO"]
            variable["IDIOMA"] = d["IDIOMA"]
            variable["MEIO-DE-DIVULGACAO"] = d["MEIO-DE-DIVULGACAO"]
            variable["HOME-PAGE-DO-TRABALHO"] = d["HOME-PAGE-DO-TRABALHO"]
            variable["FLAG-RELEVANCIA"] = d["FLAG-RELEVANCIA"]
            variable["DOI"] = d["DOI"]
            variable["TITULO-DO-TRABALHO-INGLES"] = d["TITULO-DO-TRABALHO-INGLES"]
            variable["FLAG-DIVULGACAO-CIENTIFICA"] = d["FLAG-DIVULGACAO-CIENTIFICA"]
        else:
            return None


    def get_detalhamento_do_trabalho (self, xml, variable):
        if not xml == None:
            detalhamento_do_trabalho = []
            d = xml.find('DETALHAMENTO-DO-TRABALHO')
            variable["CLASSIFICACAO-DO-EVENTO"] = d["CLASSIFICACAO-DO-EVENTO"]
            variable["NOME-DO-EVENTO"] = d["NOME-DO-EVENTO"]
            variable["CIDADE-DO-EVENTO"] = d["CIDADE-DO-EVENTO"]
            variable["ANO-DE-REALIZACAO"] = d["ANO-DE-REALIZACAO"]
            variable["TITULO-DOS-ANAIS-OU-PROCEEDINGS"] = d["TITULO-DOS-ANAIS-OU-PROCEEDINGS"]
            variable["VOLUME"] = d["VOLUME"]
            variable["FASCICULO"] = d["FASCICULO"]
            variable["SERIE"] = d["SERIE"]
            variable["PAGINA-INICIAL"] = d["PAGINA-INICIAL"]
            variable["PAGINA-FINAL"] = d["PAGINA-FINAL"]
            variable["ISBN"] = d["ISBN"]
            variable["NOME-DA-EDITORA"] = d["NOME-DA-EDITORA"]
            variable["CIDADE-DA-EDITORA"] = d["CIDADE-DA-EDITORA"]
            # variable["NOME-DO-EVENTO-INGLES"] = d["NOME-DO-EVENTO-INGLES"]
        else:
            return None

    def get_autores (self, xml):
        if not xml == None:
            autores = []
            num_autores = 0
            posicao_autor = 0
            for d in xml.find_all('AUTORES'):
                dado = d.attrs
                num_autores += 1
                try:
                    if d["NRO-ID-CNPQ"] == self.id:
                        posicao_autor = num_autores
                except:
                    pass
                autores.append(dado)
            return posicao_autor, num_autores, autores
        else:
            return None

    def get_palavras_chave (self, xml):
        if not xml == None:
            palavras_chaves = []
            for palavra in xml.find_all('PALAVRAS-CHAVE'):
                palavras_chaves.append(list(palavra.attrs.values()))
            return palavras_chaves
        else:
            return None

    def get_areas_do_conhecimento (self, xml):
        if not xml == None:
            areas = []
            for area in xml.find_all('AREAS-DO-CONHECIMENTO'):
                for a in area.children:
                    area_ga = a.find('NOME-GRANDE-AREA-DO-CONHECIMENTO')
                    area_a = a.find('NOME-DA-AREA-DO-CONHECIMENTO')
                    area_sa = a.find('NOME-DA-SUB-AREA-DO-CONHECIMENTO')
                    area_e = a.find('NOME-DA-ESPECIALIDADE')
                    areas.append ((area_ga, area_a, area_sa, area_e))
            return areas
        else:
            return None

    def get_setores_de_atividade (self, xml):
        if not xml == None:
            setores = []
            for setor in xml.find_all('SETORES-DE-ATIVIDADE'):
                setores.append(list(setor.attrs.values()))
            return setores
        else:
            return None

    def get_informacoes_adicionais (self, xml):
        if not xml == None:
            informacoes = []
            for palavra in xml.find_all('INFORMACOES-ADICIONAIS'):
                informacoes.append(list(palavra.attrs.values()))
            return informacoes    
        else:
            return None

    def get_dados_basicos_do_artigo(self, xml, variable):
        if not xml == None:
            d = xml.find('DADOS-BASICOS-DO-ARTIGO')
            variable["NATUREZA"] = d["NATUREZA"]
            variable["TITULO-DO-ARTIGO"] = d["TITULO-DO-ARTIGO"]
            variable["ANO-DO-ARTIGO"] = d["ANO-DO-ARTIGO"]
            variable["PAIS-DE-PUBLICACAO"] = d["PAIS-DE-PUBLICACAO"]
            variable["IDIOMA"] = d["IDIOMA"]
            variable["MEIO-DE-DIVULGACAO"] = d["MEIO-DE-DIVULGACAO"]
            variable["HOME-PAGE-DO-TRABALHO"] = d["HOME-PAGE-DO-TRABALHO"]
            variable["FLAG-RELEVANCIA"] = d["FLAG-RELEVANCIA"]
            variable["DOI"] = d["DOI"]
            variable["TITULO-DO-ARTIGO-INGLES"] = d["TITULO-DO-ARTIGO-INGLES"]
            variable["FLAG-DIVULGACAO-CIENTIFICA"] = d["FLAG-DIVULGACAO-CIENTIFICA"]
        else:
            return None

    def get_detalhamento_do_artigo (self, xml, variable):
        if not xml == None:
            d = xml.find('DETALHAMENTO-DO-ARTIGO')
            variable["TITULO-DO-PERIODICO-OU-REVISTA"] = d["TITULO-DO-PERIODICO-OU-REVISTA"]
            variable["ISSN"] = d["ISSN"]
            variable["VOLUME"] = d["VOLUME"]
            variable["FASCICULO"] = d["FASCICULO"]
            variable["SERIE"] = d["SERIE"]
            variable["PAGINA-INICIAL"] = d["PAGINA-INICIAL"]
            variable["PAGINA-FINAL"] = d["PAGINA-FINAL"]
            variable["LOCAL-DE-PUBLICACAO"] = d["LOCAL-DE-PUBLICACAO"]
        else:
            return None

    def get_dados_basicos_do_livro (self, xml, variable):
        if not xml == None:
            d = xml.find('DADOS-BASICOS-DO-LIVRO')
            variable["TIPO"] = d["TIPO"]
            variable["NATUREZA"] = d["NATUREZA"]
            variable["TITULO-DO-LIVRO"] = d["TITULO-DO-LIVRO"]
            variable["ANO"] = d["ANO"]
            variable["PAIS-DE-PUBLICACAO"] = d["PAIS-DE-PUBLICACAO"]
            variable["IDIOMA"] = d["IDIOMA"]
            variable["MEIO-DE-DIVULGACAO"] = d["MEIO-DE-DIVULGACAO"]
            variable["HOME-PAGE-DO-TRABALHO"] = d["HOME-PAGE-DO-TRABALHO"]
            variable["FLAG-RELEVANCIA"] = d["FLAG-RELEVANCIA"]
            variable["DOI"] = d["DOI"]
            variable["TITULO-DO-LIVRO-INGLES"] = d["TITULO-DO-LIVRO-INGLES"]
            variable["FLAG-DIVULGACAO-CIENTIFICA"] = d["FLAG-DIVULGACAO-CIENTIFICA"]
        else:
            return None

    def get_detalhamento_do_livro (self, xml, variable):
        if not xml == None:
            d = xml.find('DETALHAMENTO-DO-LIVRO')
            variable["NUMERO-DE-VOLUMES"] = d["NUMERO-DE-VOLUMES"]
            variable["NUMERO-DE-PAGINAS"] = d["NUMERO-DE-PAGINAS"]
            variable["ISBN"] = d["ISBN"]
            variable["NUMERO-DA-EDICAO-REVISAO"] = d["NUMERO-DA-EDICAO-REVISAO"]
            variable["NUMERO-DA-SERIE"] = d["NUMERO-DA-SERIE"]
            variable["CIDADE-DA-EDITORA"] = d["CIDADE-DA-EDITORA"]
            variable["NOME-DA-EDITORA"] = d["NOME-DA-EDITORA"]


    def get_formacao(self):
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        cursos_tecnicos_profissionalizantes = []
        if not formacoes == None:
            formacoes = formacoes.find_all('CURSO-TECNICO-PROFISSIONALIZANTE')
            for curso in formacoes:
                curso_tecnico = {
                    "SEQUENCIA-FORMACAO": curso["SEQUENCIA-FORMACAO"],
                    "NIVEL": curso["NIVEL"],
                    "CODIGO-INSTITUICAO": curso["CODIGO-INSTITUICAO"],
                    "NOME-INSTITUICAO": curso["NOME-INSTITUICAO"],
                    # "CODIGO-ORGAO": curso["CODIGO-ORGAO"],
                    # "NOME-ORGAO": curso["NOME-ORGAO"],
                    "CODIGO-CURSO": curso["CODIGO-CURSO"],
                    "NOME-CURSO": curso["NOME-CURSO"],
                    "STATUS-DO-CURSO": curso["STATUS-DO-CURSO"],
                    "ANO-DE-INICIO": curso["ANO-DE-INICIO"],
                    "ANO-DE-CONCLUSAO": curso["ANO-DE-CONCLUSAO"],
                    "FLAG-BOLSA": curso["FLAG-BOLSA"],
                    "CODIGO-AGENCIA-FINANCIADORA": curso["CODIGO-AGENCIA-FINANCIADORA"],
                    "NOME-AGENCIA": curso["NOME-AGENCIA"],
                    "NOME-CURSO-INGLES": curso["NOME-CURSO-INGLES"],
                }
                cursos_tecnicos_profissionalizantes.append(curso_tecnico)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('Formação nível Médio: curso Técnico/profissionalizante', curso_tecnico['ANO-DE-CONCLUSAO'])
        self.lattes['CURSO-TECNICO-PROFISSIONALIZANTE'] = cursos_tecnicos_profissionalizantes

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        ensinos_fundamentais = []
        if not formacoes == None:
            formacoes = formacoes.find_all('ENSINO-FUNDAMENTAL-PRIMEIRO-GRAU')
            for curso in formacoes:
                ensino_fundamental = {
                    "SEQUENCIA-FORMACAO":curso["SEQUENCIA-FORMACAO"],
                    "NIVEL":curso["NIVEL"],
                    "CODIGO-INSTITUICAO":curso["CODIGO-INSTITUICAO"],
                    "NOME-INSTITUICAO":curso["NOME-INSTITUICAO"],
                    "STATUS-DO-CURSO":curso["STATUS-DO-CURSO"],
                    "ANO-DE-INICIO":curso["ANO-DE-INICIO"],
                    "ANO-DE-CONCLUSAO":curso["ANO-DE-CONCLUSAO"]
                    }
                ensinos_fundamentais.append(ensino_fundamental)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('Formação nível Fundamental - Primeiro grau', ensino_fundamental['ANO-DE-CONCLUSAO'])
        self.lattes['ENSINO-FUNDAMENTAL-PRIMEIRO-GRAU'] = ensinos_fundamentais

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        ensinos_medios = []
        if not formacoes == None:
            formacoes = formacoes.find_all('ENSINO-MEDIO-SEGUNDO-GRAU')
            for curso in formacoes:
                ensino_medio = {
                "SEQUENCIA-FORMACAO": curso["SEQUENCIA-FORMACAO"],
                "NIVEL": curso["NIVEL"],
                "CODIGO-INSTITUICAO": curso["CODIGO-INSTITUICAO"],
                "NOME-INSTITUICAO": curso["NOME-INSTITUICAO"],
                "STATUS-DO-CURSO": curso["STATUS-DO-CURSO"],
                "ANO-DE-INICIO": curso["ANO-DE-INICIO"],
                "ANO-DE-CONCLUSAO": curso["ANO-DE-CONCLUSAO"],
                }
                ensinos_medios.append(ensino_medio)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('Formação nível Médio - Segundo Grau', ensino_medio['ANO-DE-CONCLUSAO'])
        self.lattes['ENSINO-MEDIO-SEGUNDO-GRAU'] = ensinos_medios

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        graduacoes = []
        if not formacoes == None:
            formacoes = formacoes.find_all('GRADUACAO')
            for curso in formacoes:
                graduacao = curso.attrs
                graduacoes.append(graduacao)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('Formação nível Superior - Graduação', graduacao['ANO-DE-CONCLUSAO'])
        self.lattes['GRADUACAO'] = graduacoes

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        aperfeicoamentos = []
        if not formacoes == None:
            formacoes = formacoes.find_all('APERFEICOAMENTO')
            for curso in formacoes:
                aperfeicoamento = curso.attrs
                aperfeicoamentos.append(aperfeicoamento)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('Formação nível Superior - Aperfeiçoamento', aperfeicoamento['ANO-DE-CONCLUSAO'])
            self.lattes['APERFEICOAMENTO'] = aperfeicoamentos

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        especializacoes = []
        if not formacoes == None:
            formacoes = formacoes.find_all('ESPECIALIZACAO')
            for curso in formacoes:
                especializacao = curso.attrs
                especializacoes.append(especializacao)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('Formação nível Superior - Especialização', especializacao['ANO-DE-CONCLUSAO'])
        self.lattes['ESPECIALIZACAO'] = especializacoes

        # MESTRADOS

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        mestrados = []
        if not formacoes == None:
            formacoes = formacoes.find_all('MESTRADO')
            for curso in formacoes:
                mestrado = curso.attrs
                mestrado['PALAVRAS-CHAVE'] = self.get_palavras_chave(curso.find('PALAVRAS-CHAVE'))
                mestrado['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(curso.find('AREAS-DO-CONHECIMENTO'))
                mestrado['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(curso.find('SETORES-DE-ATIVIDADE'))
                
                mestrados.append(mestrado)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('Formação nível Superior - Mestrado', mestrado['ANO-DE-CONCLUSAO'])
        self.lattes['MESTRADO'] = mestrados

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        mestrados_profissionalizantes = []
        if not formacoes == None:
            formacoes = formacoes.find_all('MESTRADO-PROFISSIONALIZANTE')
            for curso in formacoes:
                mestrado_profissionalizante = curso.attrs
                mestrado_profissionalizante['PALAVRAS-CHAVE'] = self.get_palavras_chave(curso.find('PALAVRAS-CHAVE'))
                mestrado_profissionalizante['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(curso.find('AREAS-DO-CONHECIMENTO'))
                mestrado_profissionalizante['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(curso.find('SETORES-DE-ATIVIDADE'))
                
                mestrados_profissionalizantes.append(mestrado_profissionalizante)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('Formação nível Superior - mestrado pRofissionalizante', mestrado_profissionalizante['ANO-DE-CONCLUSAO'])
            self.lattes['MESTRADO-PROFISSIONALIZANTE'] = mestrados_profissionalizantes

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        doutorados = []
        if not formacoes == None:
            formacoes = formacoes.find_all('DOUTORADO')
            for curso in formacoes:
                doutorado = curso.attrs
                doutorado['PALAVRAS-CHAVE'] = self.get_palavras_chave(curso.find('PALAVRAS-CHAVE'))
                doutorado['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(curso.find('AREAS-DO-CONHECIMENTO'))
                doutorado['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(curso.find('SETORES-DE-ATIVIDADE'))
                
                doutorados.append(doutorado)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('Formação nível Superior - Doutorado', doutorado['ANO-DE-CONCLUSAO'])
        self.lattes['DOUTORADO'] = doutorados

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        residencias_medicas = []
        if not formacoes == None:
            formacoes = formacoes.find_all('RESIDENCIA-MEDICA')
            for curso in formacoes:
                residencia = curso.attrs
                residencia['PALAVRAS-CHAVE'] = self.get_palavras_chave(curso.find('PALAVRAS-CHAVE'))
                residencia['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(curso.find('AREAS-DO-CONHECIMENTO'))
                residencia['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(curso.find('SETORES-DE-ATIVIDADE'))
                
                residencias_medicas.append(residencia)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('Formação nível Superior - Residência Médica', residencia['ANO-DE-CONCLUSAO'])
        self.lattes['RESIDENCIA-MEDICA'] = residencias_medicas

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        livre_docencias = []
        if not formacoes == None:
            formacoes = formacoes.find_all('LIVRE-DOCENCIA')
            for curso in formacoes:
                docencia = curso.attrs
                docencia['PALAVRAS-CHAVE'] = self.get_palavras_chave(curso.find('PALAVRAS-CHAVE'))
                docencia['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(curso.find('AREAS-DO-CONHECIMENTO'))
                docencia['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(curso.find('SETORES-DE-ATIVIDADE'))
                
                livre_docencias.append(docencia)
                if curso.get('STATUS-DO-CURSO') == 'CONCLUIDO':
                    self.indicadores_append('Formação nível Superior - Livre Docência', docencia['ANO-DE-CONCLUSAO'])
        self.lattes['LIVRE-DOCENCIA'] = livre_docencias

        
        formacoes = self.soup.find('FORMACAO-ACADEMICA-TITULACAO')
        pos_doutorados = []
        if not formacoes == None:
            formacoes = formacoes.find_all('POS-DOUTORADO')
            for curso in formacoes:
                pd = curso.attrs
                pd['PALAVRAS-CHAVE'] = self.get_palavras_chave(curso.find('PALAVRAS-CHAVE'))
                pd['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(curso.find('AREAS-DO-CONHECIMENTO'))
                pd['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(curso.find('SETORES-DE-ATIVIDADE'))
                
                pos_doutorados.append(pd)
                if curso['STATUS-DO-CURSO'] == 'CONCLUIDO':
                    self.indicadores_append('Formação nível Superior - Pós-Doutorado', pd['ANO-DE-CONCLUSAO'])
        self.lattes['POS-DOUTORADO'] = pos_doutorados

            
    def get_atuacao_profissional (self):

        vinculos = []
        sopa = self.soup.find('ATUACOES-PROFISSIONAIS')
        if not sopa == None:
            sopa = sopa.find_all('VINCULOS')
            for atuacao in sopa:
                vinculo =  atuacao.attrs
                vinculos.append(vinculo)
                self.indicadores_append('atuação Profissional, Vínculo - ' + atuacao.get("TIPO-DE-VINCULO"), atuacao.get("ANO-FIM"))
        self.lattes['VINCULOS'] = vinculos

        atividades_direcao_administracao = []
        sopa = self.soup.find('ATIVIDADES-DE-DIRECAO-E-ADMINISTRACAO')
        if not sopa == None:
            sopa = sopa.find_all('DIRECAO-E-ADMINISTRACAO')
            for atuacao in sopa:
                atividade_direcao = atuacao.attrs
                atividades_direcao_administracao.append(atividade_direcao)
                self.indicadores_append('atuação Profissional, Direção e administração + primeira letras do tipo de direção', atuacao.get("ANO-FIM"))
        self.lattes['DIRECAO-E-ADMINISTRACAO'] = atividades_direcao_administracao

        atividades_pesquisa_desenvolviemnto = []
        sopa = self.soup.find('ATIVIDADES-DE-PESQUISA-E-DESENVOLVIMENTO')
        if not sopa == None:
            sopa = sopa.find_all('PESQUISA-E-DESENVOLVIMENTO')
            for atuacao in sopa:
                atividade_desenvolvimento = atuacao.attrs
                linhas_de_pesquisa = []
                for linha in atuacao.find_all('LINHA-DE-PESQUISA'):
                    linha_pesquisa = linha.attrs
                    
                    linha_pesquisa['PALAVRAS-CHAVE'] = self.get_palavras_chave(linha.find('PALAVRAS-CHAVE'))
                    linha_pesquisa['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(linha.find('AREAS-DO-CONHECIMENTO'))
                    linha_pesquisa['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(linha.find('SETORES-DE-ATIVIDADE'))

                    linhas_de_pesquisa.append(linha_pesquisa)
                    if linha["FLAG-LINHA-DE-PESQUISA-ATIVA"] == "ATUAL":
                        self.indicadores_append('atuação Profissional, atividades de Pesquisa e desenvolvimento, Linhas de Pesquisa', None)
                
                atividade_desenvolvimento["LINHA-DE-PESQUISA"] = linhas_de_pesquisa
                atividades_pesquisa_desenvolviemnto.append(atividade_desenvolvimento)
        self.lattes['PESQUISA-E-DESENVOLVIMENTO'] = atividades_pesquisa_desenvolviemnto

        atividades_ensino = []
        sopa = self.soup.find('ATIVIDADES-DE-ENSINO')
        if not sopa == None:
            sopa = sopa.find_all('ENSINO')
            for atuacao in sopa:
                atividade_ensino = atuacao.attrs
                disciplinas_ministradas = []
                for disciplina in atuacao.find_all('DISCIPLINA'):
                    disciplinas_ministradas.append (disciplina.string)
                    self.indicadores_append('atuação Profissional, atividades de Ensino - Disciplinas', atuacao.get("ANO-FIM"))
                atividade_ensino['DISCIPLINAS'] = disciplinas_ministradas
                atividades_ensino.append(atividade_ensino)
        self.lattes['ENSINO'] = atividades_ensino
  

        atividades_estagio = []
        sopa = self.soup.find('ATIVIDADES-DE-ESTAGIO')
        if not sopa == None:
            sopa = sopa.find_all('ESTAGIO')
            for atuacao in sopa:
                atua = atuacao.attrs
                atividades_estagio.append(atua)
                self.indicadores_append('atuação Profissional - atividades de Estágio - Estágio', atuacao.get("ANO-FIM"))
        self.lattes['ESTAGIO'] = atividades_estagio 


        atividades_tecnico_especializado = []
        sopa = self.soup.find('ATIVIDADES-DE-SERVICO-TECNICO-ESPECIALIZADO')
        if not sopa == None:
            sopa = sopa.find_all('SERVICO-TECNICO-ESPECIALIZADO')
            for atuacao in sopa:
                atua = atuacao.attrs
                atividades_tecnico_especializado.append(atua)
                self.indicadores_append('atuação Profissional - atividades de Técnico-especializados - Serviço técnico-epecializado', atuacao.get("ANO-FIM"))
        self.lattes['SERVICO-TECNICO-ESPECIALIZADO'] = atividades_tecnico_especializado

        atividades_extensao_universitaria = []
        sopa = self.soup.find('ATIVIDADES-DE-EXTENSAO-UNIVERSITARIA')
        if not sopa == None:
            sopa = sopa.find_all('EXTENSAO-UNIVERSITARIA')
            for atuacao in sopa:
                atua = atuacao.attrs
                atividades_extensao_universitaria.append(atua)
                self.indicadores_append('atuação Profissional - atividades de Extensão Universitária - extensão universitária', atuacao.get("ANO-FIM"))
        self.lattes['EXTENSAO-UNIVERSITARIA'] = atividades_extensao_universitaria


        atividades_treinamento_ministrado = []
        sopa = self.soup.find('ATIVIDADES-DE-TREINAMENTO-MINISTRADO')
        if not sopa == None:
            sopa = sopa.find_all('TREINAMENTO-MINISTRADO')
            for atuacao in sopa:
                atua = atuacao.attrs
                atua['TREINAMENTOS'] = [t.string for t in atuacao.find_all('TREINAMENTO')]
                atividades_treinamento_ministrado.append(atua)
                self.indicadores_append('atuação Profissional - atividades de Treinamento Ministrado - treinamento ministrado', atuacao.get("ANO-FIM"))
        self.lattes['TREINAMENTO-MINISTRADO'] = atividades_treinamento_ministrado

        atividades_outras_tecnico_cientifica = []
        sopa = self.soup.find('OUTRAS-ATIVIDADES-TECNICO-CIENTIFICA')
        if not sopa == None:
            sopa = sopa.find_all('OUTRA-ATIVIDADE-TECNICO-CIENTIFICA')
            for atuacao in sopa:
                atua = atuacao.attrs
                atividades_outras_tecnico_cientifica.append(atua)
                self.indicadores_append('atuação Profissional - Outras Atividades técnico-científicas', atuacao.get("ANO-FIM"))
        self.lattes['OUTRA-ATIVIDADE-TECNICO-CIENTIFICA'] = atividades_outras_tecnico_cientifica


        atividades_conselho_comissao_consultoria = []
        sopa = self.soup.find('ATIVIDADES-DE-CONSELHO-COMISSAO-E-CONSULTORIA')
        if not sopa == None:
            sopa = sopa.find_all('CONSELHO-COMISSAO-E-CONSULTORIA')
            for atuacao in sopa:
                atua = atuacao.attrs
                atividades_conselho_comissao_consultoria.append(atua)
                self.indicadores_append('atuação Profissional - atividades de Conselho, Comissão e Consultoria', atuacao.get("ANO-FIM"))
        self.lattes['CONSELHO-COMISSAO-E-CONSULTORIA'] = atividades_conselho_comissao_consultoria

        areas_atuacao = []
        sopa = self.soup.find('AREAS-DE-ATUACAO')
        if not sopa == None:
            sopa = sopa.find_all('AREA-DE-ATUACAO')
            for atuacao in sopa:
                atua = atuacao.attrs
                areas_atuacao.append(atua)
                self.indicadores_append('atuação Profissional - Áreas de Atuação', None)
        self.lattes['AREAS-DE-ATUACAO'] = areas_atuacao


        idiomas = []
        sopa = self.soup.find('IDIOMAS')
        if not sopa == None:
            sopa = sopa.find_all('IDIOMA')
            for atuacao in sopa:
                atua = atuacao.attrs
                idiomas.append(atua)
                self.indicadores_append('atuação Profissional - Idiomas', None)
        self.lattes['IDIOMA'] = idiomas

        premios_titulos = []
        sopa = self.soup.find('PREMIOS-TITULOS')
        if not sopa == None:
            sopa = sopa.find_all('PREMIO-TITULO')
            for atuacao in sopa:
                atua = atuacao.attrs
                premios_titulos.append(atua)
                self.indicadores_append('atuação Profissional - Prêmios e Títulos', atua['ANO-DA-PREMIACAO'])
        self.lattes['PREMIOS-TITULOS'] = premios_titulos


        atividades_participacao_projeto = []
        sopa = self.soup.find('ATIVIDADES-DE-PARTICIPACAO-EM-PROJETO')
        if not sopa == None:
            sopa = sopa.find_all('PARTICIPACAO-EM-PROJETO')
            for atuacao in sopa:
                atua = atuacao.attrs
                atividades_participacao_projeto.append(atua)

                self.projeto_pesquisa = []
                projetos_pesquisa = atuacao.find_all('PROJETO-DE-PESQUISA')
                projeto = {}
                for p in projetos_pesquisa:
                    projeto = p.attrs

                    integrantes = []
                    sopa_equipe = p.find('EQUIPE-DO-PROJETO')
                    if not sopa_equipe == None:
                        for equipe in sopa_equipe.find_all('INTEGRANTES-DO-PROJETO'):
                            integrante = equipe.attrs
                            integrantes.append(integrante)
                            if equipe.get("NRO-ID-CNPQ") == self.id:
                                self.indicadores_append('atuação Profissional - Participação em Projeto de pesquisa - Integrante em projeto', atua.get("ANO-FIM"))
                        projeto['INTEGRANTES'] = integrantes

                    financiadores = []
                    sopa_financiador = p.find('FINANCIADORES-DO-PROJETO')
                    if not sopa_financiador == None:
                        for financiador in sopa_financiador.find_all('FINANCIADOR-DO-PROJETO'):
                            finan = financiador.attrs
                            financiadores.append(finan)
                            self.indicadores_append('atuação Profissional - Participação em Projeto de pesquisa - financiador no projeto do pesquisador', atua.get("ANO-FIM"))
                        projeto['FINANCIADORES'] = financiadores

                    producoes = []
                    sopa_producao = p.find('PRODUCOES-CT-DO-PROJETO')
                    if not sopa_producao == None:
                        for produtor in sopa_producao.find_all('PRODUCAO-CT-DO-PROJETO'):
                            prod = produtor.attrs
                            producoes.append(prod)
                            self.indicadores_append('atuação Profissional - Participação em Projeto de pesquisa - pRodução em C&T', None)
                        projeto['PRODUCOES'] = producoes

                    orientacoes = []
                    sopa_orientacao = p.find('ORIENTACOES')
                    if not sopa_orientacao == None:
                        for orientacao in sopa_orientacao.find_all('ORIENTACAO'):
                            orien = orientacao.attrs
                            orientacoes.append(orien)
                            self.indicadores_append('atuação Profissional - Participação em Projeto de pesquisa - Orientacoes', None)
                        projeto['ORIENTACOES'] = orientacoes
                atua['PROJETO'] = projeto
                atividades_participacao_projeto.append(atua)
        self.lattes['PARTICIPACAO-EM-PROJETO'] = atividades_participacao_projeto

    def get_trabalhos_eventos_bak (self):
        producao_bibliografica = self.soup.find('PRODUCAO-BIBLIOGRAFICA')

        #"TRABALHOS-EM-EVENTOS"
        trabalhos_em_eventos = []
        sopa = self.soup.find('TRABALHOS-EM-EVENTOS')
        if not sopa == None:
            for producao in sopa.find_all('TRABALHO-EM-EVENTOS'):
                atua = {"SEQUENCIA-PRODUCAO": producao['SEQUENCIA-PRODUCAO']}
                self.get_dados_basicos_do_trabalho (producao, atua)
                self.get_detalhamento_do_trabalho(producao, atua)
                atua['POSICAO_AUTOR'], atua['NUMERO_AUTORES'], atua['AUTORES'] = self.get_autores(producao)
                atua['PALAVRAS-CHAVE'] = self.get_palavras_chave(producao)
                atua['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(producao)
                atua['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(producao)
                atua['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(producao)

                self.indicadores_append('produção Bibliográfica - travalhos em Eventos - ' + atua['NATUREZA'], atua['ANO-DO-TRABALHO'])
                trabalhos_em_eventos.append(atua)
        self.lattes['TRABALHOS-EM-EVENTOS'] = trabalhos_em_eventos


        #"ARTIGOS-PUBLICADOS"
        artigos_publicados = []
        sopa = self.soup.find('ARTIGOS-PUBLICADOS')
        if not sopa == None:
            for producao in sopa.find_all('ARTIGO-PUBLICADO'):
                atua = {
                "SEQUENCIA-PRODUCAO": producao["SEQUENCIA-PRODUCAO"],
                "ORDEM-IMPORTANCIA": producao["ORDEM-IMPORTANCIA"],
                }
                self.get_dados_basicos_do_artigo (producao, atua)
                self.get_detalhamento_do_artigo(producao, atua)
                atua['POSICAO_AUTOR'], atua['NUMERO_AUTORES'], atua['AUTORES'] = self.get_autores(producao)
                atua['PALAVRAS-CHAVE'] = self.get_palavras_chave(producao)
                atua['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(producao)
                atua['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(producao)
                atua['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(producao)

                self.indicadores_append('produção Bibliográfica - Artigos publicados - ' + atua['NATUREZA'], atua['ANO-DO-ARTIGO'])
                artigos_publicados.append(atua)
        self.lattes['ARTIGO-PUBLICADO'] = artigos_publicados

        #"ARTIGOS-ACEITOS-PARA-PUBLICACAO"
        artigos_aceitos = []
        sopa = self.soup.find('ARTIGOS-ACEITOS-PARA-PUBLICACAO')
        if not sopa == None:
            for producao in sopa.find_all('ARTIGO-ACEITO-PARA-PUBLICACAO'):
                atua = {
                    "SEQUENCIA-PRODUCAO": producao["SEQUENCIA-PRODUCAO"],
                }

                self.get_dados_basicos_do_artigo (producao, atua)
                self.get_detalhamento_do_artigo(producao, atua)
                atua['POSICAO_AUTOR'], atua['NUMERO_AUTORES'], atua['AUTORES'] = self.get_autores(producao)
                atua['PALAVRAS-CHAVE'] = self.get_palavras_chave(producao)
                atua['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(producao)
                atua['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(producao)
                atua['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(producao)

                self.indicadores_append('produção Bibliográfica - Artigos Aceitos para publicação', atua['ANO-DO-ARTIGO'])
                artigos_aceitos.append(atua)
        self.lattes['ARTIGO-ACEITO-PARA-PUBLICACAO'] = artigos_aceitos


        # "LIVROS-PUBLICADOS-OU-ORGANIZADOS"
        livros = []
        sopa = self.soup.find('LIVROS-PUBLICADOS-OU-ORGANIZADOSO')
        if not sopa == None:
            for producao in sopa.find_all('LIVRO-PUBLICADO-OU-ORGANIZADO'):
                atua = {
                    "SEQUENCIA-PRODUCAO": producao["SEQUENCIA-PRODUCAO"]
                }
                self.get_dados_basicos_do_livro (producao, atua)
                self.get_detalhamento_do_livro (producao, atua)
                atua['POSICAO_AUTOR'], atua['NUMERO_AUTORES'], atua['AUTORES'] = self.get_autores(producao)
                atua['PALAVRAS-CHAVE'] = self.get_palavras_chave(producao)
                atua['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(producao)
                atua['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(producao)
                atua['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(producao)

                self.indicadores_append('produção Bibliográfica - Livros publicados ou organizados - ' + atua['NATUREZA'], atua['ANO'])
                livros.append(atua)
        self.lattes['LIVRO-PUBLICADO-OU-ORGANIZADO'] = livros


        # "CAPITULOS-DE-LIVROS-PUBLICADOS"~
        capitulos = []
        sopa = self.soup.find('CAPITULO-DE-LIVRO-PUBLICADO')
        if not sopa == None:
            for producao in sopa.find_all('LIVRO-PUBLICADO-OU-ORGANIZADO'):
                atua = {"SEQUENCIA-PRODUCAO": producao["SEQUENCIA-PRODUCAO"]}

                dados = producao.find("DADOS-BASICOS-DO-CAPITULO")
                atua["TIPO"] = dados["TIPO"]
                atua["TITULO-DO-CAPITULO-DO-LIVRO"] = dados["TITULO-DO-CAPITULO-DO-LIVRO"]
                atua["ANO"] = dados["ANO"]
                atua["PAIS-DE-PUBLICACAO"] = dados["PAIS-DE-PUBLICACAO"]
                atua["IDIOMA"] = dados["IDIOMA"]
                atua["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
                atua["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
                atua["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
                atua["DOI"] = dados["DOI"]
                atua["TITULO-DO-CAPITULO-DO-LIVRO-INGLES"] = dados["TITULO-DO-CAPITULO-DO-LIVRO-INGLES"]
                atua["FLAG-DIVULGACAO-CIENTIFICA"] = dados["FLAG-DIVULGACAO-CIENTIFICA"]

                dados = producao.find("DETALHAMENTO-DO-CAPITULO")
                atua["TITULO-DO-LIVRO"] = dados["TITULO-DO-LIVRO"]
                atua["NUMERO-DE-VOLUMES"] = dados["NUMERO-DE-VOLUMES"]
                atua["PAGINA-INICIAL"] = dados["PAGINA-INICIAL"]
                atua["PAGINA-FINAL"] = dados["PAGINA-FINAL"]
                atua["ISBN"] = dados["ISBN"]
                atua["ORGANIZADORES"] = dados["ORGANIZADORES"]
                atua["NUMERO-DA-EDICAO-REVISAO"] = dados["NUMERO-DA-EDICAO-REVISAO"]
                atua["NUMERO-DA-SERIE"] = dados["NUMERO-DA-SERIE"]
                atua["CIDADE-DA-EDITORA"] = dados["CIDADE-DA-EDITORA"]
                atua["NOME-DA-EDITORA"] = dados["NOME-DA-EDITORA"]

                atua['POSICAO_AUTOR'], atua['NUMERO_AUTORES'], atua['AUTORES'] = self.get_autores(producao)
                atua['PALAVRAS-CHAVE'] = self.get_palavras_chave(producao)
                atua['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(producao)
                atua['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(producao)
                atua['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(producao)
                self.indicadores_append('produção Bibliográfica - Capítulo de livro publicado - ' + atua['NATUREZA'], atua['ANO'])
                capitulos.append(atua)
        self.lattes['LIVRO-PUBLICADO-OU-ORGANIZADO'] = capitulos


        # "TEXTOS-EM-JORNAIS-OU-REVISTAS"
        jornais_revistas = []
        sopa = self.soup.find('TEXTOS-EM-JORNAIS-OU-REVISTAS')
        if not sopa == None:
            for producao in sopa.find_all('TEXTO-EM-JORNAL-OU-REVISTA'):
                atua = {"SEQUENCIA-PRODUCAO": producao["SEQUENCIA-PRODUCAO"]}

                dados = producao.find('DADOS-BASICOS-DO-TEXTO')
                atua["NATUREZA"] = dados["NATUREZA"]
                atua["TITULO-DO-TEXTO"] = dados["TITULO-DO-TEXTO"]
                atua["ANO-DO-TEXTO"] = dados["ANO-DO-TEXTO"]
                atua["PAIS-DE-PUBLICACAO"] = dados["PAIS-DE-PUBLICACAO"]
                atua["IDIOMA"] = dados["IDIOMA"]
                atua["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
                atua["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
                atua["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
                atua["DOI"] = dados["DOI"]
                atua["TITULO-DO-TEXTO-INGLES"] = dados["TITULO-DO-TEXTO-INGLES"]
                atua["FLAG-DIVULGACAO-CIENTIFICA"] = dados["FLAG-DIVULGACAO-CIENTIFICA"]

                dados = producao.find('DETALHAMENTO-DO-TEXTO')
                atua["TITULO-DO-JORNAL-OU-REVISTA"] = dados["TITULO-DO-JORNAL-OU-REVISTA"]
                atua["ISSN"] = dados["ISSN"]
                # atua["FORMATO-DATA-DE-PUBLICACAO"   ] = dados["FORMATO-DATA-DE-PUBLICACAO"   ]
                atua["DATA-DE-PUBLICACAO"] = dados["DATA-DE-PUBLICACAO"]
                atua["VOLUME"] = dados["VOLUME"]
                atua["PAGINA-INICIAL"] = dados["PAGINA-INICIAL"]
                atua["PAGINA-FINAL"] = dados["PAGINA-FINAL"]
                atua["LOCAL-DE-PUBLICACAO"] = dados["LOCAL-DE-PUBLICACAO"]

                atua['POSICAO_AUTOR'], atua['NUMERO_AUTORES'], atua['AUTORES'] = self.get_autores(producao)
                atua['PALAVRAS-CHAVE'] = self.get_palavras_chave(producao)
                atua['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(producao)
                atua['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(producao)
                atua['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(producao)
                self.indicadores_append('produção Bibliográfica - Textos em jornais ou revistas - ' + atua['NATUREZA'], atua['ANO-DO-TEXTO'])
                jornais_revistas.append(atua)
        self.lattes['TEXTO-EM-JORNAL-OU-REVISTA'] = jornais_revistas


        #"DEMAIS-TIPOS-DE-PRODUCAO-BIBLIOGRAFICA"
        demais_producoes = []
        sopa = self.soup.find('DEMAIS-TIPOS-DE-PRODUCAO-BIBLIOGRAFICA')
        if not sopa == None:
            for outra in sopa.find_all('OUTRA-PRODUCAO-BIBLIOGRAFICA'):
                outra_producao = {}
                outra_producao["SEQUENCIA-PRODUCAO"] = outra["SEQUENCIA-PRODUCAO"]

                dados = outra.find("DADOS-BASICOS-DE-OUTRA-PRODUCAO")
                outra_producao["NATUREZA"] = dados["NATUREZA"]
                outra_producao["TITULO"] = dados["TITULO"]
                outra_producao["ANO"] = dados["ANO"]
                outra_producao["PAIS-DE-PUBLICACAO"] = dados["PAIS-DE-PUBLICACAO"]
                outra_producao["IDIOMA"] = dados["IDIOMA"]
                outra_producao["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
                outra_producao["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
                outra_producao["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
                outra_producao["DOI"] = dados["DOI"]
                outra_producao["TITULO-INGLES"] = dados["TITULO-INGLES"]
                outra_producao["NATUREZA-INGLES"] = dados["NATUREZA-INGLES"]
                outra_producao["FLAG-DIVULGACAO-CIENTIFICA"] = dados["FLAG-DIVULGACAO-CIENTIFICA"]

                dados = outra.find("DETALHAMENTO-DE-OUTRA-PRODUCAO")
                outra_producao["EDITORA"] = dados["EDITORA"]
                outra_producao["CIDADE-DA-EDITORA"] = dados["CIDADE-DA-EDITORA"]
                outra_producao["NUMERO-DE-PAGINAS"] = dados["NUMERO-DE-PAGINAS"]
                outra_producao["ISSN-ISBN"] = dados["ISSN-ISBN"]

                outra_producao['POSICAO_AUTOR'], outra_producao['NUMERO_AUTORES'], outra_producao['AUTORES'] = self.get_autores(outra)
                outra_producao['PALAVRAS-CHAVE'] = self.get_palavras_chave(outra)
                outra_producao['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(outra)
                outra_producao['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(outra)
                outra_producao['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(outra)
                
                self.indicadores_append('produção Bibliográfica - Outra produção bibliográfica - ' + outra_producao['NATUREZA'], outra_producao['ANO'])
                demais_producoes.append(outra_producao)

            self.lattes['OUTRA-PRODUCAO-BIBLIOGRAFICA'] = demais_producoes
        

            partituras = []
            for partitura in sopa.find_all('PARTITURA-MUSICAL'):
                outra_producao_partitura = {}
                outra_producao_partitura["SEQUENCIA-PRODUCAO"] = outra["SEQUENCIA-PRODUCAO"]

                dados = partitura.find('DADOS-BASICOS-DA-PARTITURA')
                outra_producao_partitura["NATUREZA"] = dados["NATUREZA"]
                outra_producao_partitura["TITULO"] = dados["TITULO"]
                outra_producao_partitura["ANO"] = dados["ANO"]
                outra_producao_partitura["PAIS-DE-PUBLICACAO"] = dados["PAIS-DE-PUBLICACAO"]
                outra_producao_partitura["IDIOMA"] = dados["IDIOMA"]
                outra_producao_partitura["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
                outra_producao_partitura["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
                outra_producao_partitura["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
                outra_producao_partitura["DOI"] = dados["DOI"]
                outra_producao_partitura["TITULO-INGLES"] = dados["TITULO-INGLES"]

                dados = partitura.find('DETALHAMENTO-DA-PARTITURA')
                outra_producao_partitura["FORMACAO-INSTRUMENTAL"] = dados["FORMACAO-INSTRUMENTAL"]
                outra_producao_partitura["EDITORA"] = dados["EDITORA"]
                outra_producao_partitura["CIDADE-DA-EDITORA"] = dados["CIDADE-DA-EDITORA"]
                outra_producao_partitura["NUMERO-DE-PAGINAS"] = dados["NUMERO-DE-PAGINAS"]
                outra_producao_partitura["NUMERO-DO-CATALOGO"] = dados["NUMERO-DO-CATALOGO"]


                outra_producao_partitura['POSICAO_AUTOR'], outra_producao_partitura['NUMERO_AUTORES'], outra_producao_partitura['AUTORES'] = self.get_autores(partitura)
                outra_producao_partitura['PALAVRAS-CHAVE'] = self.get_palavras_chave(partitura)
                outra_producao_partitura['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(partitura)
                outra_producao_partitura['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(partitura)
                outra_producao_partitura['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(partitura)
                
                self.indicadores_append('produção Bibliográfica - Partitura - ' + outra_producao_partitura['NATUREZA'], outra_producao_partitura['ANO'])
                partituras.append(outra_producao_partitura)
            self.lattes['PARTITURA-MUSICAL'] = partituras


            prefacios = []
            for prefacio in sopa.find_all('PREFACIO-POSFACIO'):
                outra_producao = {}
                outra_producao["SEQUENCIA-PRODUCAO"] = prefacio["SEQUENCIA-PRODUCAO"]

                dados = prefacio.find("DADOS-BASICOS-DO-PREFACIO-POSFACIO")
                outra_producao["TIPO"] = dados["TIPO"]
                outra_producao["NATUREZA"] = dados["NATUREZA"]
                outra_producao["TITULO"] = dados["TITULO"]
                outra_producao["ANO"] = dados["ANO"]
                outra_producao["PAIS-DE-PUBLICACAO"] = dados["PAIS-DE-PUBLICACAO"]
                outra_producao["IDIOMA"] = dados["IDIOMA"]
                outra_producao["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
                outra_producao["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
                outra_producao["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
                outra_producao["DOI"] = dados["DOI"]
                outra_producao["TITULO-INGLES"] = dados["TITULO-INGLES"]

                dados = prefacio.find("DETALHAMENTO-DO-PREFACIO-POSFACIO")
                outra_producao["NOME-DO-AUTOR-DA-PUBLICACAO"] = dados["NOME-DO-AUTOR-DA-PUBLICACAO"]
                outra_producao["TITULO-DA-PUBLICACAO"] = dados["TITULO-DA-PUBLICACAO"]
                outra_producao["ISSN-ISBN"] = dados["ISSN-ISBN"]
                outra_producao["NUMERO-DA-EDICAO-REVISAO"] = dados["NUMERO-DA-EDICAO-REVISAO"]
                outra_producao["VOLUME"] = dados["VOLUME"]
                outra_producao["SERIE"] = dados["SERIE"]
                outra_producao["FASCICULO"] = dados["FASCICULO"]
                outra_producao["EDITORA-DO-PREFACIO-POSFACIO"] = dados["EDITORA-DO-PREFACIO-POSFACIO"]
                outra_producao["CIDADE-DA-EDITORA"] = dados["CIDADE-DA-EDITORA"]

                outra_producao['POSICAO_AUTOR'], outra_producao['NUMERO_AUTORES'], outra_producao['AUTORES'] = self.get_autores(prefacio)
                outra_producao['PALAVRAS-CHAVE'] = self.get_palavras_chave(prefacio)
                outra_producao['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(prefacio)
                outra_producao['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(prefacio)
                outra_producao['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(prefacio)
                
                self.indicadores_append('produção Bibliográfica - preFácio / posFácio - ' + outra_producao['NATUREZA'], outra_producao['ANO'])
                prefacios.append(outra_producao)
            self.lattes['PREFACIO-POSFACIO'] = prefacios

            traducoes = []
            for traducao in sopa.find_all('TRADUCAO'):
                outra_producao = {}
                outra_producao["SEQUENCIA-PRODUCAO"] = prefacio["SEQUENCIA-PRODUCAO"]

                dados = traducao.find("DADOS-BASICOS-DA-TRADUCAO")
                outra_producao["NATUREZA"] = dados["NATUREZA"]
                outra_producao["TITULO"] = dados["TITULO"]
                outra_producao["ANO"] = dados["ANO"]
                outra_producao["PAIS-DE-PUBLICACAO"] = dados["PAIS-DE-PUBLICACAO"]
                outra_producao["IDIOMA"] = dados["IDIOMA"]
                outra_producao["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
                outra_producao["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
                outra_producao["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
                outra_producao["DOI"] = dados["DOI"]
                outra_producao["TITULO-INGLES"] = dados["TITULO-INGLES"]

                dados = traducao.find("DETALHAMENTO-DA-TRADUCAO")
                outra_producao["NOME-DO-AUTOR-TRADUZIDO"] = dados["NOME-DO-AUTOR-TRADUZIDO"]
                outra_producao["TITULO-DA-OBRA-ORIGINAL"] = dados["TITULO-DA-OBRA-ORIGINAL"]
                outra_producao["ISSN-ISBN"] = dados["ISSN-ISBN"]
                outra_producao["IDIOMA-DA-OBRA-ORIGINAL"] = dados["IDIOMA-DA-OBRA-ORIGINAL"]
                outra_producao["EDITORA-DA-TRADUCAO"] = dados["EDITORA-DA-TRADUCAO"]
                outra_producao["CIDADE-DA-EDITORA"] = dados["CIDADE-DA-EDITORA"]
                outra_producao["NUMERO-DE-PAGINAS"] = dados["NUMERO-DE-PAGINAS"]
                outra_producao["NUMERO-DA-EDICAO-REVISAO"] = dados["NUMERO-DA-EDICAO-REVISAO"]
                outra_producao["VOLUME"] = dados["VOLUME"]
                outra_producao["FASCICULO"] = dados["FASCICULO"]
                outra_producao["SERIE"] = dados["SERIE"]
  
                outra_producao['POSICAO_AUTOR'], outra_producao['NUMERO_AUTORES'], outra_producao['AUTORES'] = self.get_autores(traducao)
                outra_producao['PALAVRAS-CHAVE'] = self.get_palavras_chave(traducao)
                outra_producao['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(traducao)
                outra_producao['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(traducao)
                outra_producao['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(traducao)
                
                self.indicadores_append('produção Bibliográfica - tRadução - ' + outra_producao_partitura['NATUREZA'], outra_producao_partitura['ANO'])
                traducoes.append(outra_producao_partitura)
            self.lattes['TRADUCAO'] = traducoes

    def get_registro_patente(self, xml):
        sopa = xml.get('REGISTRO-OU-PATENTE')
        if not sopa == None:
            patente = {
                "CODIGO-DO-REGISTRO-OU-PATENTE": sopa["CODIGO-DO-REGISTRO-OU-PATENTE"],
                "TITULO-PATENTE": sopa["TITULO-PATENTE"],
                "FORMATO-DATA-PEDIDO": sopa["FORMATO-DATA-PEDIDO"],
                "DATA-PEDIDO-DE-DEPOSITO": sopa["DATA-PEDIDO-DE-DEPOSITO"],
                "DATA-DE-PEDIDO-DE-EXAME": sopa["DATA-DE-PEDIDO-DE-EXAME"],
                "DATA-DE-CONCESSAO": sopa["DATA-DE-CONCESSAO"],
                "INSTITUICAO-DEPOSITO-REGISTRO": sopa["INSTITUICAO-DEPOSITO-REGISTRO"],
                "NUMERO-DEPOSITO-PCT": sopa["NUMERO-DEPOSITO-PCT"],
                "FORMATO-DATA-DEPOSITO-PCT": sopa["FORMATO-DATA-DEPOSITO-PCT"],
                "DATA-DEPOSITO-PCT": sopa["DATA-DEPOSITO-PCT"],
                "NOME-DO-TITULAR": sopa["NOME-DO-TITULAR"],
                "NOME-DO-DEPOSITANTE": sopa["NOME-DO-DEPOSITANTE"],
            }
            return (patente)
        else:
            return None
        
    def get_historico_situacoes_patente (self, xml):
        if not xml == None:
            for historico in xml.get_all('HISTORICO-SITUACOES-PATENTE'):
                historico_situacoes_patente = {
                    "DESCRICAO-SITUACAO-PATENTE": historico["DESCRICAO-SITUACAO-PATENTE"],
                    "FORMATO-DATA-SITUACAO-PATENTE": historico["FORMATO-DATA-SITUACAO-PATENTE"],
                    "DATA-SITUACAO-PATENTE": historico["DATA-SITUACAO-PATENTE"],
                    "STATUS-SITUACAO-PATENTE": historico["STATUS-SITUACAO-PATENTE"],
                }

    def get_dados_basicos_cultivar (self, xml, variable):
        if xml == None:
            return None
        dados = xml.find('DADOS-BASICOS-DA-CULTIVAR')
        variable["DENOMINACAO"] = dados["DENOMINACAO"]
        variable["ANO-SOLICITACAO"] = dados["ANO-SOLICITACAO"]
        variable["PAIS"] = dados["PAIS"]
        variable["DENOMINACAO-INGLES"] = dados["DENOMINACAO-INGLES"]
        variable["FLAG-POTENCIAL-INOVACAO"] = dados["FLAG-POTENCIAL-INOVACAO"]

    def get_detalhamento_cultivar (self, xml, variable):
            if xml == None:
                return None
            dados = xml.find('DETALHAMENTO-DA-CULTIVAR')
            variable["FINALIDADE"] = dados["FINALIDADE"]
            variable["INSTITUICAO-FINANCIADORA"] = dados["INSTITUICAO-FINANCIADORA"]
            variable["FINALIDADE-INGLES"] = dados["FINALIDADE-INGLES"]

    def get_producao_tecnica_bak (self):
        sopa = self.soup.find('PRODUCAO-TECNICA')
        if sopa == None:
            return None

        # <xs:element minOccurs="0" maxOccurs="unbounded" ref="SOFTWARE"/>

        softwares = []
        for software in sopa.find_all('SOFTWARE'):
            soft = {}
            soft['SEQUENCIA-PRODUCAO'] = software['SEQUENCIA-PRODUCAO']

            software_dados = software.find("DADOS-BASICOS-DO-SOFTWARE")
            soft["NATUREZA"] = software_dados["NATUREZA"]
            soft["TITULO-DO-SOFTWARE"] = software_dados["TITULO-DO-SOFTWARE"]
            soft["ANO"] = software_dados["ANO"]
            soft["PAIS"] = software_dados["PAIS"]
            soft["IDIOMA"] = software_dados["IDIOMA"]
            soft["MEIO-DE-DIVULGACAO"] = software_dados["MEIO-DE-DIVULGACAO"]
            soft["HOME-PAGE-DO-TRABALHO"] = software_dados["HOME-PAGE-DO-TRABALHO"]
            soft["FLAG-RELEVANCIA"] = software_dados["FLAG-RELEVANCIA"]
            soft["DOI"] = software_dados["DOI"]
            soft["TITULO-DO-SOFTWARE-INGLES"] = software_dados["TITULO-DO-SOFTWARE-INGLES"]
            soft["FLAG-DIVULGACAO-CIENTIFICA"] = software_dados["FLAG-DIVULGACAO-CIENTIFICA"]
            soft["FLAG-POTENCIAL-INOVACAO"] = software_dados["FLAG-POTENCIAL-INOVACAO"]

            software_dados = software.find("DETALHAMENTO-DO-SOFTWARE")
            soft["FINALIDADE"] = software_dados["FINALIDADE"]
            soft["PLATAFORMA"] = software_dados["PLATAFORMA"]
            soft["AMBIENTE"] = software_dados["AMBIENTE"]
            soft["DISPONIBILIDADE"] = software_dados["DISPONIBILIDADE"]
            soft["INSTITUICAO-FINANCIADORA"] = software_dados["INSTITUICAO-FINANCIADORA"]
            soft["FINALIDADE-INGLES"] = software_dados["FINALIDADE-INGLES"]

            soft['REGISTRO-OU-PATENTE'] = self.get_registro_patente(software)
            soft['POSICAO_AUTOR'], soft['NUMERO_AUTORES'], soft['AUTORES'] = self.get_autores(software)
            soft['PALAVRAS-CHAVE'] = self.get_palavras_chave(software)
            soft['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(software)
            soft['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(software)
            soft['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(software)
            
            self.indicadores_append('produção Técnica - Software - ' + soft['NATUREZA'], soft['ANO'])
            softwares.append(soft)
        self.lattes['SOFTWARE'] = softwares

        # <xs:element minOccurs="0" maxOccurs="unbounded" ref="PRODUTO-TECNOLOGICO"/>
        produtos_tecnologicos = []
        for produto in sopa.find_all('PRODUTO-TECNOLOGICO'):
            prod = {}
            prod["SEQUENCIA-PRODUCAO"] = produto["SEQUENCIA-PRODUCAO"]

            dados = produto.find('DADOS-BASICOS-DO-PRODUTO-TECNOLOGICO')
            prod["TIPO-PRODUTO"] = dados["TIPO-PRODUTO"]
            prod["NATUREZA"] = dados["NATUREZA"]
            prod["TITULO-DO-PRODUTO"] = dados["TITULO-DO-PRODUTO"]
            prod["ANO"] = dados["ANO"]
            prod["PAIS"] = dados["PAIS"]
            prod["IDIOMA"] = dados["IDIOMA"]
            prod["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
            prod["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
            prod["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            prod["DOI"] = dados["DOI"]
            prod["TITULO-DO-PRODUTO-INGLES"] = dados["TITULO-DO-PRODUTO-INGLES"]
            prod["FLAG-POTENCIAL-INOVACAO"] = dados["FLAG-POTENCIAL-INOVACAO"]

            dados = produto.find('DETALHAMENTO-DO-PRODUTO-TECNOLOGICO')
            prod["FINALIDADE"] = dados["FINALIDADE"]
            prod["DISPONIBILIDADE"] = dados["DISPONIBILIDADE"]
            prod["CIDADE-DO-PRODUTO"] = dados["CIDADE-DO-PRODUTO"]
            prod["INSTITUICAO-FINANCIADORA"] = dados["INSTITUICAO-FINANCIADORA"]
            prod["FINALIDADE-INGLES"] = dados["FINALIDADE-INGLES"]

            prod['REGISTRO-OU-PATENTE'] = self.get_registro_patente(produto)
            prod['POSICAO_AUTOR'], prod['NUMERO_AUTORES'], prod['AUTORES'] = self.get_autores(produto)
            prod['PALAVRAS-CHAVE'] = self.get_palavras_chave(produto)
            prod['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(produto)
            prod['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(produto)
            prod['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(produto)
            self.indicadores_append('produção Técnica - produto Tecnológico - ' + prod['NATUREZA'], prod['ANO'])
            produtos_tecnologicos.append(prod)
        self.lattes['PRODUTO-TECNOLOGICO'] = produtos_tecnologicos

        # <xs:element minOccurs="0" maxOccurs="unbounded" ref="PATENTE"/>
        patentes = []
        for xml_patente in sopa.find_all('PATENTE'):
            patente={}
            patente["SEQUENCIA-PRODUCAO"] = xml_patente["SEQUENCIA-PRODUCAO"]

            dados = xml_patente.find("DADOS-BASICOS-DA-PATENTE")
            patente["TITULO"] = dados["TITULO"]
            patente["ANO-DESENVOLVIMENTO"] = dados["ANO-DESENVOLVIMENTO"]
            patente["PAIS"] = dados["PAIS"]
            patente["HOME-PAGE"] = dados["HOME-PAGE"]
            patente["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
            patente["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            patente["TITULO-INGLES"] = dados["TITULO-INGLES"]
            patente["FLAG-POTENCIAL-INOVACAO"] = dados["FLAG-POTENCIAL-INOVACAO"]

            dados = xml_patente.find("DETALHAMENTO-DA-PATENTE")
            patente["FINALIDADE"] = dados["FINALIDADE"]
            patente["INSTITUICAO-FINANCIADORA"] = dados["INSTITUICAO-FINANCIADORA"]
            patente["FINALIDADE-INGLES"] = dados["FINALIDADE-INGLES"]
            patente["CATEGORIA"] = dados["CATEGORIA"]

            patente['REGISTRO-OU-PATENTE'] = self.get_registro_patente(xml_patente)
            patente['HISTORICO-SITUACOES-PATENTE'] = self.get_registro_patente(xml_patente)
            patente['POSICAO_AUTOR'], patente['NUMERO_AUTORES'], patente['AUTORES'] = self.get_autores(xml_patente)
            patente['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_patente)
            patente['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_patente)
            patente['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_patente)
            patente['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_patente)

            self.indicadores_append('produção Técnica - Patente - ' + patente['CATEGORIA'], patente['ANO-DESENVOLVIMENTO'])
            patentes.append(patente)
        self.lattes['PATENTE'] = patentes

        # <xs:element minOccurs="0" maxOccurs="unbounded" ref="CULTIVAR-PROTEGIDA"/>
        cultivares_protegidas = []
        for xml_cultivar_protegida in sopa.find_all('CULTIVAR-PROTEGIDA'):
            cultivar_p={}
            cultivar_p["SEQUENCIA-PRODUCAO"] = xml_cultivar_protegida["SEQUENCIA-PRODUCAO"]
            cultivar_p["DADOS-BASICOS-DA-CULTIVAR"] = self.get_dados_basicos_cultivar(xml_cultivar_protegida, cultivar_p)
            cultivar_p["DETALHAMENTO-DA-CULTIVAR"] = self.get_detalhamento_cultivar(xml_cultivar_protegida, cultivar_p)
            cultivar_p['POSICAO_AUTOR'], cultivar_p['NUMERO_AUTORES'], cultivar_p['AUTORES'] = self.get_autores(xml_cultivar_protegida)
            cultivar_p['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_cultivar_protegida)
            cultivar_p['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_cultivar_protegida)
            cultivar_p['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_cultivar_protegida)
            cultivar_p['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_cultivar_protegida)

            self.indicadores_append('produção Técnica - Cultivar - Protegida', cultivar_p['ANO-SOLICITACAO'])
            cultivares_protegidas.append(cultivar_p)
        self.lattes['CULTIVAR-PROTEGIDA'] = cultivares_protegidas

            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="CULTIVAR-REGISTRADA"/>
        cultivares_registradas = []
        for xml_cultivar_registrada in sopa.find_all('CULTIVAR-REGISTRADA'):
            cultivar_r = {}
            cultivar_r["SEQUENCIA-PRODUCAO"] = xml_cultivar_registrada["SEQUENCIA-PRODUCAO"]
            cultivar_r["DADOS-BASICOS-DA-CULTIVAR"] = self.get_dados_basicos_cultivar(xml_cultivar_registrada, cultivar_r)
            cultivar_r["DETALHAMENTO-DA-CULTIVAR"] = self.get_detalhamento_cultivar(xml_cultivar_registrada, cultivar_r)
            cultivar_r['POSICAO_AUTOR'], cultivar_r['NUMERO_AUTORES'], cultivar_r['AUTORES'] = self.get_autores(xml_cultivar_registrada)
            cultivar_r['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_cultivar_registrada)
            cultivar_r['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_cultivar_registrada)
            cultivar_r['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_cultivar_registrada)
            cultivar_r['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_cultivar_registrada)

            self.indicadores_append('produção Técnica - Cultivar - Registrada', patente['ANO-SOLICITACAO'])
            cultivares_registradas.append(cultivar_r)
        self.lattes['CULTIVAR-REGISTRADA'] = cultivares_registradas


            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="DESENHO-INDUSTRIAL"/>
        desenhos_industriais = []
        for xml_desenho_industrial in sopa.find_all('DESENHO-INDUSTRIAL'):
            desenho_industrial = {}
            desenho_industrial["SEQUENCIA-PRODUCAO"] = xml_desenho_industrial["SEQUENCIA-PRODUCAO"]

            dados = xml_desenho_industrial.find("DADOS-BASICOS-DO-DESENHO-INDUSTRIAL")
            desenho_industrial["TITULO"] = dados["TITULO"]
            desenho_industrial["ANO-DESENVOLVIMENTO"] = dados["ANO-DESENVOLVIMENTO"]
            desenho_industrial["PAIS"] = dados["PAIS"]
            desenho_industrial["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            desenho_industrial["TITULO-INGLES"] = dados["TITULO-INGLES"]
            desenho_industrial["FLAG-POTENCIAL-INOVACAO"] = dados["FLAG-POTENCIAL-INOVACAO"]

            dados = xml_desenho_industrial.find("DETALHAMENTO-DO-DESENHO-INDUSTRIAL")
            desenho_industrial["FINALIDADE"] = dados["FINALIDADE"]
            desenho_industrial["INSTITUICAO-FINANCIADORA"] = dados["INSTITUICAO-FINANCIADORA"]
            desenho_industrial["FINALIDADE-INGLES"] = dados["FINALIDADE-INGLES"]

            desenho_industrial['REGISTRO-OU-PATENTE'] = self.get_registro_patente(xml_desenho_industrial)
            desenho_industrial['HISTORICO-SITUACOES-PATENTE'] = self.get_registro_patente(xml_desenho_industrial)
            desenho_industrial['POSICAO_AUTOR'], desenho_industrial['NUMERO_AUTORES'], desenho_industrial['AUTORES'] = self.get_autores(xml_desenho_industrial)
            desenho_industrial['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_desenho_industrial)
            desenho_industrial['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_desenho_industrial)
            desenho_industrial['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_desenho_industrial)
            desenho_industrial['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_desenho_industrial)

            self.indicadores_append('produção Técnica - Desenho Industrial', desenho_industrial['ANO-DESENVOLVIMENTO'])
            desenhos_industriais.append(desenho_industrial)
        self.lattes['DESENHO-INDUSTRIAL'] = desenhos_industriais

            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="MARCA"/>
        marcas = []
        for xml_marca in sopa.find_all('MARCA'):
            marca = {}
            marca["SEQUENCIA-PRODUCAO"] = xml_marca["SEQUENCIA-PRODUCAO"]
            marca['REGISTRO-OU-PATENTE'] = self.get_registro_patente(xml_marca)
            marca['POSICAO_AUTOR'], marca['NUMERO_AUTORES'], marca['AUTORES'] = self.get_autores(xml_marca)
            marca['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_marca)
            marca['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_marca)
            marca['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_marca)
            marca['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_marca)

            dados = xml_marca.get('DADOS-BASICOS-DA-MARCA')
            marca["TITULO"] = dados["TITULO"]
            marca["ANO-DESENVOLVIMENTO"] = dados["ANO-DESENVOLVIMENTO"]
            marca["PAIS"] = dados["PAIS"]
            marca["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            marca["TITULO-INGLES"] = dados["TITULO-INGLES"]
            marca["FLAG-POTENCIAL-INOVACAO"] = dados["FLAG-POTENCIAL-INOVACAO"]

            dados = xml_marca.get('DETALHAMENTO-DA-MARCA')
            marca["FINALIDADE"] = dados["FINALIDADE"]
            marca["FINALIDADE-INGLES"] = dados["FINALIDADE-INGLES"]
            marca["NATUREZA"] = dados["NATUREZA"]

            self.indicadores_append('produção Técnica - MArca', marca['ANO-DESENVOLVIMENTO'])
            marcas.append(marca)
        self.lattes['MARCA'] = marcas

            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="TOPOGRAFIA-DE-CIRCUITO-INTEGRADO"/>
        circuitos = []
        for xml_circuito in sopa.find_all('TOPOGRAFIA-DE-CIRCUITO-INTEGRADO'):
            circuito["SEQUENCIA-PRODUCAO"] = xml_circuito["SEQUENCIA-PRODUCAO"]

            dados = xml_circuito.find("DADOS-BASICOS-DA-TOPOGRAFIA-DE-CIRCUITO-INTEGRADO")
            circuito = {}
            circuito["TITULO"] = dados["TITULO"]
            circuito["ANO-DESENVOLVIMENTO"] = dados["ANO-DESENVOLVIMENTO"]
            circuito["PAIS"] = dados["PAIS"]
            circuito["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            circuito["TITULO-INGLES"] = dados["TITULO-INGLES"]
            circuito["FLAG-POTENCIAL-INOVACAO"] = dados["FLAG-POTENCIAL-INOVACAO"]

            dados = xml_circuito.find("DETALHAMENTO-DA-TOPOGRAFIA-DE-CIRCUITO-INTEGRADO")
            circuito["FINALIDADE"] = dados["FINALIDADE"]
            circuito["INSTITUICAO-FINANCIADORA"] = dados["INSTITUICAO-FINANCIADORA"]
            circuito["FINALIDADE-INGLES"] = dados["FINALIDADE-INGLES"]

            circuito['REGISTRO-OU-PATENTE'] = self.get_registro_patente(xml_circuito)
            circuito['POSICAO_AUTOR'], circuito['NUMERO_AUTORES'], circuito['AUTORES'] = self.get_autores(xml_circuito)
            circuito['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_circuito)
            circuito['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_circuito)
            circuito['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_circuito)
            circuito['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_circuito)

            self.indicadores_append('produção Técnica - CIrcuito', marca['ANO-DESENVOLVIMENTO'])
            circuitos.append(marca)
        self.lattes['TOPOGRAFIA-DE-CIRCUITO-INTEGRADO'] = circuitos

            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="PROCESSOS-OU-TECNICAS"/>
        processos_tecnicas = []
        for xml_processos_tecnicas in sopa.find_all('PROCESSOS-OU-TECNICAS'):
            processo_tecnica = {}
            processo_tecnica["SEQUENCIA-PRODUCAO"] = xml_processos_tecnicas["SEQUENCIA-PRODUCAO"]

            processo_tecnica['REGISTRO-OU-PATENTE'] = self.get_registro_patente(xml_processos_tecnicas)
            processo_tecnica['POSICAO_AUTOR'], processo_tecnica['NUMERO_AUTORES'], processo_tecnica['AUTORES'] = self.get_autores(xml_processos_tecnicas)
            processo_tecnica['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_processos_tecnicas)
            processo_tecnica['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_processos_tecnicas)
            processo_tecnica['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_processos_tecnicas)
            processo_tecnica['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_processos_tecnicas)

            dados = xml_processos_tecnicas.find("DADOS-BASICOS-DO-PROCESSOS-OU-TECNICAS")
            processo_tecnica["NATUREZA"] = dados["NATUREZA"]
            processo_tecnica["TITULO-DO-PROCESSO"] = dados["TITULO-DO-PROCESSO"]
            processo_tecnica["ANO"] = dados["ANO"]
            processo_tecnica["PAIS"] = dados["PAIS"]
            processo_tecnica["IDIOMA"] = dados["IDIOMA"]
            processo_tecnica["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
            processo_tecnica["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
            processo_tecnica["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            processo_tecnica["DOI"] = dados["DOI"]
            processo_tecnica["TITULO-DO-PROCESSO-INGLES"] = dados["TITULO-DO-PROCESSO-INGLES"]
            processo_tecnica["FLAG-POTENCIAL-INOVACAO"] = dados["FLAG-POTENCIAL-INOVACAO"]

            dados = xml_processos_tecnicas.find("DETALHAMENTO-DO-PROCESSOS-OU-TECNICAS")
            processo_tecnica["FINALIDADE"] = dados["FINALIDADE"]
            processo_tecnica["DISPONIBILIDADE"] = dados["DISPONIBILIDADE"]
            processo_tecnica["INSTITUICAO-FINANCIADORA"] = dados["INSTITUICAO-FINANCIADORA"]
            processo_tecnica["CIDADE-DO-PROCESSO"] = dados["CIDADE-DO-PROCESSO"]
            processo_tecnica["FINALIDADE-INGLES"] = dados["FINALIDADE-INGLES"]

            self.indicadores_append('produção Técnica - produção processo ou técNica - ' + processo_tecnica["NATUREZA"], processo_tecnica['ANO'])
            processos_tecnicas.append(processo_tecnica)
        self.lattes['PROCESSOS-OU-TECNICAS'] = processos_tecnicas


            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="TRABALHO-TECNICO"/>
        trabalhos_tecnicos = []
        for xml_trabalhos_tecnicos in sopa.find_all('TRABALHO-TECNICO'):
            trabalho_tecnico = {}
            trabalho_tecnico["SEQUENCIA-PRODUCAO"] = xml_trabalhos_tecnicos["SEQUENCIA-PRODUCAO"]

            trabalho_tecnico['REGISTRO-OU-PATENTE'] = self.get_registro_patente(xml_trabalhos_tecnicos)
            trabalho_tecnico['POSICAO_AUTOR'], trabalho_tecnico['NUMERO_AUTORES'], trabalho_tecnico['AUTORES'] = self.get_autores(xml_trabalhos_tecnicos)
            trabalho_tecnico['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_trabalhos_tecnicos)
            trabalho_tecnico['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_trabalhos_tecnicos)
            trabalho_tecnico['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_trabalhos_tecnicos)
            trabalho_tecnico['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_trabalhos_tecnicos)

            dados = xml_trabalhos_tecnicos.find('DADOS-BASICOS-DO-TRABALHO-TECNICO')
            trabalho_tecnico["NATUREZA"] = dados["NATUREZA"]
            trabalho_tecnico["TITULO-DO-TRABALHO-TECNICO"] = dados["TITULO-DO-TRABALHO-TECNICO"]
            trabalho_tecnico["ANO"] = dados["ANO"]
            trabalho_tecnico["PAIS"] = dados["PAIS"]
            trabalho_tecnico["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
            trabalho_tecnico["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
            trabalho_tecnico["IDIOMA"] = dados["IDIOMA"]
            trabalho_tecnico["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            trabalho_tecnico["DOI"] = dados["DOI"]
            trabalho_tecnico["TITULO-DO-TRABALHO-TECNICO-INGLES"] = dados["TITULO-DO-TRABALHO-TECNICO-INGLES"]

            dados = xml_trabalhos_tecnicos.find("DETALHAMENTO-DO-TRABALHO-TECNICO")
            trabalho_tecnico["FINALIDADE"] = dados["FINALIDADE"]
            trabalho_tecnico["DURACAO-EM-MESES"] = dados["DURACAO-EM-MESES"]
            trabalho_tecnico["NUMERO-DE-PAGINAS"] = dados["NUMERO-DE-PAGINAS"]
            trabalho_tecnico["DISPONIBILIDADE"] = dados["DISPONIBILIDADE"]
            trabalho_tecnico["INSTITUICAO-FINANCIADORA"] = dados["INSTITUICAO-FINANCIADORA"]
            trabalho_tecnico["CIDADE-DO-TRABALHO"] = dados["CIDADE-DO-TRABALHO"]
            trabalho_tecnico["FINALIDADE-INGLES"] = dados["FINALIDADE-INGLES"]

            self.indicadores_append('produção Técnica - trabalho tÉcnico - ' + trabalho_tecnico["NATUREZA"], trabalho_tecnico['ANO'])
            trabalhos_tecnicos.append(trabalho_tecnico)
        self.lattes['TRABALHO-TECNICO'] = trabalhos_tecnicos


            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="DEMAIS-TIPOS-DE-PRODUCAO-TECNICA"/>
        demais_producoes = sopa.find('DEMAIS-TIPOS-DE-PRODUCAO-TECNICA')

            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="APRESENTACAO-DE-TRABALHO"/>
        apresentacoes_de_trabalho = []
        for xml_apresentacoes_de_trabalho in sopa.find_all('APRESENTACAO-DE-TRABALHO'):
            apresentacao={}
            apresentacao["SEQUENCIA-PRODUCAO"] = xml_apresentacoes_de_trabalho["SEQUENCIA-PRODUCAO"]

            apresentacao['POSICAO_AUTOR'], apresentacao['NUMERO_AUTORES'], apresentacao['AUTORES'] = self.get_autores(xml_apresentacoes_de_trabalho)
            apresentacao['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_apresentacoes_de_trabalho)
            apresentacao['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_apresentacoes_de_trabalho)
            apresentacao['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_apresentacoes_de_trabalho)
            apresentacao['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_apresentacoes_de_trabalho)

            dados = xml_apresentacoes_de_trabalho.find("DADOS-BASICOS-DA-APRESENTACAO-DE-TRABALHO")
            apresentacao["NATUREZA"] = dados["NATUREZA"]
            apresentacao["TITULO"] = dados["TITULO"]
            apresentacao["ANO"] = dados["ANO"]
            apresentacao["PAIS"] = dados["PAIS"]
            apresentacao["IDIOMA"] = dados["IDIOMA"]
            apresentacao["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            apresentacao["DOI"] = dados["DOI"]
            apresentacao["TITULO-INGLES"] = dados["TITULO-INGLES"]
            apresentacao["FLAG-DIVULGACAO-CIENTIFICA"] = dados["FLAG-DIVULGACAO-CIENTIFICA"]

            dados = xml_apresentacoes_de_trabalho.find("DETALHAMENTO-DA-APRESENTACAO-DE-TRABALHO")
            apresentacao["NOME-DO-EVENTO"] = dados["NOME-DO-EVENTO"]
            apresentacao["INSTITUICAO-PROMOTORA"] = dados["INSTITUICAO-PROMOTORA"]
            apresentacao["LOCAL-DA-APRESENTACAO"] = dados["LOCAL-DA-APRESENTACAO"]
            apresentacao["CIDADE-DA-APRESENTACAO"] = dados["CIDADE-DA-APRESENTACAO"]
            apresentacao["NOME-DO-EVENTO-INGLES"] = dados["NOME-DO-EVENTO-INGLES"]

            self.indicadores_append('produção Técnica - apresentação de trabalho - ' + apresentacao["NATUREZA"], apresentacao['ANO'])
            apresentacoes_de_trabalho.append(apresentacao)
        self.lattes['APRESENTACAO-DE-TRABALHO'] = apresentacoes_de_trabalho

            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="CARTA-MAPA-OU-SIMILAR"/>
        cartas = []
        for xml_cartas in sopa.find_all('CARTA-MAPA-OU-SIMILAR'):
            carta={}
            carta["SEQUENCIA-PRODUCAO"] = xml_cartas["SEQUENCIA-PRODUCAO"]
            carta['POSICAO_AUTOR'], carta['NUMERO_AUTORES'], carta['AUTORES'] = self.get_autores(xml_cartas)
            carta['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_cartas)
            carta['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_cartas)
            carta['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_cartas)
            carta['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_cartas)

            dados = xml_cartas.find("DADOS-BASICOS-DE-CARTA-MAPA-OU-SIMILAR")
            carta["NATUREZA"] = dados["NATUREZA"]
            carta["TITULO"] = dados["TITULO"]
            carta["ANO"] = dados["ANO"]
            carta["PAIS"] = dados["PAIS"]
            carta["IDIOMA"] = dados["IDIOMA"]
            carta["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
            carta["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
            carta["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]

            dados = xml_cartas.find("DETALHAMENTO-DE-CARTA-MAPA-OU-SIMILAR")
            carta["TEMA-DA-CARTA-MAPA-OU-SIMILAR"] = dados["TEMA-DA-CARTA-MAPA-OU-SIMILAR"]
            carta["TECNICA-UTILIZADA"] = dados["TECNICA-UTILIZADA"]
            carta["FINALIDADE"] = dados["FINALIDADE"]
            carta["AREA-REPRESENTADA"] = dados["AREA-REPRESENTADA"]
            carta["INSTITUICAO-FINANCIADORA"] = dados["INSTITUICAO-FINANCIADORA"]
            carta["FINALIDADE-INGLES"] = dados["FINALIDADE-INGLES"]
            self.indicadores_append('produção Técnica - carta, mapa ou similar - ' + carta["NATUREZA"], carta['ANO'])
            cartas.append(carta)
        self.lattes['CARTA-MAPA-OU-SIMILAR'] = cartas


            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="CURSO-DE-CURTA-DURACAO-MINISTRADO"/>
        curso_curta = []
        for xml_curso_curta in sopa.find_all('CURSO-DE-CURTA-DURACAO-MINISTRADO'):
            curso={}
            curso["SEQUENCIA-PRODUCAO"] = xml_curso_curta["SEQUENCIA-PRODUCAO"]
            curso['POSICAO_AUTOR'], curso['NUMERO_AUTORES'], curso['AUTORES'] = self.get_autores(xml_curso_curta)
            curso['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_curso_curta)
            curso['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_curso_curta)
            curso['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_curso_curta)
            curso['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_curso_curta)

            dados = xml_curso_curta.find("DADOS-BASICOS-DE-CURSOS-CURTA-DURACAO-MINISTRADO")
            curso["NIVEL-DO-CURSO"] = dados["NIVEL-DO-CURSO"]
            curso["TITULO"] = dados["TITULO"]
            curso["ANO"] = dados["ANO"]
            curso["PAIS"] = dados["PAIS"]
            curso["IDIOMA"] = dados["IDIOMA"]
            curso["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
            curso["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
            curso["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            curso["DOI"] = dados["DOI"]
            curso["TITULO-INGLES"] = dados["TITULO-INGLES"]
            curso["FLAG-DIVULGACAO-CIENTIFICA"] = dados["FLAG-DIVULGACAO-CIENTIFICA"]

            dados = xml_curso_curta.find("DETALHAMENTO-DE-CURSOS-CURTA-DURACAO-MINISTRADO")
            curso["PARTICIPACAO-DOS-AUTORES"] = dados["PARTICIPACAO-DOS-AUTORES"]
            curso["INSTITUICAO-PROMOTORA-DO-CURSO"] = dados["INSTITUICAO-PROMOTORA-DO-CURSO"]
            curso["LOCAL-DO-CURSO"] = dados["LOCAL-DO-CURSO"]
            curso["CIDADE"] = dados["CIDADE"]
            curso["DURACAO"] = dados["DURACAO"]
            curso["UNIDADE"] = dados["UNIDADE"]
            curso["UNIDADE-INGLES"] = dados["UNIDADE-INGLES"]
            self.indicadores_append('produção Técnica - curso de curta duração ministrado - ' + curso["NIVEL-DO-CURSO"], curso['ANO'])
            curso_curta.append(curso)
        self.lattes['CURSO-DE-CURTA-DURACAO-MINISTRADO'] = curso_curta

            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="DESENVOLVIMENTO-DE-MATERIAL-DIDATICO-OU-INSTRUCIONAL"/>
        materiais_didaticos = []
        for xml_material in sopa.find_all("DESENVOLVIMENTO-DE-MATERIAL-DIDATICO-OU-INSTRUCIONAL"):
            material={}
            material["SEQUENCIA-PRODUCAO"] = xml_material["SEQUENCIA-PRODUCAO"]
            material['POSICAO_AUTOR'], material['NUMERO_AUTORES'], material['AUTORES'] = self.get_autores(xml_material)
            material['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_material)
            material['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_material)
            material['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_material)
            material['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_material)

            dados = xml_material.find("DADOS-BASICOS-DO-MATERIAL-DIDATICO-OU-INSTRUCIONAL")
            material["NATUREZA"] = dados["NATUREZA"]
            material["TITULO"] = dados["TITULO"]
            material["ANO"] = dados["ANO"]
            material["PAIS"] = dados["PAIS"]
            material["IDIOMA"] = dados["IDIOMA"]
            material["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
            material["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
            material["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            material["DOI"] = dados["DOI"]
            material["TITULO-INGLES"] = dados["TITULO-INGLES"]
            material["NATUREZA-INGLES"] = dados["NATUREZA-INGLES"]
            material["FLAG-DIVULGACAO-CIENTIFICA"] = dados["FLAG-DIVULGACAO-CIENTIFICA"]

            dados = xml_material.find("DETALHAMENTO-DO-MATERIAL-DIDATICO-OU-INSTRUCIONAL")
            material["FINALIDADE"] = dados["FINALIDADE"]
            material["FINALIDADE-INGLES"] = dados["FINALIDADE-INGLES"]

            self.indicadores_append('produção Técnica - desenvolvimento de materiais didáticos - ' + material["NATUREZA"], material['ANO'])
            materiais_didaticos.append(material)
        self.lattes["DESENVOLVIMENTO-DE-MATERIAL-DIDATICO-OU-INSTRUCIONAL"] = materiais_didaticos

            
            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="EDITORACAO"/>
        editoracoes = []
        for xml_editoracoes in sopa.find_all("EDITORACAO"):
            editoracao={}
            editoracao["SEQUENCIA-PRODUCAO"] = xml_editoracoes["SEQUENCIA-PRODUCAO"]
            editoracao['POSICAO_AUTOR'], editoracao['NUMERO_AUTORES'], editoracao['AUTORES'] = self.get_autores(xml_editoracoes)
            editoracao['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_editoracoes)
            editoracao['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_editoracoes)
            editoracao['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_editoracoes)
            editoracao['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_editoracoes)

            dados = xml_editoracoes.find("DADOS-BASICOS-DO-MATERIAL-DIDATICO-OU-INSTRUCIONAL")
            if not dados==None:
                editoracao["NATUREZA"] = dados["NATUREZA"]
                editoracao["TITULO"] = dados["TITULO"]
                editoracao["ANO"] = dados["ANO"]
                editoracao["PAIS"] = dados["PAIS"]
                editoracao["IDIOMA"] = dados["IDIOMA"]
                editoracao["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
                editoracao["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
                editoracao["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
                editoracao["DOI"] = dados["DOI"]
                editoracao["TITULO-INGLES"] = dados["TITULO-INGLES"]
                editoracao["NATUREZA-INGLES"] = dados["NATUREZA-INGLES"]
                editoracao["FLAG-DIVULGACAO-CIENTIFICA"] = dados["FLAG-DIVULGACAO-CIENTIFICA"]

            dados = xml_editoracoes.find("DETALHAMENTO-DO-MATERIAL-DIDATICO-OU-INSTRUCIONAL")
            if not dados == None:
                editoracao["FINALIDADE"] = dados["FINALIDADE"]
                editoracao["FINALIDADE-INGLES"] = dados["FINALIDADE-INGLES"]

            self.indicadores_append('produção Técnica - desenvolvimento de materiais didáticos', editoracao['ANO'])
            editoracoes.append(editoracao)
        self.lattes["EDITORACAO"] = materiais_didaticos

            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="MANUTENCAO-DE-OBRA-ARTISTICA"/>
        manutencoes = []
        for xml_manutencoes in sopa.find_all("MANUTENCAO-DE-OBRA-ARTISTICA"):
            manutencao = {}
            manutencao["SEQUENCIA-PRODUCAO"] = xml_manutencoes["SEQUENCIA-PRODUCAO"]

            manutencao['POSICAO_AUTOR'], manutencao['NUMERO_AUTORES'], manutencao['AUTORES'] = self.get_autores(xml_manutencoes)
            manutencao['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_manutencoes)
            manutencao['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_manutencoes)
            manutencao['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_manutencoes)
            manutencao['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_manutencoes)

            dados = xml_manutencoes.find("DADOS-BASICOS-DE-MANUTENCAO-DE-OBRA-ARTISTICA")
            manutencao["TIPO"] = dados["TIPO"]
            manutencao["NATUREZA"] = dados["NATUREZA"]
            manutencao["TITULO"] = dados["TITULO"]
            manutencao["ANO"] = dados["ANO"]
            manutencao["PAIS"] = dados["PAIS"]
            manutencao["IDIOMA"] = dados["IDIOMA"]
            manutencao["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            manutencao["DOI"] = dados["DOI"]
            manutencao["TITULO-INGLES"] = dados["TITULO-INGLES"]


            dados = xml_manutencoes.find("DETALHAMENTO-DE-MANUTENCAO-DE-OBRA-ARTISTICA")
            manutencao["NOME-DA-OBRA"] = dados["NOME-DA-OBRA"]
            manutencao["AUTOR-DA-OBRA"] = dados["AUTOR-DA-OBRA"]
            manutencao["ANO-DA-OBRA"] = dados["ANO-DA-OBRA"]
            manutencao["ACERVO"] = dados["ACERVO"]
            manutencao["LOCAL"] = dados["LOCAL"]
            manutencao["CIDADE"] = dados["CIDADE"]

            self.indicadores_append('produção Técnica - manutenção de obras de arte - ' + manutencao["TIPO"], manutencao['ANO'])
            manutencoes.append(manutencao)
        self.lattes["MANUTENCAO-DE-OBRA-ARTISTICA"] = manutencoes

            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="MAQUETE"/>
        maquetes = []
        for xml_maquete in sopa.find_all("MAQUETE"):
            maquete = {}
            maquete["SEQUENCIA-PRODUCAO"] = xml_maquete["SEQUENCIA-PRODUCAO"]

            maquete['POSICAO_AUTOR'], maquete['NUMERO_AUTORES'], maquete['AUTORES'] = self.get_autores(xml_maquete)
            maquete['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_maquete)
            maquete['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_maquete)
            maquete['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_maquete)
            maquete['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_maquete)

            dados = xml_maquete.find("DADOS-BASICOS-DA-MAQUETE")
            maquete["TITULO"] = dados["TITULO"]
            maquete["ANO"] = dados["ANO"]
            maquete["PAIS"] = dados["PAIS"]
            maquete["IDIOMA"] = dados["IDIOMA"]
            maquete["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
            maquete["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
            maquete["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            maquete["DOI"] = dados["DOI"]
            maquete["TITULO-INGLES"] = dados["TITULO-INGLES"]

            dados = xml_maquete.find("DETALHAMENTO-DA-MAQUETE")
            maquete["FINALIDADE"] = dados["FINALIDADE"]
            maquete["OBJETO-REPRESENTADO"] = dados["OBJETO-REPRESENTADO"]
            maquete["MATERIAL-UTILIZADO"] = dados["MATERIAL-UTILIZADO"]
            maquete["INSTITUICAO-FINANCIADORA"] = dados["INSTITUICAO-FINANCIADORA"]
            maquete["FINALIDADE-INGLES"] = dados["FINALIDADE-INGLES"]

            self.indicadores_append('produção Técnica - maquetes - ' + maquete["MEIO-DE-DIVULGACAO"], maquete['ANO'])
            maquetes.append(maquete)
        self.lattes["MAQUETE"] = maquetes

            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="ORGANIZACAO-DE-EVENTO"/>
        organizacoes_eventos = []
        for xml_organizacoes_eventos in sopa.find_all("ORGANIZACAO-DE-EVENTO"):
            organizacao_evento = {}
            organizacao_evento["SEQUENCIA-PRODUCAO"] = xml_organizacoes_eventos["SEQUENCIA-PRODUCAO"]

            organizacao_evento['POSICAO_AUTOR'], organizacao_evento['NUMERO_AUTORES'], organizacao_evento['AUTORES'] = self.get_autores(xml_organizacoes_eventos)
            organizacao_evento['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_organizacoes_eventos)
            organizacao_evento['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_organizacoes_eventos)
            organizacao_evento['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_organizacoes_eventos)
            organizacao_evento['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_organizacoes_eventos)

            dados = xml_organizacoes_eventos.find("DADOS-BASICOS-DA-ORGANIZACAO-DE-EVENTO")
            organizacao_evento["TIPO"] = dados["TIPO"]
            organizacao_evento["NATUREZA"] = dados["NATUREZA"]
            organizacao_evento["TITULO"] = dados["TITULO"]
            organizacao_evento["ANO"] = dados["ANO"]
            organizacao_evento["PAIS"] = dados["PAIS"]
            organizacao_evento["IDIOMA"] = dados["IDIOMA"]
            organizacao_evento["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
            organizacao_evento["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
            organizacao_evento["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            organizacao_evento["DOI"] = dados["DOI"]
            organizacao_evento["TITULO-INGLES"] = dados["TITULO-INGLES"]
            organizacao_evento["FLAG-DIVULGACAO-CIENTIFICA"] = dados["FLAG-DIVULGACAO-CIENTIFICA"]

            dados = xml_organizacoes_eventos.find("DETALHAMENTO-DA-ORGANIZACAO-DE-EVENTO")
            organizacao_evento["INSTITUICAO-PROMOTORA"] = dados["INSTITUICAO-PROMOTORA"]
            organizacao_evento["DURACAO-EM-SEMANAS"] = dados["DURACAO-EM-SEMANAS"]
            organizacao_evento["FLAG-EVENTO-ITINERANTE"] = dados["FLAG-EVENTO-ITINERANTE"]
            organizacao_evento["FLAG-CATALOGO"] = dados["FLAG-CATALOGO"]
            organizacao_evento["LOCAL"] = dados["LOCAL"]
            organizacao_evento["CIDADE"] = dados["CIDADE"]

            self.indicadores_append('produção Técnica - organização de eventos - ' + organizacao_evento["NATUREZA"], organizacao_evento['ANO'])
            organizacoes_eventos.append(organizacao_evento)
        self.lattes["ORGANIZACAO-DE-EVENTO"] = organizacoes_eventos

            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="OUTRA-PRODUCAO-TECNICA"/>
        outras_producoes = []
        for xml_outras_producoes in sopa.find_all("OUTRA-PRODUCAO-TECNICA"):
            outra_producao = {}
            outra_producao["SEQUENCIA-PRODUCAO"] = xml_outras_producoes["SEQUENCIA-PRODUCAO"]

            outra_producao['POSICAO_AUTOR'], outra_producao['NUMERO_AUTORES'], outra_producao['AUTORES'] = self.get_autores(xml_outras_producoes)
            outra_producao['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_outras_producoes)
            outra_producao['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_outras_producoes)
            outra_producao['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_outras_producoes)
            outra_producao['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_outras_producoes)

            dados = xml_outras_producoes.find("DADOS-BASICOS-DE-OUTRA-PRODUCAO-TECNICA")
            outra_producao["NATUREZA"] = dados["NATUREZA"]
            outra_producao["TITULO"] = dados["TITULO"]
            outra_producao["ANO"] = dados["ANO"]
            outra_producao["PAIS"] = dados["PAIS"]
            outra_producao["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
            outra_producao["IDIOMA"] = dados["IDIOMA"]
            outra_producao["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
            outra_producao["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            outra_producao["DOI"] = dados["DOI"]
            outra_producao["TITULO-INGLES"] = dados["TITULO-INGLES"]
            outra_producao["NATUREZA-INGLES"] = dados["NATUREZA-INGLES"]
            outra_producao["FLAG-DIVULGACAO-CIENTIFICA"] = dados["FLAG-DIVULGACAO-CIENTIFICA"]

            dados = xml_outras_producoes.find("DETALHAMENTO-DE-OUTRA-PRODUCAO-TECNICA")
            outra_producao["FINALIDADE"] = dados["FINALIDADE"]
            outra_producao["INSTITUICAO-PROMOTORA"] = dados["INSTITUICAO-PROMOTORA"]
            outra_producao["LOCAL"] = dados["LOCAL"]
            outra_producao["CIDADE"] = dados["CIDADE"]
            outra_producao["FINALIDADE-INGLES"] = dados["FINALIDADE-INGLES"]
            
            self.indicadores_append('produção Técnica - outra produção - ' + outra_producao["NATUREZA"], outra_producao['ANO'])
            outras_producoes.append(outra_producao)
        self.lattes["OUTRA-PRODUCAO-TECNICA"] = outras_producoes

            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="PROGRAMA-DE-RADIO-OU-TV"/>
        programas_radio_tv = []
        for xml_programas_radio_tv in sopa.find_all("PROGRAMA-DE-RADIO-OU-TV"):
            programas_r_tv = {}
            programas_r_tv["SEQUENCIA-PRODUCAO"] = xml_programas_radio_tv["SEQUENCIA-PRODUCAO"]

            programas_r_tv['POSICAO_AUTOR'], programas_r_tv['NUMERO_AUTORES'], programas_r_tv['AUTORES'] = self.get_autores(xml_programas_radio_tv)
            programas_r_tv['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_programas_radio_tv)
            programas_r_tv['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_programas_radio_tv)
            programas_r_tv['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_programas_radio_tv)
            programas_r_tv['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_programas_radio_tv)

            dados = xml_programas_radio_tv.find("DADOS-BASICOS-DO-PROGRAMA-DE-RADIO-OU-TV")
            programas_r_tv["NATUREZA"] = dados["NATUREZA"]
            programas_r_tv["TITULO"] = dados["TITULO"]
            programas_r_tv["ANO"] = dados["ANO"]
            programas_r_tv["PAIS"] = dados["PAIS"]
            programas_r_tv["IDIOMA"] = dados["IDIOMA"]
            programas_r_tv["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            programas_r_tv["DOI"] = dados["DOI"]
            programas_r_tv["TITULO-INGLES"] = dados["TITULO-INGLES"]
            programas_r_tv["HOME-PAGE"] = dados["HOME-PAGE"]
            programas_r_tv["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
            programas_r_tv["FLAG-DIVULGACAO-CIENTIFICA"] = dados["FLAG-DIVULGACAO-CIENTIFICA"]

            dados = xml_programas_radio_tv.find("DETALHAMENTO-DO-PROGRAMA-DE-RADIO-OU-TV")
            programas_r_tv["EMISSORA"] = dados["EMISSORA"]
            programas_r_tv["TEMA"] = dados["TEMA"]
            # programas_r_tv["FORMATO-DATA-DA-APRESENTACAO"] = dados["FORMATO-DATA-DA-APRESENTACAO"]
            programas_r_tv["DATA-DA-APRESENTACAO"] = dados["DATA-DA-APRESENTACAO"]
            programas_r_tv["DURACAO-EM-MINUTOS"] = dados["DURACAO-EM-MINUTOS"]
            programas_r_tv["CIDADE"] = dados["CIDADE"]
            # programas_r_tv["VEICULO-DE-DIVULGACAO"] = dados["VEICULO-DE-DIVULGACAO"]
            
            self.indicadores_append('produção Técnica - programas de rádio e TV - ' + programas_r_tv["NATUREZA"], programas_r_tv['ANO'])
            programas_radio_tv.append(programas_r_tv)
        self.lattes["PROGRAMA-DE-RADIO-OU-TV"] = programas_radio_tv


            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="RELATORIO-DE-PESQUISA"/>
        relatorios_pesquisa = []
        for xml_relatorios_pesquisa in sopa.find_all("RELATORIO-DE-PESQUISA"):
            relatorio_pesquisa = {}
            relatorio_pesquisa["SEQUENCIA-PRODUCAO"] = xml_relatorios_pesquisa["SEQUENCIA-PRODUCAO"]

            relatorio_pesquisa['POSICAO_AUTOR'], relatorio_pesquisa['NUMERO_AUTORES'], relatorio_pesquisa['AUTORES'] = self.get_autores(xml_relatorios_pesquisa)
            relatorio_pesquisa['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_relatorios_pesquisa)
            relatorio_pesquisa['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_relatorios_pesquisa)
            relatorio_pesquisa['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_relatorios_pesquisa)
            relatorio_pesquisa['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_relatorios_pesquisa)

            dados = xml_relatorios_pesquisa.find("DADOS-BASICOS-DO-RELATORIO-DE-PESQUISA")
            relatorio_pesquisa["TITULO"] = dados["TITULO"]
            relatorio_pesquisa["ANO"] = dados["ANO"]
            relatorio_pesquisa["PAIS"] = dados["PAIS"]
            relatorio_pesquisa["IDIOMA"] = dados["IDIOMA"]
            relatorio_pesquisa["MEIO-DE-DIVULGACAO"] = dados["MEIO-DE-DIVULGACAO"]
            relatorio_pesquisa["HOME-PAGE-DO-TRABALHO"] = dados["HOME-PAGE-DO-TRABALHO"]
            relatorio_pesquisa["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            relatorio_pesquisa["DOI"] = dados["DOI"]
            relatorio_pesquisa["TITULO-INGLES"] = dados["TITULO-INGLES"]

            dados = xml_relatorios_pesquisa.find("DETALHAMENTO-DO-RELATORIO-DE-PESQUISA")
            relatorio_pesquisa["NOME-DO-PROJETO"] = dados["NOME-DO-PROJETO"]
            relatorio_pesquisa["NUMERO-DE-PAGINAS"] = dados["NUMERO-DE-PAGINAS"]
            relatorio_pesquisa["DISPONIBILIDADE"] = dados["DISPONIBILIDADE"]
            relatorio_pesquisa["INSTITUICAO-FINANCIADORA"] = dados["INSTITUICAO-FINANCIADORA"]
            
            self.indicadores_append('produção Técnica - relatórios de pesquisa', relatorio_pesquisa['ANO'])
            relatorios_pesquisa.append(relatorio_pesquisa)
        self.lattes["RELATORIO-DE-PESQUISA"] = relatorios_pesquisa

            # <xs:element minOccurs="0" maxOccurs="unbounded" ref="MIDIA-SOCIAL-WEBSITE-BLOG"/>
        midias = []
        for xml_midias in sopa.find_all("MIDIA-SOCIAL-WEBSITE-BLOG"):
            midia = {}
            midia["SEQUENCIA-PRODUCAO"] = xml_midias["SEQUENCIA-PRODUCAO"]

            midia['POSICAO_AUTOR'], midia['NUMERO_AUTORES'], midia['AUTORES'] = self.get_autores(xml_midias)
            midia['PALAVRAS-CHAVE'] = self.get_palavras_chave(xml_midias)
            midia['AREAS-DO-CONHECIMENTO'] = self.get_areas_do_conhecimento(xml_midias)
            midia['SETORES-DE-ATIVIDADE'] = self.get_setores_de_atividade(xml_midias)
            midia['INFORMACOES-ADICIONAIS'] = self.get_informacoes_adicionais(xml_midias)

            dados = xml_midias.find("DADOS-BASICOS-DA-MIDIA-SOCIAL-WEBSITE-BLOG")
            midia["NATUREZA"] = dados["NATUREZA"]
            midia["NATUREZA-INGLES"] = dados["NATUREZA-INGLES"]
            midia["TITULO"] = dados["TITULO"]
            midia["TITULO-INGLES"] = dados["TITULO-INGLES"]
            midia["ANO"] = dados["ANO"]
            midia["PAIS"] = dados["PAIS"]
            midia["IDIOMA"] = dados["IDIOMA"]
            midia["HOME-PAGE"] = dados["HOME-PAGE"]
            midia["FLAG-RELEVANCIA"] = dados["FLAG-RELEVANCIA"]
            midia["FLAG-DIVULGACAO-CIENTIFICA"] = dados["FLAG-DIVULGACAO-CIENTIFICA"]

            dados = xml_midias.find("DETALHAMENTO-DA-MIDIA-SOCIAL-WEBSITE-BLOG")
            midia["TEMA"] = dados["TEMA"]
            
            self.indicadores_append('produção Técnica - mídia social, website, blog - ' + midia["NATUREZA"], midia['ANO'])
            midias.append(midia)
        self.lattes["MIDIA-SOCIAL-WEBSITE-BLOG"] = midias

    def get_outra_producao (self):
        id = str(self.id)
        sopa = self.soup.find("OUTRA-PRODUCAO")
        if sopa == None:
            return None
        dado = {}
        for child0 in sopa.children:
            for child1 in child0.children:
                self.lattes[child1.name] = []
                dado = child1.attrs
                for child2 in child1.descendants:
                    for (key, value) in child2.attrs.items():
                        dado[key] = value
                if dado.get('NATUREZA') == None:
                    dado['INDICADOR'] = 'OUTRA-PRODUCAO - ' + child0.name + ' - ' + child1.name
                else:
                    dado['INDICADOR'] = 'OUTRA-PRODUCAO - ' + child0.name + ' - ' + child1.name + ' - ' + dado['NATUREZA']
                dado['ID'] = id
                self.lattes[child1.name].append(dado)
                if not dado.get('ANO') == None:
                    ano = dado.get('ANO')
                elif not dado.get('ANO-DE-CONCLUSAO') == None:
                    ano = dado.get('ANO-DE-CONCLUSAO')
                elif not dado.get('ANO-DA-OBRA-DE-REFERENCIA') == None:
                    ano = dado.get('ANO-DA-OBRA-DE-REFERENCIA')
                elif not dado.get('ANO-DE-OBTENCAO-DO-TITULO') ==None:
                    ano = dado.get('ANO-DE-OBTENCAO-DO-TITULO')
                elif not dado.get('ANO-FIM') == None:
                    ano = dado.get('ANO-FIM')
                elif not dado.get('ANO-DE-REALIZACAO') == None:
                    ano = dado.get('ANO-DE-REALIZACAO')
                elif not dado.get('ANO-DO-ARTIGO') == None:
                    ano = dado.get('ANO-DO-ARTIGO')
                elif not dado.get('ANO-DO-TEXTO') == None:
                    ano = dado.get('ANO-DO-TEXTO')
                elif not dado.get('ANO-DESENVOLVIMENTO') == None:
                    ano = dado.get('ANO-DESENVOLVIMENTO')
                elif not dado.get('ANO-SOLICITACAO') == None:
                    ano = dado.get('ANO-SOLICITACAO')
                elif not dado.get('ANO-DA-OBRA') == None:
                    ano = dado.get('ANO-DA-OBRA') 
                else:
                    ano = None
                self.indicadores_append(dado['INDICADOR'], ano)

    def get_dados_complementares (self):
        id = str(self.id)
        sopa = self.soup.find("DADOS-COMPLEMENTARES")
        if sopa == None:
            return None
        dado = {}
        for child0 in sopa.children:
            if child0.name[0:22] == 'INFORMACOES-ADICIONAIS':
                continue
            for child1 in child0.children:
                self.lattes[child1.name] = []
                dado = child1.attrs
                for child2 in child1.descendants:
                    for (key, value) in child2.attrs.items():
                        dado[key] = value
                if dado.get('NATUREZA') == None:
                    dado['INDICADOR'] = 'DADOS-COMPLEMENTARES - ' + child0.name + ' - ' + child1.name
                else:
                    dado['INDICADOR'] = 'DADOS-COMPLEMENTARES - ' + child0.name + ' - ' + child1.name + ' - ' + dado['NATUREZA']
                dado['ID'] = id
                self.lattes[child1.name].append(dado)

                if not dado.get('ANO') == None:
                    ano = dado.get('ANO')
                elif not dado.get('ANO-DE-CONCLUSAO') == None:
                    ano = dado.get('ANO-DE-CONCLUSAO')
                elif not dado.get('ANO-DA-OBRA-DE-REFERENCIA') == None:
                    ano = dado.get('ANO-DA-OBRA-DE-REFERENCIA')
                elif not dado.get('ANO-DE-OBTENCAO-DO-TITULO') ==None:
                    ano = dado.get('ANO-DE-OBTENCAO-DO-TITULO')
                elif not dado.get('ANO-FIM') == None:
                    ano = dado.get('ANO-FIM')
                elif not dado.get('ANO-DE-REALIZACAO') == None:
                    ano = dado.get('ANO-DE-REALIZACAO')
                elif not dado.get('ANO-DO-ARTIGO') == None:
                    ano = dado.get('ANO-DO-ARTIGO')
                elif not dado.get('ANO-DO-TEXTO') == None:
                    ano = dado.get('ANO-DO-TEXTO')
                elif not dado.get('ANO-DESENVOLVIMENTO') == None:
                    ano = dado.get('ANO-DESENVOLVIMENTO')
                elif not dado.get('ANO-SOLICITACAO') == None:
                    ano = dado.get('ANO-SOLICITACAO')
                elif not dado.get('ANO-DA-OBRA') == None:
                    ano = dado.get('ANO-DA-OBRA') 
                else:
                    ano = None
                self.indicadores_append(dado['INDICADOR'], ano)

    def get_producao_tecnica (self):
        sopa = self.soup.find('PRODUCAO-TECNICA')
        if sopa == None:
            return None
        id = str(self.id)
        dado = {}
        for child0 in sopa.children:
            if child0.name[0:22] == 'INFORMACOES-ADICIONAIS':
                continue
            for child1 in child0.children:
                self.lattes[child1.name] = []
                dado = child1.attrs
                for child2 in child1.descendants:
                    for (key, value) in child2.attrs.items():
                        dado[key] = value
                if dado.get('NATUREZA') == None:
                    dado['INDICADOR'] = 'PRODUCAO-TECNICA - ' + child0.name + ' - ' + child1.name
                else:
                    dado['INDICADOR'] = 'PRODUCAO-TECNICA - ' + child0.name + ' - ' + child1.name + ' - ' + dado['NATUREZA']
                dado['ID'] = id
                self.lattes[child1.name].append(dado)

                if not dado.get('ANO') == None:
                    ano = dado.get('ANO')
                elif not dado.get('ANO-DE-CONCLUSAO') == None:
                    ano = dado.get('ANO-DE-CONCLUSAO')
                elif not dado.get('ANO-DA-OBRA-DE-REFERENCIA') == None:
                    ano = dado.get('ANO-DA-OBRA-DE-REFERENCIA')
                elif not dado.get('ANO-DE-OBTENCAO-DO-TITULO') ==None:
                    ano = dado.get('ANO-DE-OBTENCAO-DO-TITULO')
                elif not dado.get('ANO-FIM') == None:
                    ano = dado.get('ANO-FIM')
                elif not dado.get('ANO-DE-REALIZACAO') == None:
                    ano = dado.get('ANO-DE-REALIZACAO')
                elif not dado.get('ANO-DO-ARTIGO') == None:
                    ano = dado.get('ANO-DO-ARTIGO')
                elif not dado.get('ANO-DO-TEXTO') == None:
                    ano = dado.get('ANO-DO-TEXTO')
                elif not dado.get('ANO-DESENVOLVIMENTO') == None:
                    ano = dado.get('ANO-DESENVOLVIMENTO')
                elif not dado.get('ANO-SOLICITACAO') == None:
                    ano = dado.get('ANO-SOLICITACAO')
                elif not dado.get('ANO-DA-OBRA') == None:
                    ano = dado.get('ANO-DA-OBRA') 
                else:
                    ano = None
                self.indicadores_append(dado['INDICADOR'], ano)

    def get_trabalhos_eventos (self):
        sopa = self.soup.find('PRODUCAO-BIBLIOGRAFICA')
        if sopa == None:
            return None
        id = str(self.id)
        dado = {}
        for child0 in sopa.children:
            if child0.name[0:22] == 'INFORMACOES-ADICIONAIS':
                continue
            for child1 in child0.children:
                self.lattes[child1.name] = []
                dado = child1.attrs
                for child2 in child1.descendants:
                    for (key, value) in child2.attrs.items():
                        dado[key] = value
                if dado.get('NATUREZA') == None:
                    dado['INDICADOR'] = 'PRODUCAO-BIBLIOGRAFICA - ' + child0.name + ' - ' + child1.name
                else:
                    dado['INDICADOR'] = 'PRODUCAO-BIBLIOGRAFICA - ' + child0.name + ' - ' + child1.name + ' - ' + dado['NATUREZA']
                dado['ID'] = id
                self.lattes[child1.name].append(dado)

                if not dado.get('ANO') == None:
                    ano = dado.get('ANO')
                elif not dado.get('ANO-DE-CONCLUSAO') == None:
                    ano = dado.get('ANO-DE-CONCLUSAO')
                elif not dado.get('ANO-DA-OBRA-DE-REFERENCIA') == None:
                    ano = dado.get('ANO-DA-OBRA-DE-REFERENCIA')
                elif not dado.get('ANO-DE-OBTENCAO-DO-TITULO') ==None:
                    ano = dado.get('ANO-DE-OBTENCAO-DO-TITULO')
                elif not dado.get('ANO-FIM') == None:
                    ano = dado.get('ANO-FIM')
                elif not dado.get('ANO-DE-REALIZACAO') == None:
                    ano = dado.get('ANO-DE-REALIZACAO')
                elif not dado.get('ANO-DO-ARTIGO') == None:
                    ano = dado.get('ANO-DO-ARTIGO')
                elif not dado.get('ANO-DO-TEXTO') == None:
                    ano = dado.get('ANO-DO-TEXTO')
                elif not dado.get('ANO-DESENVOLVIMENTO') == None:
                    ano = dado.get('ANO-DESENVOLVIMENTO')
                elif not dado.get('ANO-SOLICITACAO') == None:
                    ano = dado.get('ANO-SOLICITACAO')
                elif not dado.get('ANO-DA-OBRA') == None:
                    ano = dado.get('ANO-DA-OBRA') 
                else:
                    ano = None
                self.indicadores_append(dado['INDICADOR'], ano)

    def get_atuacao_profissional_bak (self):
        sopa = self.soup.find('ATUACOES-PROFISSIONAIS')
        if sopa == None:
            return None
        id = str(self.id)
        dado = {}
        for child0 in sopa.children:
            if child0.name[0:22] == 'INFORMACOES-ADICIONAIS':
                continue
            for child1 in child0.children:
                self.lattes[child1.name] = []
                dado = child1.attrs
                for child2 in child1.descendants:
                    for (key, value) in child2.attrs.items():
                        dado[key] = value
                if dado.get('NATUREZA') == None:
                    dado['INDICADOR'] = 'PRODUCAO-BIBLIOGRAFICA - ' + child0.name + ' - ' + child1.name
                else:
                    dado['INDICADOR'] = 'PRODUCAO-BIBLIOGRAFICA - ' + child0.name + ' - ' + child1.name + ' - ' + dado['NATUREZA']
                dado['ID'] = id
                self.lattes[child1.name].append(dado)

                if not dado.get('ANO') == None:
                    ano = dado.get('ANO')
                elif not dado.get('ANO-DE-CONCLUSAO') == None:
                    ano = dado.get('ANO-DE-CONCLUSAO')
                elif not dado.get('ANO-DA-OBRA-DE-REFERENCIA') == None:
                    ano = dado.get('ANO-DA-OBRA-DE-REFERENCIA')
                elif not dado.get('ANO-DE-OBTENCAO-DO-TITULO') ==None:
                    ano = dado.get('ANO-DE-OBTENCAO-DO-TITULO')
                elif not dado.get('ANO-FIM') == None:
                    ano = dado.get('ANO-FIM')
                elif not dado.get('ANO-DE-REALIZACAO') == None:
                    ano = dado.get('ANO-DE-REALIZACAO')
                elif not dado.get('ANO-DO-ARTIGO') == None:
                    ano = dado.get('ANO-DO-ARTIGO')
                elif not dado.get('ANO-DO-TEXTO') == None:
                    ano = dado.get('ANO-DO-TEXTO')
                elif not dado.get('ANO-DESENVOLVIMENTO') == None:
                    ano = dado.get('ANO-DESENVOLVIMENTO')
                elif not dado.get('ANO-SOLICITACAO') == None:
                    ano = dado.get('ANO-SOLICITACAO')
                elif not dado.get('ANO-DA-OBRA') == None:
                    ano = dado.get('ANO-DA-OBRA') 
                else:
                    ano = None
                self.indicadores_append(dado['INDICADOR'], ano)    
                
    def get_all (self):
        sopa = self.soup.find('DADOS-GERAIS')
        nivel = 0
        nome_indicador = []        
        if sopa == None:
            return None
        for child in sopa.children:
            self.get_children(child, nível, nome_indicador)

    def get_children(self, children, nível, nome_indicador):

        if len(children.children.name) > 0:
            nome_indicador.append(children.name)
            nível += 1
            for child in children:
                self.get_children(child)
        else:
            dado = {}
            for (key, value) in children.attrs.items():
                dado[key] = value
            if not dado.get('NATUREZA') == None:
                nome_indicador += ' - ' + dado['NATUREZA']
            dado['INDICADOR'] = nome_indicador
            dado['ID'] = id
            self.lattes[nome_indicador].append(dado)
            if not dado.get('ANO') == None:
                ano = dado.get('ANO')
            elif not dado.get('ANO-DE-CONCLUSAO') == None:
                ano = dado.get('ANO-DE-CONCLUSAO')
            elif not dado.get('ANO-DA-OBRA-DE-REFERENCIA') == None:
                ano = dado.get('ANO-DA-OBRA-DE-REFERENCIA')
            elif not dado.get('ANO-DE-OBTENCAO-DO-TITULO') ==None:
                ano = dado.get('ANO-DE-OBTENCAO-DO-TITULO')
            elif not dado.get('ANO-FIM') == None:
                ano = dado.get('ANO-FIM')
            elif not dado.get('ANO-DE-REALIZACAO') == None:
                ano = dado.get('ANO-DE-REALIZACAO')
            elif not dado.get('ANO-DO-ARTIGO') == None:
                ano = dado.get('ANO-DO-ARTIGO')
            elif not dado.get('ANO-DO-TEXTO') == None:
                ano = dado.get('ANO-DO-TEXTO')
            elif not dado.get('ANO-DESENVOLVIMENTO') == None:
                ano = dado.get('ANO-DESENVOLVIMENTO')
            elif not dado.get('ANO-SOLICITACAO') == None:
                ano = dado.get('ANO-SOLICITACAO')
            elif not dado.get('ANO-DA-OBRA') == None:
                ano = dado.get('ANO-DA-OBRA') 
            else:
                ano = None
            self.indicadores_append(dado['INDICADOR'], ano)


