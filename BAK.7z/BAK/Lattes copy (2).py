
# d8888b.       .d8b.       d888888b       .d8b.            d8888b.       .d8b.       .d8888.      d88888b 
# 88  `8D      d8' `8b      `~~88~~'      d8' `8b           88  `8D      d8' `8b      88'  YP      88'     
# 88   88      88ooo88         88         88ooo88           88oooY'      88ooo88      `8bo.        88ooooo 
# 88   88      88~~~88         88         88~~~88           88~~~b.      88~~~88        `Y8b.      88~~~~~ 
# 88  .8D      88   88         88         88   88           88   8D      88   88      db   8D      88.     
# Y8888D'      YP   YP         YP         YP   YP           Y8888P'      YP   YP      `8888Y'      Y88888P 
                                                                                                         
                                                                                                         
# d88888b db    db d8b   db  .o88b. d888888b d888888b  .d88b.  d8b   db .d8888.                            
# 88'     88    88 888o  88 d8P  Y8 `~~88~~'   `88'   .8P  Y8. 888o  88 88'  YP                            
# 88ooo   88    88 88V8o 88 8P         88       88    88    88 88V8o 88 `8bo.                              
# 88~~~   88    88 88 V8o88 8b         88       88    88    88 88 V8o88   `Y8b.                            
# 88      88b  d88 88  V888 Y8b  d8    88      .88.   `8b  d8' 88  V888 db   8D                            
# YP      ~Y8888P' VP   V8P  `Y88P'    YP    Y888888P  `Y88P'  VP   V8P `8888Y'        



from distutils.log import ERROR
import os, sys, time, zeep, pytz, socket, html, glob
import shutil, pandas, xmltodict, json, csv, psycopg2
from re import S
from tkinter import EXCEPTION

from configparser import ConfigParser
from datetime import datetime
from collections import OrderedDict
from sqlalchemy import create_engine, false
from pathlib import Path
from bs4 import BeautifulSoup, Tag

class Lattes:

    def __init__(self):
        self.xml = None
        self.json = None
        self.id = None

    @staticmethod
    def config_db_connection(filename='d:/database.ini', section='postgresql'):
        parser = ConfigParser()
        parser.read(filename)
        db = {}
        if parser.has_section(section):
            params = parser.items(section)
            for param in params:
                db[param[0]] = param[1]
        else:
            raise Exception('Section {0} not found in the {1} file'.format(section, filename))
        return db

    @staticmethod
    def insert_xml(id, xml):
        sql = """INSERT INTO public."lattes_xml"(
            id, xml)
            VALUES(%s, %s::xml)
            ON CONFLICT (id)
            DO
            UPDATE SET
            xml = EXCLUDED.xml,
            ;
            """
        data = (id,
                xml,
                )
        conn = None
        try:
            params = Lattes.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.execute(sql, data)
            conn.commit()
            cur.close()
            return("XML inserted.")
        except (Exception, psycopg2.DatabaseError) as error:
            return ("Erro ao Inserir Currículo no BD: ", error)
        finally:
            if conn is not None:
                conn.close()   
    @staticmethod
    def insert_json(id, json):
        sql = """INSERT INTO public."lattes_json"(
            id, json)
            VALUES(%s, %s::json)
            ON CONFLICT (id)
            DO
            UPDATE SET
            json = EXCLUDED.json,
            ;
            """
        data = (id,
                json.dumps(json)
               )
        conn = None
        try:
            params = Lattes.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.execute(sql, data)
            conn.commit()
            cur.close()
            return("XML inserted.")
        except (Exception, psycopg2.DatabaseError) as error:
            return (error)
        finally:
            if conn is not None:
                conn.close()                     

    @staticmethod
    def insert_lattes(id, data_atualizacao):
        sql = """INSERT INTO public."lattes"(
            id, last_updated)
            VALUES(%s, TIMESTAMP %s)
            ON CONFLICT (id)
            DO
            UPDATE SET
            last_updated = EXCLUDED.last_updated,
            created_at = now()
            ;
            """
        data = (id,
                data_atualizacao.strftime('%Y-%m-%dT%H:%M:%S.%f'))
        conn = None
        try:
            params = Lattes.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.execute(sql, data)
            conn.commit()
            cur.close()
            return True
        except (Exception, psycopg2.DatabaseError) as error:
            return ("Erro ao Inserir Currículo no BD: ", error)
        finally:
            if conn is not None:
                conn.close()      

    @staticmethod
    def insert_palavras_chave_no_bd (data):
        sql = 'INSERT INTO public."palavras_chave"(id, palavra) VALUES(%(id)s, %(palavra)s);'
        data = []
        #data = ({'id': self.id, 'palavra': palavra} for palavra in self.palavras_chave)
        conn = None
        try:
            params = Lattes.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.executemany(sql, data)
            conn.commit()
            cur.close()
            print("Banco de dados atualizado.")
            return("Data inserted.")
        except (Exception, psycopg2.DatabaseError) as error:
            print("Erro ao Inserir Palavras_Chaves no BD: ", error)
            return (error)
        finally:
            if conn is not None:
                conn.close()

    @staticmethod
    def insere_dados_pessoais_no_bd(self, data):
        sql = '''
            INSERT INTO public."dados_pessoais" 
                (id, nome, cpf, email, telefone, chamada, sexo, regiao, nomes_citacao) 
                VALUES
                (%(id)s, %(nome)s, %(cpf)s, %(email)s, %(telefone)s, %(chamada)s, %(sexo)s, %(regiao)s, %(nomes_citacao)s) ;
            '''
        # data = ({
        #     'id': self.id,
        #     'nome': self.nome_completo,
        #     'cpf': self.CPF,
        #     'email': self.emails,
        #     'telefone': self.telefones,
        #     'chamada': self.chamada,
        #     'sexo': self.sexo,
        #     'regiao': self.regiao,
        #     'nomes_citacao': self.nomes_citação
        # })
        conn = None
        try:
            params = Lattes.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.execute(sql, data)
            conn.commit()
            cur.close()
            print("Banco de dados atualizado.")
            return("Data inserted.")
        except (Exception, psycopg2.DatabaseError) as error:
            print("Erro ao Inserir Dados PEssoais no BD: ", error)
            return (error)
        finally:
            if conn is not None:
                conn.close()

    @staticmethod
    def get_bd_data_atualizacao(id):
        sql = """SELECT last_updated from public."lattes"
        where id = %s;
        """
        data = (id,)
        try:
            conn = None
            params = Lattes.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.execute(sql, data)
            bd_data_atualizacao = cur.fetchone()[0].replace(tzinfo=pytz.UTC)
            cur.close()
            return bd_data_atualizacao
        except (Exception, psycopg2.DatabaseError) as error:
            return (error)
        finally:
            if conn is not None:
                conn.close()

    @staticmethod
    def get_json_bd(id):
        print('Pegando lattes no BD.')
        sql = """SELECT last_updated, created_at, json from public."lattes"
        where id = %s;
        """
        data = (id,)
        conn = None
        try:
            params = Lattes.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.execute(sql, data)

            resultado = cur.fetchone()

            bd_data_atualizacao = resultado[0].replace(tzinfo=pytz.UTC)
            bd_created_at = resultado[1].replace(tzinfo=pytz.UTC)
            json = resultado[2]
            cur.close()
            return bd_data_atualizacao, bd_created_at, json
        except (Exception, psycopg2.DatabaseError) as error:
            return (error)
        finally:
            if conn is not None:
                conn.close()

    @staticmethod
    def get_list_ids_dados_pessoais_data (data):
        sql = '''
            select distinct "carga_dados_pessoais".id from "carga_dados_pessoais" join "all_lattes"
            on CAST ("carga_dados_pessoais".id as BIGINT) = "all_lattes".id
            WHERE "all_lattes".dt_atualizacao > %s        
            '''
        conn = None
        try:
            params = Lattes.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.execute(sql, data)
            ids = cur.fetchall()
            conn.commit()
            cur.close()
            return ids
        except (Exception, psycopg2.DatabaseError) as error:
            return (error)
        finally:
            if conn is not None:
                conn.close()