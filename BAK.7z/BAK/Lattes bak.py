import io, os, time
from zipfile import ZipFile
import zeep
import xmltodict, json, pandas
import psycopg2
from configparser import ConfigParser
from datetime import date, datetime
import pytz
import ctypes
from ctypes.wintypes import MAX_PATH
import socket
from Indicadores import Indicadores





class Lattes:
    '''Classe que representa um currículo Lattes, com todos os seus indicadores.

    Principais métodos:
        read_zip_from_disk - 
            Carrega o Lattes compactado (arquivo físico no HD) na memória
            Pega o XML do arquivo compactado
        get_zip_from_SOAP - Pega o Lattes compactado do CNPq via SOAP
        read_xml_from_zip - Uma vez pego o lattes compactado, transmorma em xml
            Também inicializa a classe Indicadores
            Também atualiza o BD com o xml
        get_atualizacao_SOAP - pega a data de atualização do Lattes no CNPq via SOAP
        get_id - pega o id do CNPq via SOAP com os argumentos nome, data de nascimento e CPF
        get_xml_from_zip - pega o xml através do Lattes compactado carregada na memória
        load_carga - 
            Método Estático - Pega uma carga de ids
            Pega arquivos zip e salva no disco
        get_and_save_zip - pega o arquivo compactado do CNPq via SOAP e o salva no disco
        get_xml - Pega o xml de um Currículo Lattes, sendo que verifica a necessidade antes.
        get_xml_bd - Pega o xml do Banco de Dados Postgress
        get_bd_data_atualizacao - Pega data de atualização do Banco de Dados Postgress
        





    '''
    
    def __init__(self, 
                 id = '7281587998425548', 
                 wsdl = 'http://servicosweb.cnpq.br/srvcurriculo/WSCurriculo?wsdl', 
                 path_to_save_file = 'C:/Users/albertos/CNPq/Lattes/Downloads',
                 carga = 'C:/Users/albertos/CNPq/Lattes/Planilhas/R358737.csv'
                 ) :
        settings = zeep.Settings(strict=True, xml_huge_tree=True) 
        self.zip_lattes = None
        self.xml = None
        self.json_lattes = None
        self.data_atualizacao = None
        self.bd_data_atualizacao = None
        self.bd_created_at = None
        self.id = id
        self.wsdl = wsdl
        self.path = path_to_save_file
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        if local_ip == '10.30.12.10':
            self.can_get_soap = True
            self.path = 'C:/Users/albertos/CNPq/Lattes/Downloads'
        else:
            self.can_get_soap = False
            self.path = 'C:/Users/silva/CNPq/Lattes/Downloads'
        self.indicadores = None
        self.carga = carga
        

        #Getting Documents Folder
        # if path_to_save_file[0:11] == '~Documents/'
        #     dll = ctypes.windll.shell32
        #     buf = ctypes.create_unicode_buffer(MAX_PATH + 1)
        # if (not dll.SHGetSpecialFolderPathW(None, buf, 0x0005, False)) or (path_to_save_file[0:2] == '~/') :
        #     buf = str(Path.home())
        # path_to_save_file = os.path.join(buf, path_to_save_file)
    
    def get_zip_from_SOAP(self, id=None, set_auto_import=False, num_errors = 0):
        self.zip_lattes = None
        if not id == None:
            self.id = id
        if self.can_get_soap:
            # print ('Tentando recuperar Lattes compactado via SOAP')
            try:
                client = zeep.Client(wsdl=self.wsdl)
                self.zip_lattes = client.service.getCurriculoCompactado(self.id)
                self.ocorrencia = client.service.getOcorrenciaCV(self.id)
            except:
                num_errors += 1
                time.sleep(num_errors**3)
                self.get_zip_from_SOAP(id = self.id, set_auto_import = set_auto_import, num_errors = num_errors)

            while not self.ocorrencia == "Curriculo recuperado com sucesso!" and num_errors < 10:
                num_errors += 1
                print (f'Erro {num_errors}: "{self.ocorrencia}"')
                if self.ocorrencia == 'Nenhum curriculo encontrado!' or self.ocorrencia == 'Mais de um curriculo atende ao criterio informado!' or self.ocorrencia == 'Nenhum curriculo encontrado!':
                    return False
                time.sleep(num_errors**3)
                self.zip_lattes = client.service.getCurriculoCompactado(self.id)
                self.ocorrencia = client.service.getOcorrenciaCV(self.id)
            if num_errors >= 10:
                return False
            if not self.zip_lattes == None:
                print('Lattes compactado recuperado via SOAP')
                if set_auto_import:
                    self.read_xml_from_zip()
                return True
        else:
            print('Impossível recuperar SOAP - IP errado. Tentando recuperar pelo arquivo.')
            self.read_zip_from_disk()
            if self.zip_lattes == None:
                print('Impossível recuperar arquivo do disco. Erro.')
                return False
            else:
                print('Arquivo zip recuperado do disco.')
                return True

    def read_xml_from_zip (self):
        # self.save_zip_to_disk()
        self.get_xml_from_zip()
        self.indicador = Indicadores(self.xml)
        self.data_atualizacao = self.indicador.data_atualizcao
        self.insert_xml()

    def get_atualizacao_SOAP (self, id=None):
        if not id == None:
            self.id = id
            self.get_zip_from_SOAP()
            if not self.xml == None:
                self.get_xml()
        if self.can_get_soap:
            client = zeep.Client(wsdl=self.wsdl)
            self.data_atualizacao = client.service.getDataAtualizacaoCV(self.id)
            if self.data_atualizacao == None:
                raise ValueError('Invalid ID') 
            else:
                self.data_atualizacao = datetime.strptime(self.data_atualizacao, '%d/%m/%Y %H:%M:%S').replace(tzinfo=pytz.UTC)
                print ("Data de atualização pega via SOAP:", self.data_atualizacao)
        else:
            return('Impossível recuperar SOAP')

              
            
    def get_id (self, cpf = "69045542153", nomeCompleto="Alberto de Campos e Silva", dataNascimento="10/05/1976"):
        client = zeep.Client(wsdl=self.wsdl)
        self.id = client.service.getIdentificadorCNPq(cpf, nomeCompleto, dataNascimento)
        if self.id == None:
            raise ValueError('Invalid CPF, Name or DateBirth informed.')
        print ("ID do usuário pego pelos dados pessoais.")
            
    def get_xml_from_zip(self):
        if self.zip_lattes == None:
            return False
        try:
            with ZipFile(io.BytesIO(self.zip_lattes)) as myzip:
                with myzip.open(myzip.namelist()[0]) as myfile:
                    self.xml = myfile.read().decode('iso-8859-1').replace('encoding="ISO-8859-1" ', '')
            print("XML atualizado a partir do Lattes compactado.")
            return True
        except:
            print("Error in File - Could not retrieve zipped information.")
            return False

    def get_json(self):
        if self.xml == None:
            self.get_xml()
        self.json_lattes = xmltodict.parse(self.xml)
              
    def save_zip_to_disk (self):
        if self.zip_lattes == None:
            if self.get_zip_from_SOAP():
                filename = "Lattes_"+ self.id + ".zip"
                file_path = os.path.join(self.path, filename)
                with open(file_path , 'wb') as f:
                    f.write(self.zip_lattes)
                print("Arquivo compactado salvo no disco.")
                return True
            else:
                return False

    def read_zip_from_disk(self):
        filename = "Lattes_"+ self.id + ".zip"
        try:
            file_path = os.path.join(self.path, filename)
            with open(file_path , 'rb') as f:
                self.zip_lattes = f.read()
            print("Arquivo compactado lido no disco.")
            return self.get_xml_from_zip()
        except:
            print("Could not read file from HD. Error.")
            return False
            
    def save_xml_to_disk (self):
        if self.xml == None:
            self.get_xml()
        filename = "Lattes_"+ self.id + ".xml"
        file_path = os.path.join(self.path, filename)
        with open(file_path, 'w', encoding='utf-8') as f:
            f.write(self.xml)
        print("Arquivo em XML salvo no disco.")

    def read_xml_from_disk (self):
        filename = "Lattes_"+ self.id + ".xml"
        file_path = os.path.join(self.path, filename)
        with open(file_path, 'r', encoding='utf-8') as f:
            self.xml = f.read()
        print("Arquivo em XML lido no disco.")   

    def save_json_to_disk (self):
        if self.json_lattes == None:
            self.get_json()
        filename = "Lattes_"+ self.id + ".json"
        file_path = os.path.join(self.path, filename)
        with open(file_path, 'w', encoding='utf-8') as f:
            json.dump(self.json_lattes, f)
        print("Arquivo em JSON salvo no disco.")

    def read_json_from_disk(self):
        filename = "Lattes_"+ self.id + ".json"
        file_path = os.path.join(self.path, filename)
        with open(file_path, 'r', encoding='utf-8') as f:
            self.json_lattes = f.read()
        print("Arquivo em JSON lido no disco.")

    def save_to_disk (self, path = None):
        if not path == None:
            self.path = path
        self.save_zip_to_disk()
        self.save_xml_to_disk()
        self.save_json_to_disk()

    def read_from_disk (self, path = None):
        if not path == None:
            self.path = path
        self.read_zip_from_disk()
        self.read_xml_from_disk()
        self.read_json_from_disk()
        
    def config_db_connection(self, filename='database.ini', section='postgresql'):
        # create a parser
        parser = ConfigParser()
        # read config file
        parser.read(filename)

        # get section, default to postgresql
        db = {}
        if parser.has_section(section):
            params = parser.items(section)
            for param in params:
                db[param[0]] = param[1]
        else:
            raise Exception('Section {0} not found in the {1} file'.format(section, filename))

        return db

    def insert_xml(self):
        ##print("Getting bd.data.atualizacao")
        self.get_bd_data_atualizacao()
        # print ('Bd Data Atualização', self.bd_data_atualizacao)
        if self.data_atualizacao == None:
            ##print("Getting lattes.data_atualizacao.")
            self.get_atualizacao_SOAP()
        # print ('SOAP Data Atualização', self.data_atualizacao)

        if self.bd_data_atualizacao == None or (
            self.data_atualizacao > self.bd_data_atualizacao):
            ##print ("Inserting xml to Postgree")
           #insert a new xml into the table 
            sql = """INSERT INTO public."Lattes"(
                id, xml_lattes, last_updated)
                VALUES(%s, %s::xml, TIMESTAMP %s)
                ON CONFLICT (id) 
                DO 
                UPDATE SET 
                xml_lattes = EXCLUDED.xml_lattes,
                last_updated = EXCLUDED.last_updated,
                created_at = now()
                ;
                """
            if self.xml == None:
                ##print("Getting xml.")
                self.get_xml()
            data = (self.id, 
                    self.xml,
                    self.data_atualizacao.strftime('%Y-%m-%dT%H:%M:%S.%f'))
            # print("Data tuple: ", data)
            conn = None
            # result_id=""
            try:
                # read database configuration
                params = self.config_db_connection()
                # print("params setted")
                # connect to the PostgreSQL database
                conn = psycopg2.connect(**params)
                # create a new cursor
                cur = conn.cursor()
                # print("Cursor opened")
                # execute the INSERT statement
                cur.execute(sql, data)
                # print("Cursor executed.")
                # get the generated id back
                # result_id = cur.fetchone()[0]
                # print ("Result Fetched")
                # commit the changes to the database
                conn.commit()
                # close communication with the database
                cur.close()
                print("Banco de dados atualizado.")
                return("XML inserted.")
            except (Exception, psycopg2.DatabaseError) as error:
                print("Erro ao Inserir Currículo no BD: ", error)
                return (error)
            finally:
                if conn is not None:
                    conn.close()

            # return result_id   
        else:
            ##print ("XML already up to date")
            print("XML já está atualizado.") 
            return ("XML already up to date") 

    def insert_json(self):
        ##print("Getting bd.data.atualizacao")
        self.get_bd_data_atualizacao()
        # print ('Bd Data Atualização', self.bd_data_atualizacao)
        if self.data_atualizacao == None:
            ##print("Getting lattes.data_atualizacao.")
            self.get_atualizacao_SOAP()
        # print ('SOAP Data Atualização', self.data_atualizacao)

        if self.bd_data_atualizacao == None or (
            self.data_atualizacao > self.bd_data_atualizacao):
            ##print ("Inserting xml to Postgree")
           #insert a new xml into the table 
            sql = """INSERT INTO public."Lattes"(
                id, xml_lattes, json_lattes, last_updated)
                VALUES(%s, %s::xml, %s::json, TIMESTAMP %s)
                ON CONFLICT (id) 
                DO 
                UPDATE SET 
                xml_lattes = EXCLUDED.xml_lattes,
                json_lattes = EXCLUDED.json_lattes,
                last_updated = EXCLUDED.last_updated,
                created_at = now()
                ;
                """
            if self.xml == None:
                ##print("Getting xml.")
                self.get_xml()
            data = (self.id, 
                    self.xml,
                    json.dumps(self.json_lattes), 
                    self.data_atualizacao.strftime('%Y-%m-%dT%H:%M:%S.%f'))
            # print("Data tuple: ", data)
            conn = None
            # result_id=""
            try:
                # read database configuration
                params = self.config_db_connection()
                # print("params setted")
                # connect to the PostgreSQL database
                conn = psycopg2.connect(**params)
                # create a new cursor
                cur = conn.cursor()
                # print("Cursor opened")
                # execute the INSERT statement
                cur.execute(sql, data)
                # print("Cursor executed.")
                # get the generated id back
                # result_id = cur.fetchone()[0]
                # print ("Result Fetched")
                # commit the changes to the database
                conn.commit()
                # close communication with the database
                cur.close()
                print("Banco de dados atualizado.")
                return("XML inserted.")
            except (Exception, psycopg2.DatabaseError) as error:
                print("Erro ao Inserir Currículo no BD: ", error)
                return (error)
            finally:
                if conn is not None:
                    conn.close()

            # return result_id   
        else:
            ##print ("XML already up to date")
            print("XML já está atualizado.") 
            return ("XML already up to date") 


    def get_bd_data_atualizacao(self):
        sql = """SELECT last_updated from public."Lattes"
        where id = %s;
        """

        data = (self.id,)
        conn = None
        try:
            params = self.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.execute(sql, data)
            self.bd_data_atualizacao = cur.fetchone()[0].replace(tzinfo=pytz.UTC)
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            print("Erro ao recuperar Data de Atualização do Currículo no BD: ", error)
        finally:
            if conn is not None:
                conn.close()
        print("Data de atualização pega do Banco de dados:", self.bd_data_atualizacao)
        return self.bd_data_atualizacao          

    def get_xml_bd(self):
        print('Pegando lattes no BD.')
        sql = """SELECT last_updated, created_at, xml_lattes, json_lattes from public."Lattes"
        where id = %s;
        """

        data = (self.id,)
        conn = None
        try:
            params = self.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.execute(sql, data)

            resultado = cur.fetchone()

            self.bd_data_atualizacao = resultado[0].replace(tzinfo=pytz.UTC)
            self.bd_created_at = resultado[1].replace(tzinfo=pytz.UTC)
            self.xml = resultado[2] 
            self.json_lattes = resultado[3] 

            # self.bd_data_atualizacao = self.bd_data_atualizacao.replace(tzinfo=pytz.UTC)

            cur.close()
            print("XML e JSON pegos do Banco de Dados.")
            return ("Fetched xml.")
        except (Exception, psycopg2.DatabaseError) as error:
            print("XML e JSON inexistentes no Banco de Dados. Erro: ", error)
            return (error)
        finally:
            if conn is not None:
                conn.close()

        return ("Unknown error.")

    def get_xml(self, id=None):
        '''Pega o xml de um Currículo Lattes, sendo que verifica a necessidade antes.

        Será usado a seguinte ordem de prioridade:
        1. Banco de Dados Postgree
        2. Arquivo ZIP
        3. SOAP do Extrator Lattes

        Parâmetros:
        id (str): define o id do Lattes a ser pego.
        '''
        pegar_data_pelos_indicadores = False
        if not id == None:
            self.id = id
        if self.bd_data_atualizacao == None:
            self.get_bd_data_atualizacao()
            if not self.bd_data_atualizacao == None:
                if self.data_atualizacao == None:
                    self.get_atualizacao_SOAP()
                    if self.data_atualizacao == None:
                        pegar_data_pelos_indicadores = True
        if self.bd_data_atualizacao == None or self.data_atualizacao == None or (
            self.data_atualizacao > self.bd_data_atualizacao):
            self.get_zip_from_SOAP()
        else:
            print('Não é necessário atualizar o currículo.')
        if pegar_data_pelos_indicadores:
            if self.indicadores == None:
                self.indicadores = Indicadores(self.xml)
                print ('Classe Indicadores criada')
            self.data_atualizacao = self.indicadores.data_atualizcao
            print('Data de atualização do Lattes pega pelo XML: ', self.data_atualizacao)

        if self.xml == None:
            self.get_xml_bd()
            if self.xml == None:
                self.get_xml_from_zip()
                if not self.xml == None:
                    self.insert_xml()

    

    def get_and_save_zip (self, id = None, set_verify_update=False):
        '''Baixa o Lattes compactado via SOAP e o salva no hd em formato ZIP

        Parâmetros:
        id (str): número identificador id do Lattes
        set_verify_update (Boolean): Se verdadeiro, verificará se o currículo está atualizado e o atualizará em caso negativo.

        Retorno:
        nada

        Exemplo:
        get_and_save_zip (id='6716436953396086')
        '''

        if not id == None:
            self.id = id
        if set_verify_update:
            self.get_xml()
        else:
            filename = "Lattes_"+ self.id + ".zip"
            file_path = os.path.join(self.path, filename)
            if not os.path.exists(file_path):
                return self.save_zip_to_disk()
            else:
                print('File already existis')
                return None

    @staticmethod
    def load_carga (carga = 'C:/Users/albertos/CNPq/Lattes/Planilhas/R358737.csv', max=-1):
        """Salva todos os currículos Lattes np HD do computador. Pode ser chamada sem inicialização.

        Exemplo de chamamento da função:
        from Lattes import Lattes
        Lattes.load_carga()

        Parâmetros:
        carga (str): caminho completo de onde se pode achar o arquivo com a carga a ser carregada.
            O arquivo pode ser baixado no seguinte endereço: http://memoria.cnpq.br/web/portal-lattes/extracoes-de-dados
        max (int): número máximo de arquivos a importar. Se negativo serão importados todos os arquivos.

        Returns:
        nothing

        """

        erros = []
        data = pandas.read_csv(carga, dtype = str)
        id_count = len(data)
        primeiro = True
        linhas_lidas = 0
        tempo_inicio = datetime.now()
        line_count = 0
        for id in data.NRO_ID_CNPQ:
            if line_count == 0:
                line_count += 1
                linhas_lidas += 1
                continue
            linhas_lidas += 1
            porcentagem = line_count / id_count
            if not porcentagem == 0:
                tempo_para_fim = (datetime.now() - tempo_inicio) * (1/porcentagem)
            porcentagem = round(100 * porcentagem, 0)
            fim = (tempo_inicio + tempo_para_fim).strftime("%d/%m/%Y, %H:%M:%S")
            print(f'{"{:,}".format(linhas_lidas)}: {porcentagem}% importados ({"{:,}".format(line_count)} de {"{:,}".format(id_count)}), com {print ("{:,}".format(erros))} erros. Acabará em {fim} - Importando Lattes: ', id)
            lattes = Lattes()
            lattes.path = 'C:/Users/albertos/CNPq/Lattes/Downloads'
            log_file = 'C:/Users/albertos/CNPq/Lattes/log.txt'
            resposta = lattes.get_and_save_zip(id)
            if resposta == None:
                id_count -= 1
                primeiro = False
                tempo_inicio = datetime.now()
            elif not resposta:
                line_count += 1
                erros.append(id)
                with open(log_file, 'a') as log:
                    log.write(id + '\n')
            else:
                line_count += 1
            if max > 0 and line_count > max:
                print ('Erros:' ,erros)
                break
        print ('Erros:' ,erros)

