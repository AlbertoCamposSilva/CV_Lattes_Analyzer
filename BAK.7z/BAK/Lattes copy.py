print("Importando Módulos")
import io, os, sys, time, zeep, pytz, socket, html, glob, shutil, pandas, xmltodict, json, csv, psycopg2
from tkinter import EXCEPTION
from zipfile import ZipFile
from configparser import ConfigParser
from datetime import datetime
from collections import OrderedDict
from sqlalchemy import create_engine, false
from pathlib import Path
from bs4 import BeautifulSoup, Tag
print('Módulos Importados')




class Lattes:
    '''Classe que representa um currículo Lattes, com todos os seus indicadores.

    Variáveis de Classe:
        Lattes.bd_lista_ids  ->  após chamar o método Lattes.get_bd_lista_ids(), 
            retorna lista com todos os ids no Postgrees.

Python - Class - Lattes
Documentação
 
Métodos Para Leitura do SOAP do Extrator Lattes:
get_zip_from_SOAP(
id= self.id, 
set_auto_save=True, 
num_errors = 0, 
path = 'C:/Downloads/')
Carrega o Lattes do Extrator Lattes, compactado, e o salva no disco caso tenha sido recuperado com sucesso.
Em caso de falha, retorna o erro.
Se set_auto_save for definifo como falso, não salvará o arquivo no disco.
get_atualizacao_SOAP
 id= self.id,
Pega a última data de atualização do Lattes.
get_id
cpf = "69045542153", 
nomeCompleto="Alberto de Campos e Silva", 
dataNascimento="10/05/1976"
Pega o ID do Lattes baseado nos dados de CPF, Nome Completo e Data de Nascimento. Todos os dados são obrigatórios.

Métodos para gravação e leitura no disco:
•	read_zip_from_disk
•	read_xml_from_disk
•	read_json_from_disk
•	read_from_disk -> faz todos acima
•	save_zip_to_disk
•	save_xml_to_disk
•	save_json_to_disk
•	save_to_disk -> faz todos acima
Parâmetros:
filename = 'Lattes_' + id + '.' + type, 
path = 'C:/Downloads/'
 
read_xml_from_zip -> Carrega o arquivo zip do disco e depois pega tanto o XML quanto o JSON.

Funções de Banco de Dados
insert_xml -> Insere o xml na tabela Lattes_xml
insert_json -> Insere o JSON e a data de atualização na tabela Lattes
get_bd_lista_ids -> Seleciona a lista de IDs da tabela Lattes.
get_bd_data_atualizacao -> Seleciona a data de atualização da tabela Lattes.
get_json_bd -> Seleciona todos os campos da tabela Lattes.

Funções de Automação
get_xml_auto_source
Pega o xml de um Currículo Lattes, sendo que verifica a necessidade antes.
Será usado a seguinte ordem de prioridade:
        1. Banco de Dados Postgree
        2. Arquivo ZIP
        3. SOAP do Extrator Lattes
Parâmetros:
        id (str): define o id do Lattes a ser pego.

get_atualizacao_JSON
Pega a data de atualização através do JSON já presente no Lattes.
Gerará exceção se não houver a variável self.JSON.
get_and_save_zip
Baixa o Lattes compactado via SOAP e o salva no hd em formato ZIP
Parâmetros:
•	id (str): número identificador id do Lattes
•	set_verify_update (Boolean): Se verdadeiro, verificará se o currículo está atualizado e o atualizará em caso negativo.
Exemplo:
        get_and_save_zip (id='6716436953396086')

Importador da Carga do Lattes
Todos os métodos são estáticos.
Lista de métodos:
lista_arquivos_no_HD (path)
Como é método estático, o path tem padrão para C:/Downloads e não para self.path
Retorna a lista dos IDs presentes no path, já formatado para permitir busca rápida.
O retorno se dá no formato: ids_já_carregados[0][1][2][3][4]
Onde 0, 1, 2, 3 e 4 são os primeiros caracteres do ID.
Isso permite a busca 100.000 mais rápida para eliminação de IDs duplicados.
db_engine
Retorna a engine  para que o PANDAS possa atualizar o BD.
Exemplo de código de uso:
        engine = Lattes.db_engine()
        Lattes.dados_pessoais.to_sql('dados_pessoais', engine, if_exists='replace')
carrega_dados_pessoais
        path = 'C:/Users/albertos/CNPq/Lattes/carga',
        insert_bd = True,
Carrega os IDs da planilha de dados pessoais a serem lidos.
Também atualiza a tabela “dados_pessoais” no BD com essa lista, eliminando qualquer tabela anterior.
Útil para saber quais currículos participaram de quais chamadas.

carrega_erros_anteriores
Carrega a lista de erros na importação da Carga.
Formato de lista simples, uma vez que se espera menos de 100.000 erros ao total.
Parâmetros:
•	Log_file = 'C:/Users/albertos/CNPq/Lattes/log.txt', 
carrega_bd_lista_ids
Carrega a lista de IDs já salva no Banco de Dados em formato JSON.
Mesmo padrão de formato de lista_arquivos_no_HD .
Para facilitar interoperabilidade, estuda-se não usar salvar JSON no Postgress e sim somente em arquivo. Ainda em análise.
move_files_temp_to_path
Por serem muitos arquivos, para facilitar o processo de IO no HD e não haver possibilidade de interferência, arquivos são baixados em diretório temporário.
Esta função move os arquivos do diretório temporário para o padrão.
Parâmetros:
•	path = 'c:/Downloads/', 
•	temp_path = path[:-1] + '_temp' + '/'
load_carga
Função que carrega todos os arquivos do Extrator Lattes.
Parâmetros:
     carga = 'C:/Users/albertos/CNPq/Lattes/Planilhas/R358737.csv', 
Planilha a ser carregada.
                    de_dados_pessoais = True,
Se serão baixados currículos das planilhas de dados pessoais baixadas do Relatorios.CNPq
                    de_carga = True,
Se serão baixados currículos da carga acima especificada.
                    max=-1, 
Quantos currículos, no máximo, serão baixados. Se inferior a zero, todos serão baixados.
                    data_mínima_de_atualização='01/01/2018', 
Somente serão baixados currículos atualizados no mínimo até essa data.
                    path = 'C:/Downloads/',
Local de onde os currículos serão baixados
                    log_file = 'C:/Users/albertos/CNPq/Lattes/log.txt',
Arquivo que conterá a lista de erros.
                    linhas_a_pular = 0,
Quantas linhas, do arquivo de Carga, deverão ser puladas.
                    tempo_a_esperar_em_horário_de_pico = 0.5,
Em horário comercial, será pausado por esse período, em segundos, entre cada carga. Útil para não sobrecarregar o BD do CNPq em horário comercial.
                    insere_no_bd = False,
Se haverá a inserção do arquivo zipado no BD.
                    temp_path = path[:-1] + '_temp' + '/'
Local de salvamento temporário dos arquivos.
                    num_imports_skip_before_log = 100,
Quantos inserts serão realizados antes de mostrar, na tela, o andamento da importação. Efeito apenas visual.
                    show_import_messages = False
Se as mensagens derivadas das funções de importação serão mostradas na tela ou não.

grava_arquivo_json
                    max=-1,
                    path = 'C:/Downloads/',
                    log_file = 'C:/Users/albertos/CNPq/Lattes/log_save_json.txt',
                    show_import_messages = False):
Carrega todos os JSON para o BD

Funções de Bibliometria
recorre_sobre_todo_json
Função que recorre sobre todo o JSON e transforma a lista de strings HTML SCAPE em UTF 8. Não deve ser chamada, listada aqui porque precisarei reaproveitar o código depois.
    def recorre_sobre_todo_json(self, d, path=None):
            if not path: path = []
            for k, v in d.items():
                if isinstance(v, dict) or isinstance(v, OrderedDict):
                    #print("Getting: ", k)
                    self.recorre_sobre_todo_json(v, path + [k])
                elif isinstance(v, list):
                    num = 0
                    for item in v:
                        #print("Unfolding List: ", v)
                        self.recorre_sobre_todo_json(item, path + [k] + [num])
                        num +=1
                else:
                    if not v == None:
                        d[k] = html.unescape(v)
                        #print("{2} - {0} : {1}".format(k, html.unescape(v), path))
                    else:
                        #print("{2} - {0} : {1}".format(k, v, path))
                        pass
            return d

get_xml
Principal função para transformar o arquivo ZIP baixado em XML interpretável e JSON pesquisável.
indicadores_append (descricao, ano)
Adiciona ao Pandas DataFrame Lattes.indicadores o indicador :
            'Id': [self.id],
            'Tipo': [descricao],
            'Ano': [int(ano)]
get_lista_indicadores
Lista de indicadores é uma tabela no Postgress que referencia cada indicador a um número. Serve para economizar espaço/memória, indexando um longo nome de indicador.
A função:
•	Pega a lista de indicadores no BD
•	Se não existir o indicador nessa lista, acrescenta esse no BD
•	Retorna o número do indicador em questão.
get_palavras_chave
Retorna lista de palavras-chaves em JSON abaixo do json indicado.
Parâmetros: json
Todas as palavras chaves abaixo desse json informado serão retornadas em forma de lista.
get_areas_conhecimento
Pega as áreas do conhecimento do pesquisador através do JSON e salva na tabela areas_conhecimento

get_autores
Retorna os autores de uma publicação.
Deve ser informado o json da publicação em questão. 
Ainda, retorna o número de autores e a posição do pesquisador nessa lista.

    '''
    lista_indicadores = {}
    bd_lista_ids = []
    indicadores = pandas.DataFrame()
    dados_pessoais = pandas.DataFrame()

    def __init__(self,
                 id = '7281587998425548',
                 wsdl = 'http://servicosweb.cnpq.br/srvcurriculo/WSCurriculo?wsdl',
                 path = 'D:/Lattes/',
                 carga = 'C:/Users/albertos/CNPq/Lattes/Planilhas/R358737.csv'
                 ) :
        settings = zeep.Settings(strict=True, xml_huge_tree=True)
        self.zip = None
        self.xml = None
        self.json = None
        self.data_atualizacao = None
        self.bd_data_atualizacao = None
        self.bd_created_at = None
        self.id = id
        self.wsdl = wsdl
        self.path = path
        self.bd_lista_ids = None
        hostname = socket.gethostname()
        local_ip = socket.gethostbyname(hostname)
        if local_ip == '10.30.12.10':
            self.can_get_soap = True
        else:
            self.can_get_soap = False
        self.indicadores = []
        self.publicações = []
        self.palavras_chave = []
        self.carga = carga
        self.areas = {
            'grande_area': [],
            'area': [],
            'sub-area': [],
            'especialidade': [],
        }

        self.emails = None
        self.telefones = None
        self.chamada = None
        self.regiao = None
        self.nomes_citação = None
        self.nome_completo = None
        self.nacionalidade = None
        self.CPF = None
        self.data_nascimento = None
        self.sexo = None
        self.areas_do_conhecimento = [('Grande Área', 'Área', 'Sub-Área', 'Especialidade')]
        self.lattes = {}


# .d8888.       .d88b.        .d8b.       d8888b.                               
# 88'  YP      .8P  Y8.      d8' `8b      88  `8D                               
# `8bo.        88    88      88ooo88      88oodD'                               
#   `Y8b.      88    88      88~~~88      88~~~                                 
# db   8D      `8b  d8'      88   88      88                                    
# `8888Y'       `Y88P'       YP   YP      88                                    
                                                                              
                                                                              
# d88888b db    db d8b   db  .o88b. d888888b d888888b  .d88b.  d8b   db .d8888. 
# 88'     88    88 888o  88 d8P  Y8 `~~88~~'   `88'   .8P  Y8. 888o  88 88'  YP 
# 88ooo   88    88 88V8o 88 8P         88       88    88    88 88V8o 88 `8bo.   
# 88~~~   88    88 88 V8o88 8b         88       88    88    88 88 V8o88   `Y8b. 
# 88      88b  d88 88  V888 Y8b  d8    88      .88.   `8b  d8' 88  V888 db   8D 
# YP      ~Y8888P' VP   V8P  `Y88P'    YP    Y888888P  `Y88P'  VP   V8P `8888Y'         

 
    def get_zip_from_SOAP(self, id=None, set_auto_save=True, num_errors = 0, path = None):
        if path == None:
            path = self.path
        self.ocorrencia = None
        self.zip = None
        if not id == None:
            self.id = id
        if self.can_get_soap:
            print (f'Tentando recuperar Lattes compactado {self.id} via SOAP')
            try:
                client = zeep.Client(wsdl=self.wsdl)
                self.zip = client.service.getCurriculoCompactado(self.id)
                self.ocorrencia = client.service.getOcorrenciaCV(self.id)
            except Exception as e:
                if self.ocorrencia == None:
                    self.ocorrencia = str(e)
            if not self.ocorrencia == "Curriculo recuperado com sucesso!" and num_errors < 3:
                num_errors += 1
                print (f'Erro {num_errors}: "{self.ocorrencia}".')
                if self.ocorrencia == 'Nenhum curriculo encontrado!' or self.ocorrencia == 'Mais de um curriculo atende ao criterio informado!' or self.ocorrencia == 'Nenhum curriculo encontrado!':
                    return self.ocorrencia
                tempo_a_dormir = (num_errors*4)**2
                print(f'Esperando {tempo_a_dormir} segundos.')
                time.sleep(tempo_a_dormir)
                print(f'Tentando novamente.')
                self.get_zip_from_SOAP(id = self.id, set_auto_save = set_auto_save, num_errors = num_errors)
            if self.ocorrencia == "Curriculo recuperado com sucesso!" and not self.zip == None:
                print('Lattes compactado recuperado via SOAP')
                if set_auto_save:
                    self.save_zip_to_disk(path)
                return self.ocorrencia
            elif num_errors >= 3:
                return self.ocorrencia
            else:
                return (self.ocorrencia + ' - Erro ao recuperar zip.')
        else:
            return "Wrong IP number. Can't get zipped Lattes from this IP number."


    def read_xml_from_zip (self, filename = None, path = None):
        self.read_zip_from_disk(filename = filename, path = path)
        self.get_xml()


    def get_atualizacao_SOAP (self, id=None):
        if not id == None:
            self.id = id
        if self.can_get_soap:
            client = zeep.Client(wsdl=self.wsdl)
            self.data_atualizacao = client.service.getDataAtualizacaoCV(self.id)
            if self.data_atualizacao == None:
                raise ValueError('Invalid ID') 
            else:
                self.data_atualizacao = datetime.strptime(self.data_atualizacao, '%d/%m/%Y %H:%M:%S').replace(tzinfo=pytz.UTC)
                print ("Data de atualização pega via SOAP:", self.data_atualizacao)
        else:
            return('Impossível recuperar SOAP')

    def get_id (self, cpf = "69045542153", nomeCompleto="Alberto de Campos e Silva", dataNascimento="10/05/1976"):
        client = zeep.Client(wsdl=self.wsdl)
        self.id = client.service.getIdentificadorCNPq(cpf, nomeCompleto, dataNascimento)
        if self.id == None:
            raise ValueError('Invalid CPF, Name or DateBirth informed.')
        print ("ID do usuário pego pelos dados pessoais.")


# d8888b.      d888888b      .d8888.      db   dD                               
# 88  `8D        `88'        88'  YP      88 ,8P'                               
# 88   88         88         `8bo.        88,8P                                 
# 88   88         88           `Y8b.      88`8b                                 
# 88  .8D        .88.        db   8D      88 `88.                               
# Y8888D'      Y888888P      `8888Y'      YP   YD                               
                                                                              
                                                                              
# d88888b db    db d8b   db  .o88b. d888888b d888888b  .d88b.  d8b   db .d8888. 
# 88'     88    88 888o  88 d8P  Y8 `~~88~~'   `88'   .8P  Y8. 888o  88 88'  YP 
# 88ooo   88    88 88V8o 88 8P         88       88    88    88 88V8o 88 `8bo.   
# 88~~~   88    88 88 V8o88 8b         88       88    88    88 88 V8o88   `Y8b. 
# 88      88b  d88 88  V888 Y8b  d8    88      .88.   `8b  d8' 88  V888 db   8D 
# YP      ~Y8888P' VP   V8P  `Y88P'    YP    Y888888P  `Y88P'  VP   V8P `8888Y' 


    @staticmethod
    def get_saving_path(self, type, path, id, create_path_if_new = True):
        filename = "Lattes_" + id + "." + type
        path_name = os.path.join(path, 'Lattes_' + type.upper())
        if type=="zip":
            full_path =  os.path.join(path_name, id[0], id[1])
        else:
            full_path = os.path.join(path_name, id[0], id[1], id[2], id[3], id[4])
        if create_path_if_new:
            Path(full_path).mkdir(parents=True, exist_ok=True)
        return os.path.join(full_path, filename)

    def read_zip_from_disk(self, filename = None, path = None):
        if path == None:
            path = self.path
        if filename == None:
            filename = Lattes.get_saving_path(type = "zip", path = path, id = self.id)
        with open(filename, 'rb') as f:
            self.zip = f.read()
        print("Arquivo compactado lido no disco.")
        #return self.get_xml()
        if not self.zip == None:
            return True
        else:
            return False

    def read_xml_from_disk (self, filename = None, path = None):
        if path == None:
            path = self.path
        if filename == None:
            filename = Lattes.get_saving_path("xml", path = path, id = self.id)
        with open(filename, 'r', encoding='utf-8') as f:
            self.xml = f.read()
        print("Arquivo em XML lido no disco.")

    def read_json_from_disk(self, filename = None, path = None):
        if path == None:
            path = self.path
        if filename == None:
            filename = Lattes.get_saving_path("JSON", path = path, id = self.id)
        with open(filename, 'r', encoding='utf-8') as f:
            self.json = json.load(f)
        print("Arquivo em JSON lido no disco.")

    def read_from_disk (self, path = None):
        if path == None:
            path = self.path
        if not path == None:
            self.path = path
        self.read_zip_from_disk()
        self.read_xml_from_disk()
        self.read_json_from_disk()

    def save_zip_to_disk (self, path = None):
        if path == None:
            path = self.path
        if path == None:
            path = Lattes.get_saving_path("zip", path = path, id = self.id)
        with open(path, 'wb') as f:
            f.write(self.zip)
        print("Arquivo compactado salvo no disco.")
        return True

    def save_xml_to_disk (self, filename = None, path = None):
        if path == None:
            path = self.path
        if filename == None:
            filename = Lattes.get_saving_path("xml", path = path, id = self.id)
        with open(filename, 'w', encoding='utf-8') as f:
            f.write(self.xml)
        print("Arquivo em XML salvo no disco.")

    def save_json_to_disk (self, filename = None, path = None):
        if path == None:
            path = self.path
        if filename == None:
            filename = Lattes.get_saving_path("JSON", path = path, id = self.id)
        with open(filename, 'w', encoding='utf-8') as f:
            json.dump(self.json, f, indent=4)
        print("Arquivo em JSON salvo no disco.")

    def save_to_disk (self, path = None):
        if not path == None:
            self.path = path
        self.save_zip_to_disk()
        self.save_xml_to_disk()
        self.save_json_to_disk()

# d8888b.       .d8b.       d888888b       .d8b.            d8888b.       .d8b.       .d8888.      d88888b 
# 88  `8D      d8' `8b      `~~88~~'      d8' `8b           88  `8D      d8' `8b      88'  YP      88'     
# 88   88      88ooo88         88         88ooo88           88oooY'      88ooo88      `8bo.        88ooooo 
# 88   88      88~~~88         88         88~~~88           88~~~b.      88~~~88        `Y8b.      88~~~~~ 
# 88  .8D      88   88         88         88   88           88   8D      88   88      db   8D      88.     
# Y8888D'      YP   YP         YP         YP   YP           Y8888P'      YP   YP      `8888Y'      Y88888P 
                                                                                                         
                                                                                                         
# d88888b db    db d8b   db  .o88b. d888888b d888888b  .d88b.  d8b   db .d8888.                            
# 88'     88    88 888o  88 d8P  Y8 `~~88~~'   `88'   .8P  Y8. 888o  88 88'  YP                            
# 88ooo   88    88 88V8o 88 8P         88       88    88    88 88V8o 88 `8bo.                              
# 88~~~   88    88 88 V8o88 8b         88       88    88    88 88 V8o88   `Y8b.                            
# 88      88b  d88 88  V888 Y8b  d8    88      .88.   `8b  d8' 88  V888 db   8D                            
# YP      ~Y8888P' VP   V8P  `Y88P'    YP    Y888888P  `Y88P'  VP   V8P `8888Y'        


    @staticmethod
    def config_db_connection(filename='database.ini', section='postgresql'):
        # create a parser
        parser = ConfigParser()
        # read config file
        parser.read(filename)

        # get section, default to postgresql
        db = {}
        if parser.has_section(section):
            params = parser.items(section)
            for param in params:
                db[param[0]] = param[1]
        else:
            raise Exception('Section {0} not found in the {1} file'.format(section, filename))

        return db

    def insert_xml(self):
        ##print("Getting bd.data.atualizacao")
        self.get_bd_data_atualizacao()
        # print ('Bd Data Atualização', self.bd_data_atualizacao)
        if self.data_atualizacao == None:
            ##print("Getting lattes.data_atualizacao.")
            self.get_atualizacao_SOAP()
        # print ('SOAP Data Atualização', self.data_atualizacao)

        if self.bd_data_atualizacao == None or (
            self.data_atualizacao > self.bd_data_atualizacao):
            # self.insert_json()
            ##print ("Inserting xml to Postgree")
            #insert a new xml into the table
            sql = """INSERT INTO public."lattes_xml"(
                id, xml)
                VALUES(%s, %s::xml)
                ON CONFLICT (id)
                DO
                UPDATE SET
                xml = EXCLUDED.xml,
                ;
                """
            if self.xml == None:
                ##print("Getting xml.")
                self.get_xml()
            data = (self.id,
                    self.xml,
                    )
            # print("Data tuple: ", data)
            conn = None
            # result_id=""
            try:
                # read database configuration
                params = Lattes.config_db_connection()
                # print("params setted")
                # connect to the PostgreSQL database
                conn = psycopg2.connect(**params)
                # create a new cursor
                cur = conn.cursor()
                # print("Cursor opened")
                # execute the INSERT statement
                cur.execute(sql, data)
                # print("Cursor executed.")
                # get the generated id back
                # result_id = cur.fetchone()[0]
                # print ("Result Fetched")
                # commit the changes to the database
                conn.commit()
                # close communication with the database
                cur.close()
                print("Banco de dados atualizado. XML inserted.")
                return("XML inserted.")
            except (Exception, psycopg2.DatabaseError) as error:
                print("Erro ao Inserir Currículo no BD: ", error)
                return (error)
            finally:
                if conn is not None:
                    conn.close()

            # return result_id
        else:
            ##print ("XML already up to date")
            print("XML já está atualizado.")
            return ("XML already up to date")

    def insert_json(self):
        print(f"Inserting {self.id} JSON in BD.")

        sql = """INSERT INTO public."lattes_json"(
            id, json)
            VALUES(%s, %s::json)
            ON CONFLICT (id)
            DO
            UPDATE SET
            json = EXCLUDED.json,
            ;
            """
        data = (self.id,
                json.dumps(self.json)
               )
        # print("Data tuple: ", data)
        conn = None
        # result_id=""
        try:
            # read database configuration
            params = Lattes.config_db_connection()
            # print("params setted")
            # connect to the PostgreSQL database
            conn = psycopg2.connect(**params)
            # create a new cursor
            cur = conn.cursor()
            # print("Cursor opened")
            # execute the INSERT statement
            cur.execute(sql, data)
            # print("Cursor executed.")
            # get the generated id back
            # result_id = cur.fetchone()[0]
            # print ("Result Fetched")
            # commit the changes to the database
            conn.commit()
            # close communication with the database
            cur.close()
            print("Banco de dados atualizado.")
            return("XML inserted.")
        except (Exception, psycopg2.DatabaseError) as error:
            print("Erro ao Inserir Currículo no BD: ", error)
            return (error)
        finally:
            if conn is not None:
                conn.close()

    def insert_lattes(self):
        print(f"Inserting {self.id} in Lattes BD.")
        sql = """INSERT INTO public."lattes"(
            id, last_updated)
            VALUES(%s, TIMESTAMP %s)
            ON CONFLICT (id)
            DO
            UPDATE SET
            last_updated = EXCLUDED.last_updated,
            created_at = now()
            ;
            """
        data = (self.id,
                self.data_atualizacao.strftime('%Y-%m-%dT%H:%M:%S.%f'))
        # print("Data tuple: ", data)
        conn = None
        # result_id=""
        try:
            # read database configuration
            params = Lattes.config_db_connection()
            # print("params setted")
            # connect to the PostgreSQL database
            conn = psycopg2.connect(**params)
            # create a new cursor
            cur = conn.cursor()
            # print("Cursor opened")
            # execute the INSERT statement
            cur.execute(sql, data)
            # print("Cursor executed.")
            # get the generated id back
            # result_id = cur.fetchone()[0]
            # print ("Result Fetched")
            # commit the changes to the database
            conn.commit()
            # close communication with the database
            cur.close()
            print("Banco de dados atualizado.")
            return("Data inserted.")
        except (Exception, psycopg2.DatabaseError) as error:
            print("Erro ao Inserir Currículo no BD: ", error)
            return (error)
        finally:
            if conn is not None:
                conn.close()

    def insert_palavras_chave_no_bd (self):
        sql = 'INSERT INTO public."palavras_chave"(id, palavra) VALUES(%(id)s, %(palavra)s);'
        data = []
        data = ({'id': self.id, 'palavra': palavra} for palavra in self.palavras_chave)
        conn = None
        try:
            params = Lattes.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.executemany(sql, data)
            conn.commit()
            cur.close()
            print("Banco de dados atualizado.")
            return("Data inserted.")
        except (Exception, psycopg2.DatabaseError) as error:
            print("Erro ao Inserir Palavras_Chaves no BD: ", error)
            return (error)
        finally:
            if conn is not None:
                conn.close()


    def insere_dados_pessoais_no_bd(self):
        sql = '''
            INSERT INTO public."dados_pessoais" 
                (id, nome, cpf, email, telefone, chamada, sexo, regiao, nomes_citacao) 
                VALUES
                (%(id)s, %(nome)s, %(cpf)s, %(email)s, %(telefone)s, %(chamada)s, %(sexo)s, %(regiao)s, %(nomes_citacao)s) ;
            '''
        data = ({
            'id': self.id,
            'nome': self.nome_completo,
            'cpf': self.CPF,
            'email': self.emails,
            'telefone': self.telefones,
            'chamada': self.chamada,
            'sexo': self.sexo,
            'regiao': self.regiao,
            'nomes_citacao': self.nomes_citação
        })
        conn = None
        try:
            params = Lattes.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.execute(sql, data)
            conn.commit()
            cur.close()
            print("Banco de dados atualizado.")
            return("Data inserted.")
        except (Exception, psycopg2.DatabaseError) as error:
            print("Erro ao Inserir Dados PEssoais no BD: ", error)
            return (error)
        finally:
            if conn is not None:
                conn.close()


    @staticmethod
    def get_bd_lista_ids ():
        sql = 'SELECT id from public."lattes";'

        conn = None
        try:
            params = Lattes.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.execute(sql)
            lista = bd_lista_ids = cur.fetchall()
            for id in lista:
                Lattes.bd_lista_ids.append(id[0])
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            print("Erro ao recuperar ids no BD: ", error)
        finally:
            if conn is not None:
                conn.close()
        print("Lista de IDs pega no Banco de Dados.")
        return Lattes.bd_lista_ids

    def get_bd_data_atualizacao(self):
        sql = """SELECT last_updated from public."lattes"
        where id = %s;
        """

        data = (self.id,)
        conn = None
        try:
            params = Lattes.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.execute(sql, data)
            self.bd_data_atualizacao = cur.fetchone()[0].replace(tzinfo=pytz.UTC)
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            print("Erro ao recuperar Data de Atualização do Currículo no BD: ", error)
        finally:
            if conn is not None:
                conn.close()
        print("Data de atualização pega do Banco de dados:", self.bd_data_atualizacao)
        return self.bd_data_atualizacao

    def get_json_bd(self):
        print('Pegando lattes no BD.')
        sql = """SELECT last_updated, created_at, json from public."lattes"
        where id = %s;
        """

        data = (self.id,)
        conn = None
        try:
            params = Lattes.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.execute(sql, data)

            resultado = cur.fetchone()

            self.bd_data_atualizacao = resultado[0].replace(tzinfo=pytz.UTC)
            self.bd_created_at = resultado[1].replace(tzinfo=pytz.UTC)
            self.json = resultado[2]

            # self.bd_data_atualizacao = self.bd_data_atualizacao.replace(tzinfo=pytz.UTC)

            cur.close()
            print("JSON pegos do Banco de Dados.")
            return ("Fetched json.")
        except (Exception, psycopg2.DatabaseError) as error:
            print("XML e JSON inexistentes no Banco de Dados. Erro: ", error)
            return (error)
        finally:
            if conn is not None:
                conn.close()

#  .d8b.  db    db d888888b  .d88b.  .88b  d88.  .d8b.  d888888b d88888b        
# d8' `8b 88    88 `~~88~~' .8P  Y8. 88'YbdP`88 d8' `8b `~~88~~' 88'            
# 88ooo88 88    88    88    88    88 88  88  88 88ooo88    88    88ooooo        
# 88~~~88 88    88    88    88    88 88  88  88 88~~~88    88    88~~~~~        
# 88   88 88b  d88    88    `8b  d8' 88  88  88 88   88    88    88.            
# YP   YP ~Y8888P'    YP     `Y88P'  YP  YP  YP YP   YP    YP    Y88888P        
                                                                              
                                                                              
# d88888b db    db d8b   db  .o88b. d888888b d888888b  .d88b.  d8b   db .d8888. 
# 88'     88    88 888o  88 d8P  Y8 `~~88~~'   `88'   .8P  Y8. 888o  88 88'  YP 
# 88ooo   88    88 88V8o 88 8P         88       88    88    88 88V8o 88 `8bo.   
# 88~~~   88    88 88 V8o88 8b         88       88    88    88 88 V8o88   `Y8b. 
# 88      88b  d88 88  V888 Y8b  d8    88      .88.   `8b  d8' 88  V888 db   8D 
# YP      ~Y8888P' VP   V8P  `Y88P'    YP    Y888888P  `Y88P'  VP   V8P `8888Y' 

    def get_xml_auto_source(self, id=None, pegar_data_pelos_indicadores = True):
        '''Pega o xml de um Currículo Lattes, sendo que verifica a necessidade antes.

        Será usado a seguinte ordem de prioridade:
        1. Banco de Dados Postgree
        2. Arquivo ZIP
        3. SOAP do Extrator Lattes

        Parâmetros:
        id (str): define o id do Lattes a ser pego.
        '''
        if not id == None:
            self.id = id
        if self.bd_data_atualizacao == None:
            self.get_bd_data_atualizacao()
            if not self.bd_data_atualizacao == None:
                if self.data_atualizacao == None:
                    self.get_atualizacao_SOAP()
                    if self.data_atualizacao == None:
                        pegar_data_pelos_indicadores = True
        if self.bd_data_atualizacao == None or self.data_atualizacao == None or (
            self.data_atualizacao > self.bd_data_atualizacao):
            self.get_zip_from_SOAP()
        else:
            print('Não é necessário atualizar o currículo.')
        if pegar_data_pelos_indicadores:
            self.data_atualizacao = self.get_atualizacao_JSON()
            print('Data de atualização do Lattes pega pelo XML: ', self.data_atualizacao)

        if self.xml == None:
            self.get_xml()

    def get_atualizacao_JSON (self):
        return datetime.strptime(self.json['CURRICULO-VITAE']['@DATA-ATUALIZACAO'] + self.json['CURRICULO-VITAE']['@HORA-ATUALIZACAO'], '%d%m%Y%H%M%S').replace(tzinfo=pytz.UTC)

    def get_and_save_zip (self, id = None, set_verify_update=False, path = None):
        '''Baixa o Lattes compactado via SOAP e o salva no hd em formato ZIP

        Parâmetros:
        id (str): número identificador id do Lattes
        set_verify_update (Boolean): Se verdadeiro, verificará se o currículo está atualizado e o atualizará em caso negativo.

        Retorno:
        nada

        Exemplo:
        get_and_save_zip (id='6716436953396086')
        '''
        if not path == None:
            self.path = path
        if not id == None:
            self.id = id
        if set_verify_update:
            self.get_xml()
        else:
            filename = "Lattes_"+ self.id + ".zip"
            file_path = os.path.join(self.path, filename)
            if not os.path.exists(file_path):
                return self.save_zip_to_disk()
            else:
                #print('File already existis')
                return None

    @staticmethod
    def update_bd_from_zip (id, path='D:/Lattes/Lattes_ZIP/'):
        lattes = Lattes(id = id)
        if lattes.read_zip_from_disk(path):
            lattes.get_xml()
            lattes.get_id_by_xml()
            lattes.insere_dados_pessoais_no_bd()
            lattes.get_all_indicadores()
            lattes.get_areas_conhecimento()
            lattes.get_publicacoes()
            lattes.get_palavras_chave()
            lattes.insert_palavras_chave_no_bd()
            lattes.insert_lattes()
            lattes.update_indicadores_bd()
            return True
        else:
            return False



# d888888b .88b  d88. d8888b.  .d88b.  d8888b. d888888b                          
#   `88'   88'YbdP`88 88  `8D .8P  Y8. 88  `8D `~~88~~'                          
#    88    88  88  88 88oodD' 88    88 88oobY'    88                             
#    88    88  88  88 88~~~   88    88 88`8b      88                             
#   .88.   88  88  88 88      `8b  d8' 88 `88.    88                             
# Y888888P YP  YP  YP 88       `Y88P'  88   YD    YP                             
                                                                               
                                                                               
#  .d8b.  db      db           db       .d8b.  d888888b d888888b d88888b .d8888. 
# d8' `8b 88      88           88      d8' `8b `~~88~~' `~~88~~' 88'     88'  YP 
# 88ooo88 88      88           88      88ooo88    88       88    88ooooo `8bo.   
# 88~~~88 88      88           88      88~~~88    88       88    88~~~~~   `Y8b. 
# 88   88 88booo. 88booo.      88booo. 88   88    88       88    88.     db   8D 
# YP   YP Y88888P Y88888P      Y88888P YP   YP    YP       YP    Y88888P `8888Y' 


    @staticmethod
    def lista_arquivos_no_HD (path):
        print("Pegando lista de ids já salvos no HD.")
        ids_já_carregados = {}
        for x0 in range(10):
            ids_já_carregados[str(x0)] ={}
            for x1 in range(10):
                ids_já_carregados[str(x0)][str(x1)] = {}
                for x2 in range(10):
                    ids_já_carregados[str(x0)][str(x1)][str(x2)] = {}
                    for x3 in range(10):
                        ids_já_carregados[str(x0)][str(x1)][str(x2)][str(x3)] = {}
                        for x4 in range(10):
                            ids_já_carregados[str(x0)][str(x1)][str(x2)][str(x3)][str(x4)] = []
        diretórios_lidos = 0
        for x in os.walk(path):
            diretórios_lidos +=1
            print(f'    {round(diretórios_lidos/1.11,1)}% completos.\r', end="", flush=True)
            for y in glob.glob(os.path.join(x[0], '*.zip')):
                id = y[-20:-4]
                if id.isnumeric():
                    try:
                        ids_já_carregados[id[0]][id[1]][id[2]][id[3]][id[4]].append(id)
                    except:
                        print (id)
                        raise Exception
                else:
                    print (f'\n\nErro! {id} não é um número.')
        return ids_já_carregados
        
    @staticmethod
    def db_engine ():
        params = Lattes.config_db_connection()
        username = params['user']
        password = params['password']
        ipaddress = params['host']
        port = int(params['port'])
        dbname = params['database']
        return f'postgresql://{username}:{password}@{ipaddress}:{port}/{dbname}'

    @staticmethod
    def carrega_dados_pessoais (
        path = 'C:/Users/albertos/CNPq/Lattes/carga',
        insert_bd = True, 
        ):
        print('Pegando lista de arquivos para baixar:')
        files = [y for x in os.walk(path) for y in glob.glob(os.path.join(x[0], '*.xls'))]
        for file in files:
            dt = pandas.read_excel(file,header = 4)
            if 'Lattes' in dt:
                nome_arquivo = str(file).replace('\\', '/').split('/')[-1].split('.')[0]
                print(f'Carregando arquivo: {nome_arquivo}')
                dt.Lattes = dt.Lattes.str[-16:]
                for column in dt.columns:
                    if column[:7] == 'Unnamed':
                        del dt[column]
                dt['chamada'] = nome_arquivo
                Lattes.dados_pessoais = Lattes.dados_pessoais.append(dt, ignore_index=True)

        engine = Lattes.db_engine()
        Lattes.dados_pessoais.to_sql('dados_pessoais', engine, if_exists='replace')
    
    @staticmethod
    def carrega_erros_anteriores (log_file = 'C:/Users/albertos/CNPq/Lattes/log.txt'):
        print('Carregando erros anteriores.')
        erros = []
        if os.path.exists(log_file):
            with open(log_file) as file:
                json_erros = json.load(file) 
            for erro in json_erros:
                erros.append(erro['id'])
            del json_erros
        return erros

    @staticmethod
    def carrega_bd_lista_ids ():
        print('Carregando ids já salvos no Banco de Dados.')
        Lattes.get_bd_lista_ids()
        ids_no_bd = {}
        for x0 in range(10):
            ids_no_bd[str(x0)] = {}
            for x1 in range(10):
                ids_no_bd[str(x0)][str(x1)] = {}
                for x2 in range(10):
                    ids_no_bd[str(x0)][str(x1)][str(x2)] = {}
                    for x3 in range(10):
                        ids_no_bd[str(x0)][str(x1)][str(x2)][str(x3)] = {}
                        for x4 in range(10):
                            ids_no_bd[str(x0)][str(x1)][str(x2)][str(x3)][str(x4)] = []
        for id in Lattes.bd_lista_ids:
            id = str(id)
            while len(str(id)) < 16:
                id = '0' + id
            ids_no_bd[id[0]][id[1]][id[2]][id[3]][id[4]].append(id)
        del Lattes.bd_lista_ids
        return ids_no_bd

    @staticmethod
    def show_progress(tempo_inicio, num_imports_skip_before_log, linhas_totais, linhas_lidas, num_erros):

        if linhas_lidas % num_imports_skip_before_log == 0:
            os.system('cls')
            segundos_por_linha = (datetime.now() - tempo_inicio)/num_imports_skip_before_log
            tempo_para_fim = (linhas_totais - linhas_lidas) * segundos_por_linha
            porcentagem = round(100 * (linhas_lidas/linhas_totais), 1)
            segundos_por_linha_total = (datetime.now() - tempo_inicio)/(linhas_lidas)
            acabará_em_total = (tempo_inicio + (linhas_totais - linhas_lidas) * segundos_por_linha_total).strftime("%d/%m/%Y, %H:%M:%S")
            resposta = (f'Importação iniciada em {tempo_inicio.strftime("%d/%m/%Y, %H:%M:%S")}')
            resposta += (f'\n{porcentagem}% importados.\n')
            if not segundos_por_linha_total.total_seconds() == 0:
                resposta += (f'\nLinhas por segundo lidas (total): {round(1/segundos_por_linha_total.total_seconds(), 1)}')
            resposta +=  ('\n{:,} de {:,}'.format(linhas_lidas, linhas_totais))
            resposta +=  ('\n{:,} erros.\n'.format(num_erros))
            resposta += (f'\nAcabará em:')
            resposta += (f'\n    Cálculo considerando desde o início: {acabará_em_total}\n\n')
            return resposta

    @staticmethod
    def carrega_lista_ids_indicadores_bd ():
        bd_lista_ids = []
        sql = 'SELECT distinct id from public."indicadores";'
        conn = None
        try:
            params = Lattes.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.execute(sql)
            bd_lista_ids = cur.fetchall()
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            print("Erro ao recuperar ids no BD: ", error)
        finally:
            if conn is not None:
                conn.close()
        print("Lista de IDs pega no Banco de Dados.")

        ids_no_bd = {}
        for x0 in range(10):
            ids_no_bd[str(x0)] = {}
            for x1 in range(10):
                ids_no_bd[str(x0)][str(x1)] = {}
                for x2 in range(10):
                    ids_no_bd[str(x0)][str(x1)][str(x2)] = {}
                    for x3 in range(10):
                        ids_no_bd[str(x0)][str(x1)][str(x2)][str(x3)] = {}
                        for x4 in range(10):
                            ids_no_bd[str(x0)][str(x1)][str(x2)][str(x3)][str(x4)] = []
        for bd_id in bd_lista_ids:
            id = str(bd_id[0])
            while len(id) < 16:
                id = '0' + id
            ids_no_bd[id[0]][id[1]][id[2]][id[3]][id[4]].append(id)
        return ids_no_bd

    @staticmethod
    def move_files_temp_to_path (path = 'c:/Downloads/', temp_path = None):
        if temp_path == None:
            temp_path = path[:-1] + '_temp' + '/'
        print('Movendo arquivos do diretório temporário para o diretório permanente.')
        files = [y for x in os.walk(temp_path) for y in glob.glob(os.path.join(x[0], '*.zip'))]
        num_files = 0
        for file in files:
            shutil.move(file, file.replace('\\','/').replace(temp_path, path))
            num_files += 1
        print(f'Foram movidos {num_files} arquivos.')



    @staticmethod
    def load_carga (carga = 'C:/Users/albertos/CNPq/Lattes/Planilhas/R358737.csv', 
                    de_dados_pessoais = True,
                    de_carga = True,
                    max=-1, 
                    data_mínima_de_atualização='01/01/2018', 
                    path = 'C:/Downloads/',
                    log_file = 'C:/Users/albertos/CNPq/Lattes/log.txt',
                    linhas_a_pular = 0,
                    tempo_a_esperar_em_horário_de_pico = 0.5,
                    insere_no_bd = False,
                    temp_path = None,
                    num_imports_skip_before_log = 100,
                    show_import_messages = False
                    ):
        """Salva todos os currículos Lattes np HD do computador. Pode ser chamada sem inicialização.

        Exemplo de chamamento da função:
        from Lattes import Lattes
        Lattes.load_carga()

        Parâmetros:
        carga (str): caminho completo de onde se pode achar o arquivo com a carga a ser carregada.
            O arquivo pode ser baixado no seguinte endereço: http://memoria.cnpq.br/web/portal-lattes/extracoes-de-dados
        max (int): número máximo de arquivos a importar. Se negativo serão importados todos os arquivos.

        Returns:
        nothing

        """
        #Inicializando Variáveis
        if temp_path == None:
            temp_path = path[:-1] + '_temp' + '/'
        erros = {}
        data_mínima_de_atualização = datetime.strptime(data_mínima_de_atualização, '%d/%m/%Y')
        fim=''
        linhas_totais = 0
        lista_de_ids = []
        primeiras_linhas_puladas = False
        linhas_lidas = 0

        # Creating Subdirectorys, if they don't exixsts
        print(r'''
_______  _        ______   _______  _______ _________ _______ 
(  ___  )( \      (  ___ \ (  ____ \(  ____ )\__   __/(  ___  )
| (   ) || (      | (   ) )| (    \/| (    )|   ) (   | (   ) |
| (___) || |      | (__/ / | (__    | (____)|   | |   | |   | |
|  ___  || |      |  __ (  |  __)   |     __)   | |   | |   | |
| (   ) || |      | (  \ \ | (      | (\ (      | |   | |   | |
| )   ( || (____/\| )___) )| (____/\| ) \ \__   | |   | (___) |
|/     \|(_______/|/ \___/ (_______/|/   \__/   )_(   (_______)


 _______  _______  _______  _______  _______  _______ 
(  ____ \(  ___  )(       )(  ____ )(  ___  )(  ____ \
| (    \/| (   ) || () () || (    )|| (   ) || (    \/
| |      | (___) || || || || (____)|| |   | || (_____ 
| |      |  ___  || |(_)| ||  _____)| |   | |(_____  )
| |      | (   ) || |   | || (      | |   | |      ) |
| (____/\| )   ( || )   ( || )      | (___) |/\____) |
(_______/|/     \||/     \||/       (_______)\_______)



 _____     ___    ______    _____     ___  
/  __ \   / _ \   | ___ \  |  __ \   / _ \ 
| /  \/  / /_\ \  | |_/ /  | |  \/  / /_\ \
| |      |  _  |  |    /   | | __   |  _  |
| \__/\  | | | |  | |\ \   | |_\ \  | | | |
 \____/  \_| |_/  \_| \_|   \____/  \_| |_/

        ''')
        print('Criando diretórios temporários, se não existirem.')
        if not os.path.isdir(temp_path):
            os.makedirs(temp_path)
            #print("Created folder : ", temp_path)
        for x in range (10):
            file_path1 = os.path.join(temp_path, str(x))
            for y in range(10):
                file_path2 = os.path.join(file_path1, str(y))
                CHECK_FOLDER = os.path.isdir(file_path2)
                # If folder doesn't exist, then create it.
                if not CHECK_FOLDER:
                    os.makedirs(file_path2)
                   #print("Created folder : ", file_path2)
                else:
                    #print(file_path2, "folder already exists.")
                    pass

        ids_já_carregados = Lattes.lista_arquivos_no_HD (path)
        print('\nPegando lista de erros.')
        erros = Lattes.carrega_erros_anteriores(log_file)
        num_erros = len(erros)
        print(f"{len(erros)} erros encontrados que não serão importados.\n")
        ids_no_bd = Lattes.carrega_bd_lista_ids()
        print(f'\n{len(ids_no_bd)} ids no Banco de Dados que não serão importados.')

        if de_dados_pessoais == True:
            print ('Carregando lista de IDs a importar pela carga de dados pessoais do Relatórios do CNPq')
            Lattes.carrega_dados_pessoais()
            print('Gerando lista de ids a importar. Eliminando ids já importados.')
            for id in Lattes.dados_pessoais.Lattes.tolist():
                if (
                    id in erros or
                    id in ids_já_carregados[id[0]][id[1]][id[2]][id[3]][id[4]] or
                    id in ids_no_bd[id[0]][id[1]][id[2]][id[3]][id[4]]
                    ):
                    continue
                lista_de_ids.append(id)
            del Lattes.dados_pessoais

        if de_carga == True:
            print ('\n\nCarregando lista de IDs a importar pela carga de ids no SOAP')
            with open(carga) as csvfile:
                spamreader = csv.reader(csvfile, delimiter=',', quotechar='"')
                print('Pulando primeiras linhas.')
                while linhas_lidas <= linhas_a_pular:
                    linhas_lidas += 1
                    next(spamreader)
                print('Carregando ids a ler.')
                for row in spamreader:
                    linhas_lidas += 1
                    try:
                        id = row[0]
                        if len(id) == 16:
                            data_atualizado = datetime.strptime(row[2], '%d/%m/%Y')
                            if not data_mínima_de_atualização == None and data_atualizado >= data_mínima_de_atualização and not (
                                    id in erros or
                                    id in ids_já_carregados[id[0]][id[1]][id[2]][id[3]][id[4]] or
                                    id in ids_no_bd[id[0]][id[1]][id[2]][id[3]][id[4]]
                                    ):
                                lista_de_ids.append(id)
                        else:
                            print (f'Erro na linha {linhas_lidas}: {row}')
                    except Exception as e:
                        print ('\n\n\n\n', str(e))
                        print (row)
                        print(row[0])
                        print (row[2])
                        print (ids_já_carregados[id[0]][id[1]][id[2]][id[3]][id[4]])
                        print(ids_no_bd[id[0]][id[1]][id[2]][id[3]][id[4]])
                        return False

        print('Limpando memória.')
        del ids_já_carregados
        del ids_no_bd

        print('Começando importação.')
        start_time = datetime.now()
        tempo_inicio = datetime.now()
        linhas_lidas = 0
        linhas_totais = len(lista_de_ids)
        print(f'\n\n Há {linhas_totais} arquivos a importar.\n\n')
        for id in lista_de_ids:
            linhas_lidas += 1
            print(f'Importando {id}. -> Salvando arquivo compactado no disco.                              \r', end="", flush=True)
            if linhas_lidas % num_imports_skip_before_log == 0:
                Lattes.move_files_temp_to_path(path)
            os.system('cls')
            print(Lattes.show_progress(tempo_inicio, num_imports_skip_before_log, linhas_totais, linhas_lidas, num_erros))
            if not show_import_messages:
                old_stdout = sys.stdout # backup current stdout -> https://stackoverflow.com/questions/8447185/to-prevent-a-function-from-printing-in-the-batch-console-in-python
                sys.stdout = open(os.devnull, "w")
            lattes = Lattes(id = id, path = temp_path)
            resposta = lattes.get_zip_from_SOAP()
            # print(resposta, insere_no_bd, resposta == True and insere_no_bd == True)
            if resposta == "Curriculo recuperado com sucesso!" and insere_no_bd == True:
                print(f'Importando {id}. -> Inserindo no Banco de Dados.                              \r', end="", flush=True)
                lattes.get_xml()
                lattes.insert_json()
            elif not resposta == "Curriculo recuperado com sucesso!":
                erro =  {
                    'data': datetime.now().strftime("%d/%m/%Y, %H:%M:%S"),
                    'id': id,
                    'erro': resposta
                }
                erros.append(erro)
                with open(log_file, 'w') as log:
                    json.dump(erros, log, indent=4)
            if not show_import_messages:
                sys.stdout = old_stdout # reset old stdout
            horas_agora = int(datetime.now().time().strftime("%H"))
            if (tempo_a_esperar_em_horário_de_pico > 0 and
                datetime.today().weekday() < 5 and
                horas_agora >= 8 and
                horas_agora <= 18
                ):
                print(f'Importando {id}. -> Esperando para não sobrecarregar o BD do CNPq.    \r', end="", flush=True)
                time.sleep(tempo_a_esperar_em_horário_de_pico)

            if max > 0 and linhas_lidas > max:
                print ('Erros:' ,erros)
                break
        print ('Erros:' ,erros)

            
    @staticmethod
    def grava_arquivo_json (
                    max=-1,
                    path = 'C:/Downloads/',
                    log_file = 'C:/Users/albertos/CNPq/Lattes/log_save_json.txt',
                    show_import_messages = False,
                    num_imports_skip_before_log = 100):
        """Salva todos os currículos Lattes np HD do computador. Pode ser chamada sem inicialização.

        Exemplo de chamamento da função:
        from Lattes import Lattes
        Lattes.load_carga()

        Parâmetros:
        carga (str): caminho completo de onde se pode achar o arquivo com a carga a ser carregada.
            O arquivo pode ser baixado no seguinte endereço: http://memoria.cnpq.br/web/portal-lattes/extracoes-de-dados
        max (int): número máximo de arquivos a importar. Se negativo serão importados todos os arquivos.

        Returns:
        nothing

        """

        print(r'''
 _______  _        ______   _______  _______ _________ _______ 
(  ___  )( \      (  ___ \ (  ____ \(  ____ )\__   __/(  ___  )
| (   ) || (      | (   ) )| (    \/| (    )|   ) (   | (   ) |
| (___) || |      | (__/ / | (__    | (____)|   | |   | |   | |
|  ___  || |      |  __ (  |  __)   |     __)   | |   | |   | |
| (   ) || |      | (  \ \ | (      | (\ (      | |   | |   | |
| )   ( || (____/\| )___) )| (____/\| ) \ \__   | |   | (___) |
|/     \|(_______/|/ \___/ (_______/|/   \__/   )_(   (_______)


 _______  _______  _______  _______  _______  _______ 
(  ____ \(  ___  )(       )(  ____ )(  ___  )(  ____ \
| (    \/| (   ) || () () || (    )|| (   ) || (    \/
| |      | (___) || || || || (____)|| |   | || (_____ 
| |      |  ___  || |(_)| ||  _____)| |   | |(_____  )
| |      | (   ) || |   | || (      | |   | |      ) |
| (____/\| )   ( || )   ( || )      | (___) |/\____) |
(_______/|/     \||/     \||/       (_______)\_______)



   ___  _____  _____  _   _                                  ______ ______ 
  |_  |/  ___||  _  || \ | |                                 | ___ \|  _  \
    | |\ `--. | | | ||  \| |    _ __    __ _  _ __   __ _    | |_/ /| | | |
    | | `--. \| | | || . ` |   | '_ \  / _` || '__| / _` |   | ___ \| | | |
/\__/ //\__/ /\ \_/ /| |\  |   | |_) || (_| || |   | (_| |   | |_/ /| |/ / 
\____/ \____/  \___/ \_| \_/   | .__/  \__,_||_|    \__,_|   \____/ |___/  

        ''')
        erros = []
        fim=''
        linhas_lidas = 0

        print('\n\nPegando lista de arquivos zip a importar.')
        ids_em_zip = [y[y.find('Lattes_')+7:-4] for x in os.walk(path) for y in glob.glob(os.path.join(x[0], '*.zip'))]
        ids_no_bd = Lattes.carrega_bd_lista_ids()

        print('\nGerando lista de arquivos a transformar em JSON')

        arquivos = [id for id in ids_em_zip if id not in ids_no_bd[id[0]][id[1]][id[2]][id[3]][id[4]]]
        linhas_totais = len(arquivos)
        print("Linhas a ler: ", linhas_totais)

        print("Apagando itens desnecessários da memória")
        del ids_no_bd
        del ids_em_zip

        num_erros = len(erros)

        print('Começando importação.')
        tempo_inicio = datetime.now()
        for id in arquivos:
            linhas_lidas += 1
            os.system('cls')
            print(Lattes.show_progress(tempo_inicio, num_imports_skip_before_log, linhas_totais, linhas_lidas, num_erros))

            print(f"Importing id {id}.\r", end="", flush=True)
            try:
                if not show_import_messages:
                    old_stdout = sys.stdout # backup current stdout -> https://stackoverflow.com/questions/8447185/to-prevent-a-function-from-printing-in-the-batch-console-in-python
                    sys.stdout = open(os.devnull, "w")
                lattes = Lattes(id = id)
                lattes.path = path
                lattes.read_xml_from_zip()
                print(id + ': ' + lattes.insert_json() + '\r')
                if not show_import_messages:
                    sys.stdout = old_stdout # reset old stdout
            except EXCEPTION as e:
                erro =  {
                    'data': datetime.now().strftime("%d/%m/%Y, %H:%M:%S"),
                    'id': id,
                    'erro': str(e)
                }
                erros.append(erro)
                with open(log_file, 'w') as log:
                    json.dump(erros, log, indent=4)

            if max > 0 and linhas_lidas > max:
                break


# _________ _______  _______  _______  _______ _________
# \__   __/(       )(  ____ )(  ___  )(  ____ )\__   __/
#    ) (   | () () || (    )|| (   ) || (    )|   ) (   
#    | |   | || || || (____)|| |   | || (____)|   | |   
#    | |   | |(_)| ||  _____)| |   | ||     __)   | |   
#    | |   | |   | || (      | |   | || (\ (      | |   
# ___) (___| )   ( || )      | (___) || ) \ \__   | |   
# \_______/|/     \||/       (_______)|/   \__/   )_(   




# _________ _        ______  _________ _______  _______  ______   _______ 
# \__   __/( (    /|(  __  \ \__   __/(  ____ \(  ___  )(  __  \ (  ___  )
#    ) (   |  \  ( || (  \  )   ) (   | (    \/| (   ) || (  \  )| (   ) |
#    | |   |   \ | || |   ) |   | |   | |      | (___) || |   ) || |   | |
#    | |   | (\ \) || |   | |   | |   | |      |  ___  || |   | || |   | |
#    | |   | | \   || |   ) |   | |   | |      | (   ) || |   ) || |   | |
# ___) (___| )  \  || (__/  )___) (___| (____/\| )   ( || (__/  )| (___) |
# \_______/|/    )_)(______/ \_______/(_______/|/     \|(______/ (_______)
                                                                        
#  _______  _______  _______ 
# (  ____ )(  ____ \(  ____ \
# | (    )|| (    \/| (    \/
# | (____)|| (__    | (_____ 
# |     __)|  __)   (_____  )
# | (\ (   | (            ) |
# | ) \ \__| (____/\/\____) |
# |/   \__/(_______/\_______)



    @staticmethod
    def atualiza_todos_os_indicadores (path = 'D:/Lattes\Lattes_ZIP', 
            log_file = 'd:/indicadores.log', 
            max = -1,
            show_import_messages = False,
            num_imports_skip_before_log = 10
            ):
        ids_já_carregados = Lattes.lista_arquivos_no_HD (path)
        print('\nPegando lista de erros.')
        erros = Lattes.carrega_erros_anteriores(log_file)
        num_erros = len(erros)
        print(f"{len(erros)} erros encontrados que não serão importados.\n")
        print('\nCarregando lista de indicadores já no BD')
        ids_no_bd = Lattes.carrega_lista_ids_indicadores_bd()
        número = 0
        print('Gerando lista de ids a atualizar indicadores')
        ids_para_atualizar = []
        for x0 in ids_já_carregados:
            for x1 in ids_já_carregados[x0]:
                for x2 in ids_já_carregados[x0][x1]:
                    for x3 in ids_já_carregados[x0][x1][x2]:
                        for x4 in ids_já_carregados[x0][x1][x2][x3]:
                            for x in ids_já_carregados[x0][x1][x2][x3][x4]:
                                if (    x not in erros and
                                        x not in ids_no_bd[x[0]][x[1]][x[2]][x[3]][x[4]]):
                                    ids_para_atualizar.append(x)
        linhas_totais = len(ids_para_atualizar)
        tempo_inicio = datetime.now()
        linhas_lidas = 0
        for id in ids_para_atualizar:
            linhas_lidas += 1
            print(f'{round(100*linhas_lidas/linhas_totais,1)}%  -  {linhas_lidas} de {linhas_totais}: Recuperando dados do Currículo: {id}\r', end="", flush=True)
            lattes = Lattes()
            lattes.id = id
            print(Lattes.show_progress(tempo_inicio, num_imports_skip_before_log, linhas_totais, linhas_lidas, num_erros))
            if not show_import_messages:
                old_stdout = sys.stdout # backup current stdout -> https://stackoverflow.com/questions/8447185/to-prevent-a-function-from-printing-in-the-batch-console-in-python
                sys.stdout = open(os.devnull, "w")
            Lattes.update_bd_from_zip(id = id, path = path)
            if not show_import_messages:
                sys.stdout = old_stdout # reset old stdout
            else:
                print('Erro ao carregar arquivo:', lattes.id)
            if max > 0 and linhas_lidas >= max:
                break

# d8888b. d888888b d8888b. db      d888888b  .d88b.  .88b  d88. d88888b d888888b d8888b. d888888b  .o88b. 
# 88  `8D   `88'   88  `8D 88        `88'   .8P  Y8. 88'YbdP`88 88'     `~~88~~' 88  `8D   `88'   d8P  Y8 
# 88oooY'    88    88oooY' 88         88    88    88 88  88  88 88ooooo    88    88oobY'    88    8P      
# 88~~~b.    88    88~~~b. 88         88    88    88 88  88  88 88~~~~~    88    88`8b      88    8b      
# 88   8D   .88.   88   8D 88booo.   .88.   `8b  d8' 88  88  88 88.        88    88 `88.   .88.   Y8b  d8 
# Y8888P' Y888888P Y8888P' Y88888P Y888888P  `Y88P'  YP  YP  YP Y88888P    YP    88   YD Y888888P  `Y88P' 
                                                                                                        
                                                                                                        
# d88888b db    db d8b   db  .o88b. d888888b d888888b  .d88b.  d8b   db .d8888.                           
# 88'     88    88 888o  88 d8P  Y8 `~~88~~'   `88'   .8P  Y8. 888o  88 88'  YP                           
# 88ooo   88    88 88V8o 88 8P         88       88    88    88 88V8o 88 `8bo.                             
# 88~~~   88    88 88 V8o88 8b         88       88    88    88 88 V8o88   `Y8b.                           
# 88      88b  d88 88  V888 Y8b  d8    88      .88.   `8b  d8' 88  V888 db   8D                           
# YP      ~Y8888P' VP   V8P  `Y88P'    YP    Y888888P  `Y88P'  VP   V8P `8888Y'          

    def get_id_by_xml (self):
        if not (
                type(self.xml) == BeautifulSoup or
                type(self.xml) == Tag ):
            self.xml = BeautifulSoup(self.xml, "xml")
        if self.id == None:
            self.id = self.soup.find('CURRICULO-VITAE')['NUMERO-IDENTIFICADOR']
        data = self.soup.find('CURRICULO-VITAE').get('DATA-ATUALIZACAO')
        hora = self.soup.find('CURRICULO-VITAE').get('HORA-ATUALIZACAO')
        self.data_atualizacao = datetime.strptime(data + hora, '%d%m%Y%H%M%S')
        self.nome_completo = self.soup.find('DADOS-GERAIS').get('NOME-COMPLETO')
        self.nacionalidade = self.soup.find('DADOS-GERAIS').get('PAIS-DE-NACIONALIDADE')
        self.nomes_citação = self.soup.find('DADOS-GERAIS').get('NOME-EM-CITACOES-BIBLIOGRAFICAS')
        #self.CPF = self.soup.find('DADOS-GERAIS').get('CPF')
        #self.data_nascimento = datetime.strptime(self.soup.find('DADOS-GERAIS').get('DATA-NASCIMENTO'], '%d%m%Y')
        #self.sexo = self.soup.find('DADOS-GERAIS').get('SEXO')
        #self.raca = self.soup.find('DADOS-GERAIS').get('RACA-OU-COR')
        



    def indicadores_append (self, descricao, qty, ano):
        if ano == None or ano == '': 
            ano = 0
        existe = False
        for item in self.indicadores:
            if (item['id'] == self.id and
                item['tipo'] == self.get_lista_indicadores(descricao) and
                item['ano'] == int(ano)
                ):
                item['qty'] += 1
                existe = True
        if not existe:
            mydict = {
                'id': self.id,
                'tipo': self.get_lista_indicadores(descricao),
                'ano': int(ano),
                'qty': qty,
            }
            self.indicadores.append(mydict)


    def recorre_sobre_todo_json(self, d, path=None):
            if not path: path = []
            for k, v in d.items():
                if isinstance(v, dict) or isinstance(v, OrderedDict):
                    #print("Getting: ", k)
                    self.recorre_sobre_todo_json(v, path + [k])
                elif isinstance(v, list):
                    num = 0
                    for item in v:
                        #print("Unfolding List: ", v)
                        self.recorre_sobre_todo_json(item, path + [k] + [num])
                        num +=1
                else:
                    if not v == None:
                        d[k] = html.unescape(v)
                        #print("{2} - {0} : {1}".format(k, html.unescape(v), path))
                    else:
                        #print("{2} - {0} : {1}".format(k, v, path))
                        pass
            return d


    def get_xml(self):
        if self.zip == None:
            return False
        try:
            with ZipFile(io.BytesIO(self.zip)) as myzip:
                with myzip.open(myzip.namelist()[0]) as myfile:
                    print('Unzipping file and gettinf xml and json')
                    self.xml = myfile.read()

                #transforma o Lattes compactado em um dicionário JSON
                self.json = xmltodict.parse(self.xml)
                #print('retira, de cada JSON, caracteres especiais web')
                #print (self.json)
                self.json = self.recorre_sobre_todo_json(self.json)
                #print (self.recorre_sobre_todo_json(self.json))
                #Decoding XML - must be done after JSON transform.
                self.xml = self.xml.decode('iso-8859-1').replace('encoding="ISO-8859-1" ', '')
                self.data_atualizacao = self.get_atualizacao_JSON()
                self.soup = BeautifulSoup(self.xml, "xml")
            print("XML & JSON atualizado a partir do Lattes compactado.")
            return True
        except:
            return False         

    @staticmethod
    def get_lista_indicadores (indicador):
        if not indicador in Lattes.lista_indicadores:
            sql = 'SELECT id, descricao from public."lista_indicadores"'
            conn = None
            try:
                params = Lattes.config_db_connection()
                conn = psycopg2.connect(**params)
                cur = conn.cursor()
                cur.execute(sql)
                result = cur.fetchall()
                cur.close()
                for k in result:
                    Lattes.lista_indicadores[k[1]] = k[0]
            except (Exception, psycopg2.DatabaseError) as error:
                print("Não foi possível pegar os indicadores. Erro: ", error)
                return False
            finally:
                if conn is not None:
                    conn.close()
        if not indicador in Lattes.lista_indicadores:
            try:
                sql = 'insert into public."lista_indicadores" (descricao) VALUES (%s);'
                params = Lattes.config_db_connection()
                conn = psycopg2.connect(**params)
                cur = conn.cursor()
                cur.execute(sql, [indicador])
                conn.commit()
                sql = 'SELECT id, descricao from public."lista_indicadores"'
                cur.execute(sql)
                result = cur.fetchall()
                cur.close()
                for k in result:
                    Lattes.lista_indicadores[k[1]] = k[0]
            except (Exception, psycopg2.DatabaseError) as error:
                print("Não foi possível pegar os indicadores. Erro: ", error)
                return False
            finally:
                if conn is not None:
                    conn.close()
        return Lattes.lista_indicadores[indicador]

    def get_palavras_chave(self, json = None, path = None, palavras_chave = None):
            if palavras_chave == None:
                palavras_chave = self.palavras_chave
            if json == None: json = self.json
            if not path: path = []
            for k, v in json.items():
                if isinstance(v, dict) or isinstance(v, OrderedDict):
                    self.get_palavras_chave(json = v, path = path + [k], palavras_chave = palavras_chave)
                elif isinstance(v, list):
                    num = 0
                    for item in v:
                        #print("Unfolding List: ", v)
                        self.get_palavras_chave(json = item, path = path + [k] + [num], palavras_chave = palavras_chave)
                        num +=1
                else:
                    if not v == None:
                        #print(k[0:14], path, v)
                        if k[0:15] == '@PALAVRA-CHAVE-':
                            if (len(v) > 2): 
                                if not v in palavras_chave:
                                    palavras_chave.append(v)
                        #print("{2} - {0} : {1}".format(k, html.unescape(v), path))
                    else:
                        #print("{2} - {0} : {1}".format(k, v, path))
                        pass
            self.palavras_chave = palavras_chave
            return palavras_chave

        

    def get_areas_conhecimento(self):
        dados = []
        try:
            for area in self.json["CURRICULO-VITAE"]["DADOS-GERAIS"]['AREAS-DE-ATUACAO']:
                for area2 in self.json["CURRICULO-VITAE"]["DADOS-GERAIS"]['AREAS-DE-ATUACAO'][area]:
                    if len(area2['@NOME-GRANDE-AREA-DO-CONHECIMENTO']) > 1:
                        dados.append((
                            self.id, 
                            "grande-area", 
                            area2['@NOME-GRANDE-AREA-DO-CONHECIMENTO'])
                            )
                        self.areas['grande_area'].append(area2['@NOME-GRANDE-AREA-DO-CONHECIMENTO'])
                    if len(area2['@NOME-DA-AREA-DO-CONHECIMENTO']) > 1:
                        dados.append((
                            self.id, 
                            "area", 
                            area2['@NOME-DA-AREA-DO-CONHECIMENTO']))
                        self.areas['area'].append(area2['@NOME-DA-AREA-DO-CONHECIMENTO'])
                    if len(area2['@NOME-DA-SUB-AREA-DO-CONHECIMENTO']) > 1:
                        dados.append((
                            self.id, 
                            "sub-area", 
                            area2['@NOME-DA-SUB-AREA-DO-CONHECIMENTO']))
                        self.areas['sub-area'].append(area2['@NOME-DA-SUB-AREA-DO-CONHECIMENTO'])
                    if len(area2['@NOME-DA-ESPECIALIDADE']) > 1:
                        dados.append((
                            self.id, 
                            "especialidade",                 
                            area2['@NOME-DA-ESPECIALIDADE']))
                        self.areas['especialidade'].append(area2['@NOME-DA-ESPECIALIDADE'])
            params = Lattes.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            args_str = ','.join((cur.mogrify("(%s,%s,%s)", x).decode("utf-8")) for x in dados)
            sql = '''
            delete from public."areas_conhecimento" where id = %s;
            insert into public."areas_conhecimento" VALUES ''' + (args_str) + '''
            on conflict DO NOTHING'''
            cur.execute(sql, [self.id])
            conn.commit()
            cur.close()
            print('Areas do Conhecimento inseridas no BD.')
        except:
            pass

    def get_indicadores (self, id = None):
        if not id == None:
            self.id = id
        if self.xml == None:
            self.get_xml()
        self.get_all_indicadores()

    
    def update_indicadores_bd (self, update_publicações = True):
        sql = 'delete from public."indicadores" where id = %s '
        data = (self.id,)
        # print("Data tuple: ", data)
        conn = None
        try:
            params = Lattes.config_db_connection()
            conn = psycopg2.connect(**params)
            cur = conn.cursor()
            cur.execute(sql, data)
            conn.commit()
            cur.close()
        except (Exception, psycopg2.DatabaseError) as error:
            print("Erro ao apagar os Indicaodres no BD: ", error)
        finally:
            if conn is not None:
                conn.close()
        pd = pandas.DataFrame(self.indicadores)
        engine = Lattes.db_engine()
        pd.to_sql('indicadores', engine, if_exists='append', index = False)

        if update_publicações == True:
            sql = 'delete from public."publicacoes" where id = %s '
            data = (self.id,)
            # print("Data tuple: ", data)
            conn = None
            try:
                params = Lattes.config_db_connection()
                conn = psycopg2.connect(**params)
                cur = conn.cursor()
                cur.execute(sql, data)
                conn.commit()
                cur.close()
            except (Exception, psycopg2.DatabaseError) as error:
                print("Erro ao apagar os Indicaodres no BD: ", error)
            finally:
                if conn is not None:
                    conn.close()
            self.publicações = self.get_publicacoes()
            pd = pandas.DataFrame(self.publicações)
            engine = Lattes.db_engine()
            pd.to_sql('publicacoes', engine, if_exists='append', index = False)



    def get_all_indicadores(self, xml = None, nivel = 0):
        dado={}   
        if xml == None:
            xml = self.xml
            if xml == None:
                return None
        if not (
                type(xml) == BeautifulSoup or
                type(xml) == Tag ):
            xml = BeautifulSoup(xml, "xml")
 
        if not xml.find('CURRICULO-VITAE') == None:
            xml = xml.find('CURRICULO-VITAE')

        nome_indicador = xml.name


        # Verifica se os filhos não são detalhamentos do pai
        detalhamento = False
        for child in xml.children:
            child_name = child.name
            if (not child_name == None and 
                    (child_name[0:14] == 'DADOS-BASICOS' or
                    child_name[0:13] == 'DETALHAMENTO-' or
                    child_name == 'AUTORES' or
                    child_name == "PALAVRAS-CHAVE" or
                    child_name == "AREAS-DO-CONHECIMENTO" or
                    child_name == "SETORES-DE-ATIVIDADE" or
                    child_name == "INFORMACOES-ADICIONAIS" or
                    child_name == 'INFORMACOES-ADICIONAIS' or
                    child_name == 'INFORMACOES-ADICIONAIS-INSTITUICOES' or
                    child_name == 'INFORMACOES-ADICIONAIS-CURSOS' 
                    )):
                detalhamento = True
                continue

        #Se houver detalhamento, pega.
        if detalhamento:
            
            #1. Pegar autores, se existirem
            autores = []
            num_autores = 0
            posicao_autor = 0
            for autor in xml.find_all('AUTORES'):
                num_autores += 1
                if autor.get("NRO-ID-CNPQ") == self.id:
                    posicao_autor = num_autores
                for (key, value) in xml.attrs.items():
                    try:
                        dado[key.lower()].append(value)
                    except:
                        dado[key.lower()] = [value]
                        # if key.lower() in dado:
                        #     dado[key.lower()] = [dado[key.lower()]]
                        #     dado[key.lower()].append(value)
                        # else:
                        #     dado[key.lower()] = value
                autores.append(list(autor.attrs.items()))
            if len(autores) > 0:
                dado['numero-autores'] = [num_autores]
                dado['posicao-autor'] = [posicao_autor]
                dado['autores'] = autores
            
            #2 Pegar palavras-chave, se existirem.
            palavras_chaves = []
            for palavra in xml.find_all('PALAVRAS-CHAVE'):
                palavras_chaves.append(list(palavra.attrs.values()))
            if len(palavras_chaves) > 0:
                dado['palavras-chave'] = palavras_chaves
                
            #3 Pegar áreas de atuação, se existirem
            areas = []
            for area in xml.find_all('AREAS-DO-CONHECIMENTO'):
                for a in area.children:
                    area_ga = a.find('NOME-GRANDE-AREA-DO-CONHECIMENTO')
                    area_a = a.find('NOME-DA-AREA-DO-CONHECIMENTO')
                    area_sa = a.find('NOME-DA-SUB-AREA-DO-CONHECIMENTO')
                    area_e = a.find('NOME-DA-ESPECIALIDADE')
                    areas.append ((area_ga, area_a, area_sa, area_e))
            if len(areas) > 0:
                dado['areas-do-conhecimento'] = areas
                        
            #4 Setores de Atividade
            setores = []
            for setor in xml.find_all('SETORES-DE-ATIVIDADE'):
                setores.append(list(setor.attrs.values()))
            if len(setores) > 0:
                    dado['setores-de-atividade'] = setores
                    
            #5 Informações adicionais
            informacoes = []
            for palavra in xml.find_all('INFORMACOES-ADICIONAIS'):
                informacoes.append(list(palavra.attrs.values()))
            if len(informacoes) > 0:
                    dado['informacoes-adicionais'] = informacoes
                    
            #6 Pegar outras informações
            for child in xml.children:
                child_name = child.name
                if child_name in [
                        'AUTORES',
                        'PALAVRAS-CHAVE',
                        'AREAS-DO-CONHECIMENTO',
                        'SETORES-DE-ATIVIDADE',
                        'INFORMACOES-ADICIONAIS',
                        'INFORMACOES-ADICIONAIS-INSTITUICOES',
                        'INFORMACOES-ADICIONAIS-CURSOS',
                        'SISTEMA-ORIGEM-XML',
                        '[document] - '
                        ]:
                    continue
                try:
                    for (key, value) in child.attrs.items():
                        try:
                            dado[key.lower()].append(value)
                        except:
                            dado[key.lower()] = [value]
                            # if key.lower() in dado:
                            #     dado[key.lower()] = [dado[key.lower()]]
                            #     dado[key.lower()].append(value)
                            # else:
                            #     if key in ('AUTORES',
                            #         'PALAVRAS-CHAVE',
                            #         'AREAS-DO-CONHECIMENTO',
                            #         'SETORES-DE-ATIVIDADE',):
                            #         dado[key.lower()] = [value]
                            #     else:
                            #         dado[key.lower()] = value
                    try:
                        for child2 in child.children:
                            child_name = child2.name
                            if child_name in [
                                    'AUTORES',
                                    'PALAVRAS-CHAVE',
                                    'AREAS-DO-CONHECIMENTO',
                                    'SETORES-DE-ATIVIDADE',
                                    'INFORMACOES-ADICIONAIS',
                                    ]:
                                continue
                            for (key, value) in child2.attrs.items():
                                try:
                                    dado[key.lower()].append(value)
                                except:
                                    dado[key.lower()] = [value]
                    except:
                        pass
                except:
                    pass

        #Pega outros atributos do XML
        for (key, value) in xml.attrs.items():
                dado[key.lower()] = [value]

        #Pega o ano, se houver           
        try:
            if not dado.get('ano') == None:
                ano = dado.get('ano')[0]
            elif not dado.get('ano-de-conclusao') == None:
                ano = dado.get('ano-de-conclusao')[0]
            elif not dado.get('ano-da-obra-de-referencia') == None:
                ano = dado.get('ano-da-obra-de-referencia')[0]
            elif not dado.get('ano-de-obtencao-do-titulo') ==None:
                ano = dado.get('ano-de-obtencao-do-titulo')[0]
            elif not dado.get('ano-fim') == None:
                ano = dado.get('ano-fim')[0]
            elif not dado.get('ano-de-realizacao') == None:
                ano = dado.get('ano-de-realizacao')[0]
            elif not dado.get('ano-do-artigo') == None:
                ano = dado.get('ano-do-artigo')[0]
            elif not dado.get('ano-do-texto') == None:
                ano = dado.get('ano-do-texto')[0]
            elif not dado.get('ano-desenvolvimento') == None:
                ano = dado.get('ano-desenvolvimento')[0]
            elif not dado.get('ano-solicitacao') == None:
                ano = dado.get('ano-solicitacao')[0]
            elif not dado.get('ano-da-obra') == None:
                ano = dado.get('ano-da-obra') [0]
            else:
                ano = None
            if not ano==None and int(ano) > 0:
                dado['ano'] = [int(ano)]
                self.indicadores_append(nome_indicador, 1, ano)
                if not dado.get('numero-autores') == None:
                    #print((1/int(dado.get('numero-autores'))))
                    self.indicadores_append(nome_indicador + ' - INVERSO-DE-AUTORES', (1/int(dado.get('numero-autores'))), ano)
                if not dado.get('posicao-autor') == None:
                    #print(dado.get('posicao-autor'))
                    self.indicadores_append(nome_indicador + ' - POSIÇÃO-AUTOR', dado.get('posicao-autor'), ano)                    
        except:
            pass

        #coloca o tipo de indicador nos dados
        parent = xml.parent
        pais = xml.name
        while not parent == None:
            if not pais == '':
                pais = parent.name + ', ' + pais 
            else:
                pais = parent.name
            parent = parent.parent
        
        dado['tipo-indicador'] = [pais]

        #atualiza a variável Indicador.lattes, exceto se só houver o 'tipo-indicador' nos dados
        if len(dado) > 1:
            try:
                self.lattes[nome_indicador].append(dado)
            except:
                self.lattes[nome_indicador] = [dado]
                # if nome_indicador in self.lattes:
                #     self.lattes[nome_indicador] = [self.lattes[nome_indicador]]
                #     self.lattes[nome_indicador].append(dado)
                # else:
                #     self.lattes[nome_indicador] = dado
                
        #Continua, exceto para detalhamentos, que já devem ter sido pegos        
        if not detalhamento:

            for child in xml.children:
                self.get_all_indicadores(child, nivel + 1)
                    
    def get_publicacoes (self):

        def return_first_element_of(x):
            if x == None : return None
            elif isinstance(x, list): return x[0]
            elif isinstance(x, OrderedDict): return x[x.keys()[0]]
            else: return x

        publicações = []

        for k in self.lattes.keys():
            for k2 in self.lattes[k]:
                sequencia = k2.get('sequencia-producao')
                mesmo = False
                for indicador in k2:
                    if (indicador[:6]=='titulo' and
                            indicador.find('ingl') == -1 and 
                            not k2.get(indicador)==[''] and
                            not mesmo):
                        publicação = {}
                        if sequencia == k2.get('sequencia-producao'): mesmo = True
                        publicação['id'] = self.id
                        publicação['tipo'] = self.get_lista_indicadores(return_first_element_of(indicador))
                        publicação['titulo'] = (return_first_element_of(k2.get(indicador)))
                        publicação['ano'] = (return_first_element_of(k2.get('ano')))
                        publicação['tipo_indicador'] = self.get_lista_indicadores(return_first_element_of(k2.get('tipo-indicador')))
                        publicação['doi'] = (return_first_element_of(k2.get('doi')))
                        publicação['issn'] = (return_first_element_of(k2.get('issn')))
                        publicação['isbn'] = (return_first_element_of(k2.get('isbn')))
                        for indicador2 in k2:
                            if (indicador2[:6]=='titulo' and
                                    indicador2.find('ingl') == -1 and 
                                    not k2.get(indicador2)==[''] and
                                    not indicador2 == indicador
                                    ):
                                publicação['tipo_segundo_titulo'] = self.get_lista_indicadores(indicador2)
                                publicação['segundo_titulo'] = return_first_element_of(k2.get(indicador2))
                        publicações.append(publicação)
        return publicações

