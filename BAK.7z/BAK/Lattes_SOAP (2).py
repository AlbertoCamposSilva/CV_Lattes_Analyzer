# .d8888.       .d88b.        .d8b.       d8888b.                               
# 88'  YP      .8P  Y8.      d8' `8b      88  `8D                               
# `8bo.        88    88      88ooo88      88oodD'                               
#   `Y8b.      88    88      88~~~88      88~~~                                 
# db   8D      `8b  d8'      88   88      88                                    
# `8888Y'       `Y88P'       YP   YP      88                                    
                                                                              
                                                                              
# d88888b db    db d8b   db  .o88b. d888888b d888888b  .d88b.  d8b   db .d8888. 
# 88'     88    88 888o  88 d8P  Y8 `~~88~~'   `88'   .8P  Y8. 888o  88 88'  YP 
# 88ooo   88    88 88V8o 88 8P         88       88    88    88 88V8o 88 `8bo.   
# 88~~~   88    88 88 V8o88 8b         88       88    88    88 88 V8o88   `Y8b. 
# 88      88b  d88 88  V888 Y8b  d8    88      .88.   `8b  d8' 88  V888 db   8D 
# YP      ~Y8888P' VP   V8P  `Y88P'    YP    Y888888P  `Y88P'  VP   V8P `8888Y'      

import zeep
import os, io, time, pathlib, json, xmltodict, html
from datetime import datetime
import pytz
import socket
from Lattes import Lattes
from zipfile import ZipFile
from bs4 import BeautifulSoup, Tag
from collections import OrderedDict

class Lattes_SOAP():

    def __init__(self,
                 id = '7281587998425548',
                 wsdl = 'http://servicosweb.cnpq.br/srvcurriculo/WSCurriculo?wsdl',
                 path = 'D:/Lattes/',
                 ) :
        settings = zeep.Settings(strict=True, xml_huge_tree=True)
        self.id = id
        self.ocorrencia = None
        self.zip = None
        self.data_atualizacao = None
        self.wsdl = wsdl
        self.path = path
        if socket.gethostbyname(socket.gethostname()) == '10.30.12.10':
            self.can_get_soap = True
        else:
            self.can_get_soap = False
        self.nome = None
        self.CPF = None
        self.data_nascimento = None
        print('done')
   
    def get_zip_from_SOAP(self, id=None, set_auto_save=True, num_errors = 0, path = None):
        if path == None:
            path = self.path
        self.ocorrencia = None
        self.zip = None
        if not id == None:
            self.id = id
        if self.can_get_soap:
            print (f'Tentando recuperar Lattes compactado {self.id} via SOAP')
            try:
                client = zeep.Client(wsdl=self.wsdl)
                self.zip = client.service.getCurriculoCompactado(self.id)
                self.ocorrencia = client.service.getOcorrenciaCV(self.id)
            except Exception as e:
                if self.ocorrencia == None:
                    self.ocorrencia = str(e)
            if not self.ocorrencia == "Curriculo recuperado com sucesso!" and num_errors < 3:
                num_errors += 1
                print (f'Erro {num_errors}: "{self.ocorrencia}".')
                if self.ocorrencia == 'Nenhum curriculo encontrado!' or self.ocorrencia == 'Mais de um curriculo atende ao criterio informado!' or self.ocorrencia == 'Nenhum curriculo encontrado!':
                    return self.ocorrencia
                tempo_a_dormir = (num_errors*4)**2
                print(f'Esperando {tempo_a_dormir} segundos.')
                time.sleep(tempo_a_dormir)
                print(f'Tentando novamente.')
                self.get_zip_from_SOAP(id = self.id, set_auto_save = set_auto_save, num_errors = num_errors)
            if self.ocorrencia == "Curriculo recuperado com sucesso!" and not self.zip == None:
                print('Lattes compactado recuperado via SOAP')
                if set_auto_save:
                    self.save_zip_to_disk(path)
                return self.ocorrencia
            elif num_errors >= 3:
                return self.ocorrencia
            else:
                return (self.ocorrencia + ' - Erro ao recuperar zip.')
        else:
            return "Wrong IP number. Can't get zipped Lattes from this IP number."

    def get_atualizacao_SOAP (self, id=None):
        if not id == None:
            self.id = id
        if self.can_get_soap:
            client = zeep.Client(wsdl=self.wsdl)
            self.data_atualizacao = client.service.getDataAtualizacaoCV(self.id)
            if self.data_atualizacao == None:
                raise ValueError('Invalid ID') 
            else:
                self.data_atualizacao = datetime.strptime(self.data_atualizacao, '%d/%m/%Y %H:%M:%S').replace(tzinfo=pytz.UTC)
                print ("Data de atualização pega via SOAP:", self.data_atualizacao)
        else:
            return('Impossível recuperar SOAP')

    def get_id (self, CPF = "69045542153", nome="Alberto de Campos e Silva", data_nascimento="10/05/1976"):
        self.CPF = CPF
        self.nome = nome
        self.data_nascimento = data_nascimento
        client = zeep.Client(wsdl=self.wsdl)
        self.id = client.service.getIdentificadorCNPq(self.CPF, self.nome, self.data_nascimento)
        if self.id == None:
            raise ValueError('Invalid CPF, Name or DateBirth informed.')
        print ("ID do usuário pego pelos dados pessoais.")


# d8888b.      d888888b      .d8888.      db   dD                               
# 88  `8D        `88'        88'  YP      88 ,8P'                               
# 88   88         88         `8bo.        88,8P                                 
# 88   88         88           `Y8b.      88`8b                                 
# 88  .8D        .88.        db   8D      88 `88.                               
# Y8888D'      Y888888P      `8888Y'      YP   YD                               
                                                                              
                                                                              
# d88888b db    db d8b   db  .o88b. d888888b d888888b  .d88b.  d8b   db .d8888. 
# 88'     88    88 888o  88 d8P  Y8 `~~88~~'   `88'   .8P  Y8. 888o  88 88'  YP 
# 88ooo   88    88 88V8o 88 8P         88       88    88    88 88V8o 88 `8bo.   
# 88~~~   88    88 88 V8o88 8b         88       88    88    88 88 V8o88   `Y8b. 
# 88      88b  d88 88  V888 Y8b  d8    88      .88.   `8b  d8' 88  V888 db   8D 
# YP      ~Y8888P' VP   V8P  `Y88P'    YP    Y888888P  `Y88P'  VP   V8P `8888Y' 


    @staticmethod
    def get_saving_path(type, path, id, create_path_if_new = True):
        filename = "Lattes_" + id + "." + type
        path_name = os.path.join(path, 'Lattes_' + type.upper())
        if type=="zip":
            full_path =  os.path.join(path_name, id[0], id[1])
        else:
            full_path = os.path.join(path_name, id[0], id[1], id[2], id[3], id[4])
        if create_path_if_new:
            pathlib.Path(full_path).mkdir(parents=True, exist_ok=True)
        return os.path.join(full_path, filename)

    def read_zip_from_disk(self, filename = None, path = None, get_from_SOAP_if_not_exists = True):
        if path == None:
            path = self.path
        if filename == None:
            filename = Lattes_SOAP.get_saving_path(type = "zip", path = path, id = self.id)
        try:
            with open(filename, 'rb') as f:
                self.zip = f.read()
            if not self.zip == None:
                return True
        except:
            return False

    def read_xml_from_disk (self, filename = None, path = None):
        if path == None:
            path = self.path
        if filename == None:
            filename = Lattes_SOAP.get_saving_path("xml", path = path, id = self.id)
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                self.xml = f.read()
            if not self.xml == None:
                return True
            else:
                return False
        except:
            return False

    def read_json_from_disk(self, filename = None, path = None):
        if path == None:
            path = self.path
        if filename == None:
            filename = Lattes_SOAP.get_saving_path("JSON", path = path, id = self.id)
        try:
            with open(filename, 'r', encoding='utf-8') as f:
                self.json = json.load(f)
            if not self.json == None:
                return True
            else:
                return False
        except:
            return False
                

    def read_from_disk (self, path = None):
        if path == None:
            path = self.path
        if not path == None:
            self.path = path
        self.read_zip_from_disk()
        self.read_xml_from_disk()
        self.read_json_from_disk()

    def save_xml_to_disk (self, filename = None, path = None, replace = False):
        if path == None:
            path = self.path
        if filename == None:
            filename = Lattes_SOAP.get_saving_path("xml", path = path, id = self.id)
        if replace or not os.path.isfile(filename):
            with open(filename, 'w', encoding='utf-8') as f:
                f.write(self.xml)
            print("Arquivo em XML salvo no disco.")

    def save_json_to_disk (self, filename = None, path = None, replace = False):
        if path == None:
            path = self.path
        if filename == None:
            filename = Lattes_SOAP.get_saving_path("JSON", path = path, id = self.id)
        if replace or not os.path.isfile(filename):
            with open(filename, 'w', encoding='utf-8') as f:
                json.dump(self.json, f, indent=4)
            print("Arquivo em JSON salvo no disco.")
        
    def save_zip_to_disk (self, path = None, filename = None, replace = False):
        if path == None:
            path = self.path
        if filename == None:
            filename = Lattes_SOAP.get_saving_path("JSON", path = path, id = self.id)
        if replace or not os.path.isfile(filename):
            with open(filename, 'wb') as f:
                f.write(self.zip)
            print("Arquivo compactado salvo no disco.")
        return True        

    def save_to_disk (self, path = None):
        if not path == None:
            self.path = path
        
        self.save_zip_to_disk()
        self.save_xml_to_disk()
        self.save_json_to_disk()



#  dP""b8    dP"Yb    88b 88   Yb    dP   888888   88""Yb   888888 
# dP   `"   dP   Yb   88Yb88    Yb  dP    88__     88__dP     88   
# Yb        Yb   dP   88 Y88     YbdP     88""     88"Yb      88   
#  YboodP    YbodP    88  Y8      YP      888888   88  Yb     88   

#  888888   88   88   88b 88    dP""b8   888888   88    dP"Yb    88b 88   .dP"Y8 
# 88__     88   88   88Yb88   dP   `"     88     88   dP   Yb   88Yb88   `Ybo." 
# 88""     Y8   8P   88 Y88   Yb          88     88   Yb   dP   88 Y88   o.`Y8b 
# 88       `YbodP'   88  Y8    YboodP     88     88    YbodP    88  Y8   8bodP' 



    def recorre_sobre_todo_json(self, d, path=None):
            if not path: path = []
            for k, v in d.items():
                if isinstance(v, dict) or isinstance(v, OrderedDict):
                    #print("Getting: ", k)
                    self.recorre_sobre_todo_json(v, path + [k])
                elif isinstance(v, list):
                    num = 0
                    for item in v:
                        #print("Unfolding List: ", v)
                        self.recorre_sobre_todo_json(item, path + [k] + [num])
                        num +=1
                else:
                    if not v == None:
                        d[k] = html.unescape(v)
                    else:
                        pass
            return d    
    
    def get_xml(self):
        if self.zip == None:
            return False
        try:
            with ZipFile(io.BytesIO(self.zip)) as myzip:
                with myzip.open(myzip.namelist()[0]) as myfile:
                    self.xml = myfile.read()
                self.json = xmltodict.parse(self.xml)
                self.json = self.recorre_sobre_todo_json(self.json)
                self.xml = self.xml.decode('iso-8859-1').replace('encoding="ISO-8859-1" ', '')
            return True
        except:
            return False     


    def get_id_by_xml (self):
        if self.xml == None: return None
        if not (
                type(self.xml) == BeautifulSoup or
                type(self.xml) == Tag ):
            self.xml = BeautifulSoup(self.xml, "xml")
        if self.id == None:
            self.id = self.soup.find('CURRICULO-VITAE')['NUMERO-IDENTIFICADOR']
        data = self.soup.find('CURRICULO-VITAE').get('DATA-ATUALIZACAO')
        hora = self.soup.find('CURRICULO-VITAE').get('HORA-ATUALIZACAO')
        self.data_atualizacao = datetime.strptime(data + hora, '%d%m%Y%H%M%S')
        self.nome_completo = self.soup.find('DADOS-GERAIS').get('NOME-COMPLETO')
        self.nacionalidade = self.soup.find('DADOS-GERAIS').get('PAIS-DE-NACIONALIDADE')
        self.nomes_citação = self.soup.find('DADOS-GERAIS').get('NOME-EM-CITACOES-BIBLIOGRAFICAS')
        #self.CPF = self.soup.find('DADOS-GERAIS').get('CPF')
        #self.data_nascimento = datetime.strptime(self.soup.find('DADOS-GERAIS').get('DATA-NASCIMENTO'], '%d%m%Y')
        #self.sexo = self.soup.find('DADOS-GERAIS').get('SEXO')
        #self.raca = self.soup.find('DADOS-GERAIS').get('RACA-OU-COR')
                    